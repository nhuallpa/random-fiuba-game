#ifndef CANVAS_H_
#define CANVAS_H_

#include "Contenedor.h"

#include "Utils/Rect.h"
#include <list>

class FuentePosicion;
class DestinoDibujo;
class FiguraVista;
class Escenario;
namespace Modelo {
	class Mundo;
	class EntidadWrapper;
}

class Canvas : public Contenedor
{
public:
	Canvas (const FuentePosicion& fuente, Dibujable* destino,
	        Escenario *escenario, const Rect& regionModeloAMostrar);
	virtual ~Canvas ();

	Vec2 tamUnidadLogica() const;

	virtual LayoutInfo getLayoutInfo();

	bool aEliminar (Vec2 posicionRespectoPadre);
	virtual bool recibirFigura (const FiguraVista *elemento, Vec2 pos, vista::PrioridadDibujo prioridad = vista::PrioridadDibujo::normal);
	virtual bool recibirElementoPuente(FiguraVista *elemento, Vec2 extremoA, Vec2 extremoB, vista::PrioridadDibujo prioridad = vista::PrioridadDibujo::normal);
	void setBackground(std::string filename, DestinoDibujo* destino);

	Rect getRegionModelo ();

private:
	Escenario* escenario;
	Rect regionModelo;

	FiguraVista* findUnion(Modelo::EntidadWrapper entidadPuente);
	std::list<FiguraVista*> elementosPuente;
};

#endif /* CANVAS_H_ */
