/*
 * Simulador.cpp
 *
 *  Created on: Oct 5, 2013
 *      Author: lucia
 */

#include "Simulador.h"
#include "Cuerpos/PelotaBasquet.h"
#include "Cuerpos/PelotaBowling.h"
#include "Cuerpos/Balancin.h"
#include "Cuerpos/Correa.h"
#include "Cuerpos/CintaTransportadora.h"
#include "Cuerpos/Engranaje.h"
#include "Cuerpos/Globo.h"
#include "Cuerpos/Motor.h"
#include "Cuerpos/Plataforma.h"
#include "Cuerpos/Soga.h"
#include "Cuerpos/Correa.h"
#include "Cuerpos/CuerpoRotativo.h"
#include "Modelo/EntidadWrapper.h"
#include <iostream>
#include <stdio.h>

namespace simulador {
Simulador::Simulador()
	: m_mundo()
	, cuerpos()
	, estaInicializado(false)
	, estaCorriendo(false)
{
	timeStep = 1/Constantes::Instancia()->iteracionesPorSegundo;
	velocityIterations = Constantes::Instancia()->nIteracionesVelocidades;
	positionIterations = Constantes::Instancia()->nIteracionesPosiciones;
}

bool Simulador::inicializar(Modelo::Mundo* mundo) {
	if(!estaInicializado) {
		modelarMundo(mundo);
		estaInicializado = true;
	}
	return estaInicializado;
}

bool Simulador::play() {
	if(!estaCorriendo) {
		estaCorriendo = true;
	}
	return estaCorriendo;
}

bool Simulador::stop(){
	if(estaCorriendo){
		estaInicializado = false;
		estaCorriendo = false;
		restaurar();
	}
	return !estaCorriendo;
}

bool Simulador::step(){
	if(estaCorriendo) {
		modelarContactos();
		//DAR UN PASO EN LA SIMULACION:
		m_mundo->Step( timeStep, velocityIterations, positionIterations);
		//TRADUCIRLO AL MODELO:
		std::list<Cuerpo*>::const_iterator iterator;
		for(iterator = cuerpos.begin();iterator != cuerpos.end(); ++iterator) {
			Cuerpo* cuerpo = *iterator;
			cuerpo->vivir();
		}
	}
	return estaCorriendo;
}

void Simulador::modelarMundo(Modelo::Mundo* mundo) {
	m_mundo = new b2World(b2Vec2(0,simulador::Constantes::Instancia()->gravedad));
	modelarCuerpos(mundo);
//	m_mundo->SetContactListener(new ContactListener(m_mundo));
	modelarContactos();
	estaInicializado = true;
}

void Simulador::modelarCuerpos(Modelo::Mundo* mundo) {
	typedef Modelo::Mundo::iterator iter;
	//Sogas y correas.
	std::list<Modelo::EntidadWrapper> uniones;
	for (Modelo::EntidadWrapper ent : *mundo) {
		simulador::Cuerpo* n_cuerpo = nullptr;
		switch (ent.clase()) {
			case Modelo::TipoElemento::PelotaBasquet :
				n_cuerpo = new PelotaBasquet(ent.centro(), m_mundo, ent.radio(), ent.base.get());
				break;
			case Modelo::TipoElemento::PelotaBowling :
				n_cuerpo = new PelotaBowling(ent.centro(), m_mundo, ent.radio(), ent.base.get());
				break;
			case Modelo::TipoElemento::Globo :
				n_cuerpo = new Globo(ent.centro(), m_mundo, ent.radio(), ent.base.get());
				break;
			case Modelo::TipoElemento::Plataforma :
				n_cuerpo = new Plataforma(ent.centro(), ent.tamanio().x/2, ent.tamanio().y/2 ,ent.angulo(), m_mundo, ent.base.get());
				break;
			case Modelo::TipoElemento::Balancin :
				n_cuerpo = new Balancin(ent.tamanio()/2, ent.centro(), ent.angulo(), m_mundo, ent.base.get());
				break;
			case Modelo::TipoElemento::Soga :
				uniones.push_back(ent);
				break;
			case Modelo::TipoElemento::Motor :
				n_cuerpo = new Motor(ent.centro(), m_mundo, ent.angulo(), ent.radio(), ent.sentidoHorario(), !ent.sentidoHorario(), ent.base.get());
				break;
			case Modelo::TipoElemento::Correa :
				uniones.push_back(ent);
				break;
			case Modelo::TipoElemento::Engranaje :
				n_cuerpo = new Engranaje(ent.centro(), m_mundo, ent.angulo(), ent.radio(), true, false, ent.base.get());
				break;
			case Modelo::TipoElemento::CintaTransportadora :
				n_cuerpo = new CintaTransportadora(ent.centro(), m_mundo, ent.tamanio()/2, ent.base.get());
				break;
		}
		if(n_cuerpo!=nullptr){
			cuerpos.push_back(n_cuerpo);
		}
	}
	if(!uniones.empty()) modelarContactosADistancia(uniones);
}

void Simulador::modelarContactosADistancia(std::list<Modelo::EntidadWrapper> uniones){
	for (auto& entidadUnion : uniones) {
		Cuerpo* bodyA = buscarCuerpo(entidadUnion.entidadExtremoA());
		Cuerpo* bodyB = buscarCuerpo(entidadUnion.entidadExtremoB());
		if (entidadUnion.clase() == Modelo::TipoElemento::Soga) {
			//Los puntos de ligadura son totales.
			Cuerpo* soga = new Soga(m_mundo, bodyA->getCuerpo(), bodyB->getCuerpo(),entidadUnion.base.get());
			cuerpos.push_back(soga);
		} else if (entidadUnion.clase() == Modelo::TipoElemento::Correa) {
			Cuerpo* correa = new Correa(m_mundo, bodyA, bodyB, Constantes::Instancia()->ratioGiroEngranajes, entidadUnion.base.get());
			cuerpos.push_back(correa);
			//modelarCuerpoRotativoCinta(entidadUnion);
			modelarCuerposRotativos(entidadUnion);
		}
	}
}

//Busca en la lista de nuestros cuerpos, cuál corresponde a Entidad.
Cuerpo* Simulador::buscarCuerpo(Modelo::Entidad* entidad){
	std::list<Cuerpo*>::iterator iterator;
	for(iterator = cuerpos.begin();iterator != cuerpos.end(); ++iterator) {
		Cuerpo* cuerpo = *iterator;
		if(entidad==cuerpo->entidad){
			return cuerpo;
		}
	}
	return nullptr;
}

void Simulador::modelarContactos() {
	//recorro todos los contactos que existen en el m_mundo

	for(b2Contact* contact = m_mundo->GetContactList(); contact; contact = contact->GetNext()){

		void* data1 = contact->GetFixtureA()->GetBody()->GetUserData();
		void* data2 = contact->GetFixtureB()->GetBody()->GetUserData();

		if (data1 && data2){
			Cuerpo* gear1 = static_cast<Cuerpo*> (data1);
			Cuerpo* gear2 = static_cast<Cuerpo*> (data2);
			if(contact->IsTouching()){
				gear1->tocarse(gear2, m_mundo);
			}

		}
	}
}

void Simulador::modelarCuerpoRotativoCinta(Modelo::EntidadWrapper entidad){
	Modelo::Entidad* entidadA = entidad.entidadExtremoA();
	Modelo::Entidad* entidadB = entidad.entidadExtremoB();

	Cuerpo* bodyA = buscarCuerpo(entidadA);
	Cuerpo* bodyB = buscarCuerpo(entidadB);

	if ((entidadA->clase == Modelo::TipoElemento::Motor || entidadA->clase == Modelo::TipoElemento::Engranaje)
			&& (entidadB->clase == Modelo::TipoElemento::CintaTransportadora)){
		CintaTransportadora* cinta = (CintaTransportadora*) bodyB;
		cinta->setSentidoSegunCuerpoRotativo((CuerpoRotativo*) bodyA);
	}

	if ((entidadA->clase == Modelo::TipoElemento::CintaTransportadora)
			&& (entidadB->clase == Modelo::TipoElemento::Motor || entidadB->clase == Modelo::TipoElemento::Engranaje)){
		CintaTransportadora* cinta = (CintaTransportadora*) bodyA;
		cinta->setSentidoSegunCuerpoRotativo((CuerpoRotativo*) bodyB);
	}

}

void Simulador::modelarCuerposRotativos(Modelo::EntidadWrapper entidad){
	Modelo::Entidad* entidadA = entidad.entidadExtremoA();
	Modelo::Entidad* entidadB = entidad.entidadExtremoB();

	Cuerpo* bodyA = buscarCuerpo(entidadA);
	Cuerpo* bodyB = buscarCuerpo(entidadB);

	if (entidadA->clase == Modelo::TipoElemento::CintaTransportadora || entidadB->clase == Modelo::TipoElemento::CintaTransportadora){
		modelarCuerpoRotativoCinta(entidad);
	}

	if ((entidadA->clase == Modelo::TipoElemento::Motor)
			&& (entidadB->clase == Modelo::TipoElemento::Engranaje)){
		Engranaje* engranaje = (Engranaje*) bodyB;
		engranaje->setSentidoSegunCuerpoRotativo((CuerpoRotativo*) bodyA);
	}
}
void Simulador::restaurar(){
	std::list<Cuerpo*>::const_iterator iterator;
	for(iterator = cuerpos.begin();iterator != cuerpos.end(); ++iterator) {
		Cuerpo* cuerpo = *iterator;
		cuerpo->restaurarCuerpo();
	}
}

Simulador::~Simulador() {
	for(b2Joint* joint = m_mundo->GetJointList(); joint; joint = joint->GetNext()){
		this->m_mundo->DestroyJoint(joint);
	}

	std::list<Cuerpo*>::const_iterator iterator;
	for(iterator = cuerpos.begin(); iterator != cuerpos.end(); ++iterator){
		delete *iterator;
	}
}

} /* namespace simulador */
