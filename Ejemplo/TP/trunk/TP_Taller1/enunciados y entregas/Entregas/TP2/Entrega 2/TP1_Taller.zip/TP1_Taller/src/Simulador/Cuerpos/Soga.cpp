/*
 * Soga.cpp
 *
 *  Created on: 04/10/2013
 *      Author: stephanie
 */

#include "Soga.h"
#include <cmath>

namespace simulador {

Soga::Soga(b2World* mundo, b2Body* bodyA, b2Body* bodyB, Modelo::Entidad* entidad)
	: bodyA(bodyA)
	, bodyB(bodyB)
	, rJoint(nullptr)
	, puntoLigaduraA(entidad->puntoDeLigaduraEntidadA)
	, puntoLigaduraB(entidad->puntoDeLigaduraEntidadB)
{
	this->entidad = entidad;
	b2Vec2 puntoLocalA = b2Vec2(entidad->puntoDeLigaduraEntidadA) - bodyA->GetWorldCenter();
	b2Vec2 puntoLocalB = b2Vec2(entidad->puntoDeLigaduraEntidadB) - bodyB->GetWorldCenter();
	this->unir(mundo, puntoLocalA, puntoLocalB);
	this->m_mundo = mundo;
}

Soga::~Soga() {
}

void Soga::vivir(){
	entidad->puntoDeLigaduraEntidadA = rJoint->GetAnchorA();
	entidad->puntoDeLigaduraEntidadB = rJoint->GetAnchorB();
	entidad->regenerar();
}

void Soga::unir(b2World* mundo, b2Vec2 puntoA, b2Vec2 puntoB){
	b2RopeJointDef j;
	j.collideConnected = true;
	j.bodyA = this->bodyA;
	j.bodyB = this->bodyB;
	/* El sistema local y los puntos ya vienen rotados, por lo que necesito
	 * cancelar alguna de las dos rotaciones */
	auto cte = Constantes::Instancia();
	j.localAnchorA = Vec2(1,-1) * Vec2(puntoA).rotar(bodyA->GetAngle() * cte->RADTODEG);
	j.localAnchorB = Vec2(1,-1) * Vec2(puntoB).rotar(bodyB->GetAngle() * cte->RADTODEG);
	Vec2 globalAnchorA = bodyA->GetPosition() + puntoA;
	Vec2 globalAnchorB = bodyB->GetPosition() + puntoB;
	j.maxLength = globalAnchorA.distancia(globalAnchorB);
	rJoint = (b2RopeJoint*) mundo->CreateJoint(&j);
}

void Soga::restaurarCuerpo(){
	entidad->puntoDeLigaduraEntidadA = puntoLigaduraA;
	entidad->puntoDeLigaduraEntidadB = puntoLigaduraB;
	entidad->regenerar();
}

} /* namespace simulador */
