#ifndef MODOEDICION_H_
#define MODOEDICION_H_

#include "Modo/ModoUsuario.h"
#include "Modelo/Escenario.h"
#include "Vista/Ventana.h"

#include <string>

class Canvas;
class Boton;

namespace Modo {

class ModoSimulacion;

class ModoEdicion : public ModoJuego
{
public:
	ModoEdicion ();
	ModoEdicion (Ventana *ventana, Escenario *escenario, std::string pathEscenario);
	ModoEdicion (ModoSimulacion&&);

	ModoEdicion (const ModoEdicion&) = delete;
	ModoEdicion (ModoEdicion&&) = default;
	ModoEdicion& operator= (const ModoEdicion&) = delete;
	ModoEdicion& operator= (ModoEdicion&&) = default;
	virtual ~ModoEdicion();

	virtual EstadoJuego estado ();
	virtual EstadoJuego iteracionPrincipal (float ms);
	virtual std::unique_ptr<ModoJuego> transicion(EstadoJuego proximo);

private:
	Ventana *window;
	Escenario *escenario;
	std::string pathEscenario;
	Canvas *izquierda;
	Boton *cambioModo;
	Boton *salir;
	EstadoJuego proximoEstado;
	float ultimoUpdate;

	static constexpr unsigned fps_deseado = 60;

	friend class ModoSimulacion;
};

} /* namespace Modo */
#endif /* MODOEDICION_H_ */
