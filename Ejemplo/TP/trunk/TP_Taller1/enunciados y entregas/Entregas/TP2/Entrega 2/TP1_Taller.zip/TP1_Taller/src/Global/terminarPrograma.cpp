#include "terminarPrograma.h"

#include <SDL2/SDL.h>

void terminarPrograma (void)
{
	SDL_Event evento;
	evento.type = SDL_QUIT;
	SDL_PushEvent(&evento);
}
