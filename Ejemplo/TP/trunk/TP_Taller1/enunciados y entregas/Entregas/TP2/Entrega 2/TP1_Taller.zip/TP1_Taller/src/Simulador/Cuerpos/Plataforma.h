/*
 * Plataforma.h
 *
 *  Created on: Oct 3, 2013
 *      Author: lucia
 */

#ifndef PLATAFORMA_H_
#define PLATAFORMA_H_
#include "../Cuerpo.h"
namespace simulador {

class Plataforma : public Cuerpo {
public:
	Plataforma(b2Vec2 posInicial, float ancho,
			float alto, float angulo, b2World* mundo, Modelo::Entidad* entidad);
	virtual ~Plataforma();
	virtual void restaurarCuerpo();
private:
	b2Body* crearCuerpo(b2World* mundo);
	b2Vec2 dimensiones;
	float angulo;
};

} /* namespace simulador */
#endif /* PLATAFORMA_H_ */
