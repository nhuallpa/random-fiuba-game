#include "Mundo.h"

#include "Log/Suceso.h"
#include "Serializacion/Entidad.h"
#include "Utils/ConvertStr.h"
#include <yaml-cpp/yaml.h>

namespace YAML
{

Node convert<Modelo::Mundo>::encode(const Modelo::Mundo& rhs) {
	Node node;
	for (Modelo::Mundo::const_iterator iter = rhs.begin(); iter != rhs.end(); ++iter) {
		node.push_back(*iter);
	}
	return node;
}

bool convert<Modelo::Mundo>::decode(const Node& node, Modelo::Mundo& rhs) {
	YAML::Mark marca = node.mark();

	if(!node.IsSequence()) {
		ConvertStr output(marca, "No se puede leer Mundo. Creado vacio.");
		Log::Suceso (Log::ERROR, output.getString());
	}
	else {
		for (unsigned i = 0; i < node.size(); ++i) {
			try {
				rhs.agregarEntidad(node[i].as<Modelo::EntidadWrapper>());
			} catch (YAML::TypedBadConversion<Modelo::EntidadWrapper>& e) {
			} catch (Log::Suceso&) {
			}
		}
	}
	return true;
}

} /* namespace YAML */
