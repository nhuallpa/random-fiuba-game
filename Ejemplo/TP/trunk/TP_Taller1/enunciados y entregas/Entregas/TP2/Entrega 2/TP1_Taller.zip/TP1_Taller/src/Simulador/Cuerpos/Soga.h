/*
 * Soga.h
 *
 *  Created on: 04/10/2013
 *      Author: stephanie
 */

#ifndef SOGA_H_
#define SOGA_H_

#include "../Cuerpo.h"

namespace simulador {

class Soga: public simulador::Cuerpo {
public:
	Soga(b2World* mundo, b2Body* bodyA, b2Body* bodyB, Modelo::Entidad* entidad);
	virtual ~Soga();
	void unir(b2World* mundo, b2Vec2 puntoA, b2Vec2 puntoB);
	void vivir();
	void restaurarCuerpo();

private:
	b2Body* crearCuerpoSoga(b2World* mundo, int incremento);
	b2Body* bodyA;
	b2Body* bodyB;
	b2RopeJoint* rJoint;
	Vec2 puntoLigaduraA;
	Vec2 puntoLigaduraB;
};

} /* namespace simulador */
#endif /* SOGA_H_ */
