#include "Entidad.h"

#include "Log/Suceso.h"
#include <algorithm>

namespace Modelo {

Entidad::Entidad()
	: clase()
	, centro()
	, tamanio()
	, angulo()
	, sentidoHorario(true)
	, entidadExtremoA(NULL)
	, entidadExtremoB(NULL)
	, puntoDeLigaduraEntidadA()
	, puntoDeLigaduraEntidadB()
	, elemPuenteAtado()
{
}


Entidad::Entidad(Modelo::TipoElemento clase, Vec2 centro, Vec2 tamanio, float angulo)
	: clase(clase)
	, centro(centro)
	, tamanio(tamanio)
	, angulo(angulo)
	, sentidoHorario(true)
	, entidadExtremoA(NULL)
	, entidadExtremoB(NULL)
	, puntoDeLigaduraEntidadA()
	, puntoDeLigaduraEntidadB()
	, elemPuenteAtado()
{
}


Entidad::Entidad(const Entidad& unaEntidad)
	: clase(unaEntidad.clase)
	, centro(unaEntidad.centro)
	, tamanio(unaEntidad.tamanio)
	, angulo(unaEntidad.angulo)
	, sentidoHorario(unaEntidad.sentidoHorario)
	, entidadExtremoA(unaEntidad.entidadExtremoA)
	, entidadExtremoB(unaEntidad.entidadExtremoB)
	, puntoDeLigaduraEntidadA(unaEntidad.puntoDeLigaduraEntidadA)
	, puntoDeLigaduraEntidadB(unaEntidad.puntoDeLigaduraEntidadB)
	, elemPuenteAtado(unaEntidad.elemPuenteAtado)
{
}


Entidad& Entidad::operator =(const Entidad& otraEntidad) {
	if (this == &otraEntidad) {
		return *this;
	}

	clase = otraEntidad.clase;
	centro = otraEntidad.centro;
	tamanio = otraEntidad.tamanio;
	angulo = otraEntidad.angulo;
	sentidoHorario = otraEntidad.sentidoHorario;
	entidadExtremoA = otraEntidad.entidadExtremoA;
	entidadExtremoB = otraEntidad.entidadExtremoB;
	puntoDeLigaduraEntidadA = otraEntidad.puntoDeLigaduraEntidadA;
	puntoDeLigaduraEntidadB = otraEntidad.puntoDeLigaduraEntidadB;
	elemPuenteAtado.assign(otraEntidad.elemPuenteAtado.begin(), otraEntidad.elemPuenteAtado.end());

	return *this;
}


Entidad::~Entidad () {
}


bool Entidad::colicionaCon(Entidad* otraEntidad) const {
	if(otraEntidad == this) {
		//Conmigo mismo no colisiono.
		return false;
	}

	Vec2 tamOtroSup;
	Vec2 tamMiSup;

	//solo se aplica el porcentaje permitido de colisión si se juntan engranajes
	//TODO mover a métodos viruales de correa y engranaje.
	if ((this->clase == Modelo::TipoElemento::Engranaje && otraEntidad->clase == Modelo::TipoElemento::Engranaje) ||
			(this->clase == Modelo::TipoElemento::CintaTransportadora && otraEntidad->clase == Modelo::TipoElemento::Engranaje) ||
			(this->clase == Modelo::TipoElemento::Engranaje && otraEntidad->clase == Modelo::TipoElemento::CintaTransportadora) ){
		tamOtroSup = otraEntidad->tamanio - otraEntidad->tamanio*PORCENTAJE_PERMITIDO_COLISION/100;
		tamMiSup = tamanio - tamanio*PORCENTAJE_PERMITIDO_COLISION/100;
	}else {
		tamOtroSup = otraEntidad->tamanio;
		tamMiSup = tamanio;
	}

	Rect otroSup = Rect::deCentro(otraEntidad->centro, tamOtroSup);
	Rect miSup = Rect::deCentro(centro, tamMiSup);

	return miSup.colisiona(angulo, otroSup, otraEntidad->angulo);
}


bool Entidad::esMovil() const {
	return false;
}


bool Entidad::esNoMovil() const {
	return false;
}


bool Entidad::esPelota() const {
	return false;
}


bool Entidad::esElementoPuente() const {
	return false;
}


bool Entidad::esSogeable() const {
	return false;
}


bool Entidad::esCorreable() const {
	return false;
}


bool Entidad::tieneLosDosExtremosLibres() const {
	return false;
}


bool Entidad::tieneUnExtremoLibre() const {
	return false;
}


bool Entidad::puedeUnirseA(Entidad* unaEntidad) const {
	(void) ((unaEntidad)); // unused parameter
	return false;
}


bool Entidad::tieneElemPuenteAtado() const {
	if (!this->elemPuenteAtado.empty()) {
		return true;
	}
	return false;
}


std::list<Vec2> Entidad::lugarDondeSePuedeUnir() const {
	auto retval = lugarDondeSePuedeUnirBase();
	for (auto& val : retval) {
		val = centro + (val - centro).rotar(angulo);
	}
	return retval;
}

std::list<Vec2> Entidad::lugarDondeSePuedeUnirBase() const {
	return std::list<Vec2>();
}


std::pair<bool, Vec2> Entidad::lugarUnionMasCercano(Vec2 pos) const {
	auto candidatos = lugarDondeSePuedeUnir();
	if (candidatos.empty()) {
		return std::make_pair(false, Vec2());
	}
	Vec2 val = *std::min_element(begin(candidatos), end(candidatos), [pos] (Vec2 lhs, Vec2 rhs) {
		return lhs.distancia(pos) < rhs.distancia(pos);
	});
	return std::make_pair(true, val);
}


std::list<Entidad*> Entidad::desenlazarElemPuente() {
	if (!this->elemPuenteAtado.empty()) {
		for(Entidad* puente : this->elemPuenteAtado) {
			if (puente->entidadExtremoA == this) {
				puente->entidadExtremoA = NULL;
				puente->puntoDeLigaduraEntidadA = Vec2();
			}

			if (puente->entidadExtremoB == this) {
				puente->entidadExtremoB = NULL;
				puente->puntoDeLigaduraEntidadB = Vec2();
			}
		}

		std::list<Entidad*> elemPuente = elemPuenteAtado;
		this->elemPuenteAtado.clear();
		return elemPuente;
	}
	return elemPuenteAtado;
}


Entidad* Entidad::copiaProfunda(std::map<Entidad*, Entidad*> mapaDeEntidades) {
	std::map<Entidad*, Entidad*>::iterator iter;
	iter = mapaDeEntidades.find(this);

	if (iter == mapaDeEntidades.end()) {	// si no esta
		Entidad* copia = new Entidad();
	//	copia = this;
		mapaDeEntidades[this] = copia;

		if (this->entidadExtremoA != NULL) {
			copia->entidadExtremoA = this->entidadExtremoA->copiaProfunda(mapaDeEntidades);
		}

		if (this->entidadExtremoB != NULL) {
			copia->entidadExtremoB = this->entidadExtremoB->copiaProfunda(mapaDeEntidades);
		}

		//TODO
//		if (this->elemPuenteAtado != NULL) {
//			copia->elemPuenteAtado = this->elemPuenteAtado->copiaProfunda(mapaDeEntidades);
//		}

		return copia;
	}

	return iter->second;
}

void Entidad::regenerar () {
	centro = (puntoDeLigaduraEntidadA + puntoDeLigaduraEntidadB) / 2;
	tamanio = Vec2(puntoDeLigaduraEntidadA.distancia(puntoDeLigaduraEntidadB), 0);
	angulo = puntoDeLigaduraEntidadA.anguloCon(puntoDeLigaduraEntidadB);
}


} /* namespace Modelo */
