#ifndef ENTIDAD_H_
#define ENTIDAD_H_

#include "Utils/Vec2.h"
#include "Utils/Rect.h"
#include "Modelo/TipoElemento.h"
#include <string>
#include <list>
#include <map>

//Es un porcentaje que permite que se toquen un poco los objetos
//se usa en colisiona con
#ifndef PORCENTAJE_PERMITIDO_COLISION
#define PORCENTAJE_PERMITIDO_COLISION 30
#endif

namespace Modelo {

// Clase que modela a cualquier objeto que puede existir en el juego.
// Clase padre de todos esos objetos.
// Todos los atributos son publicos, asi que no hace falta compliarse ni alargar el codigo con getters y setters.
class Entidad {

public:
	Entidad();
	explicit Entidad(Modelo::TipoElemento clase, Vec2 centro = Vec2(0, 0),
	                  Vec2 tamanio = Vec2(0, 0), float angulo = 0.0f);
	Entidad(const Entidad& unaEntidad);
	Entidad& operator=(const Entidad& otraEntidad);
	virtual ~Entidad();

	// La soga y la correa son los unicos que no colisionan con otras entidades.
	virtual bool colicionaCon(Entidad* otraEntidad) const;

	// Aca sigue una serie de checkeos booleanos, que en principio todas retornan "false".
	// En cada clase heredada, en las cuales correspondan y se apliquen, retornara "true".
	virtual bool esMovil() const;		// pelotaBasquet, pelotaBowling, globo
	virtual bool esNoMovil() const;		// plataforma, soga, balancin, engranaje, motor, correa, cinta

	virtual bool esElementoPuente() const;	// EntidadElementoPuente: 	correa, soga					(1)
	virtual bool esSogeable() const;		// EntidadSogeable:			globo, balancin					(2)
	virtual bool esCorreable() const;		// EntidadCorreable:		engranaje, motor, cinta			(3)
	virtual bool esPelota() const;			// EntidadPelota:			pelotaBasquet, pelotaBowling	(4)

	// (1) Para soga y correa:
	virtual bool tieneLosDosExtremosLibres() const;
	virtual bool tieneUnExtremoLibre() const;
	virtual bool puedeUnirseA(Entidad* unaEntidad) const;

	// (2) (3) Para globo y balancin, como tambien engranaje, motor y cinta:
	virtual bool tieneElemPuenteAtado() const;

	// (2) (3) Devuelve el punto en donde el objeto se puede unirse a una soga o una correa (segun corresponda).
	// Devuelve lista vacia si no se puede unirse.
	// No es afectado si la entidad ya esta unido a algo.
	std::list<Vec2> lugarDondeSePuedeUnir() const;
	std::pair<bool, Vec2> lugarUnionMasCercano(Vec2 pos) const;

	// (2) (3) Si hay soga o correa unida, elimina la union en la entidad enlazada,
	// y devuelve el elmento puente unido. Sino devuelve NULL.
	virtual std::list<Entidad*> desenlazarElemPuente();

	// Para "copia profunda" de Mundo
	virtual Entidad* copiaProfunda(std::map<Entidad*,Entidad*> mapaDeEntidades);

	// (1) Reconstruye los atributos centro/tamanio/angulo
	void regenerar ();

// Atributos (todos publicos)
	Modelo::TipoElemento clase;
	Vec2 centro;			// (x, y)
	Vec2 tamanio;			// (ancho, alto)
	float angulo;			// Para plataforma (en grados)
	bool sentidoHorario;	// Para motor

	// (1) Para soga y correa: objetos atados
	Entidad* entidadExtremoA;
	Entidad* entidadExtremoB;
	// (1) Para soga y correa: en qué punto de los objetos esta atado el elemento puente
	Vec2 puntoDeLigaduraEntidadA;
	Vec2 puntoDeLigaduraEntidadB;

	// (2) (3) Para globo y balancin, como tambien engranaje, motor y cinta:
	//TODO elemPuenteSAtados.
	std::list<Entidad*> elemPuenteAtado;

protected:
	virtual std::list<Vec2> lugarDondeSePuedeUnirBase() const;
};


} /* namespace Modelo */

#endif /* ENTIDAD_H_ */
