/*
 * Cursor.cpp
 *
 *  Created on: 11/10/2013
 *  Last Amended: 11/10/2013
 *      Author: natuchis
 */

#include "Cursor.h"

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

Cursor::Cursor(std::string path)
	: cursor(NULL)
{
	SDL_Surface* superficieMulPun = IMG_Load (path.c_str());
	cursor = SDL_CreateColorCursor(superficieMulPun,0,0);
	SDL_FreeSurface(superficieMulPun);
}

Cursor::~Cursor() {
	SDL_FreeCursor(cursor);
}

void Cursor::mostrar() {
	SDL_ShowCursor(SDL_ENABLE);
}

void Cursor::ocultar() {
	SDL_ShowCursor(SDL_DISABLE);
}

void Cursor::activar() {
	SDL_SetCursor(cursor);
	mostrar();
}
