#ifndef SERIALIZACION_MUNDO_H_
#define SERIALIZACION_MUNDO_H_

#include "Modelo/Mundo.h"
#include <yaml-cpp/node/convert.h>

namespace YAML {

template<>
struct convert<Modelo::Mundo> {
	static Node encode(const Modelo::Mundo& rhs);

	// EL NODO ENTREGADO DEBE SER DISTINTO DE NULL Y DEFINIDO.
	static bool decode(const Node& node, Modelo::Mundo& rhs);
};

} /* namespace YAML */

#endif /* SERIALIZACION_MUNDO_H_ */
