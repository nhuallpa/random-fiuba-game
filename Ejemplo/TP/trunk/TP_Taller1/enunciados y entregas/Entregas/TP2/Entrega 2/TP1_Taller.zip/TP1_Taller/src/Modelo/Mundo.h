#ifndef MUNDO_H_
#define MUNDO_H_

#include "Modelo/EntidadWrapper.h"
#include "Utils/Vec2.h"
#include <list>
#include <map>

namespace Modelo {

class Mundo {

public:
	Mundo();
//	Mundo(const Mundo& unMundo);
	Mundo& operator=(const Mundo& otroMundo);
	virtual ~Mundo();

	void agregarEntidad(EntidadWrapper unaEntidad);
	void quitarEntidad(EntidadWrapper unaEntidad);

	typedef std::list<EntidadWrapper>::iterator iterator;
	iterator begin();
	iterator end();

	typedef std::list<EntidadWrapper>::const_iterator const_iterator;
	const_iterator begin() const;
	const_iterator end() const;

	bool colicionaConAlgo(EntidadWrapper unaEntidad);

	EntidadWrapper buscarElemento(Vec2 punto);
	
	Mundo* copiaProfunda();

private:
	std::list<EntidadWrapper> contenido;

};


} /* namespace Modelo */

#endif /* MUNDO_H_ */
