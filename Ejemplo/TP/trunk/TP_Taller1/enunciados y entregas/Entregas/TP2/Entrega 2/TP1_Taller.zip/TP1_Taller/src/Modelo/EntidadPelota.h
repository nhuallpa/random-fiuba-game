/*
 * EntidadMovilPelota.h
 *
 *  Created on: Oct 12, 2013
 *      Author: rick
 */

#ifndef ENTIDADMOVILPELOTA_H_
#define ENTIDADMOVILPELOTA_H_

#include "Entidad.h"

namespace Modelo {


class EntidadPelota: public Modelo::Entidad {

public:
	EntidadPelota();
	explicit EntidadPelota (Modelo::TipoElemento clase, Vec2 centro = Vec2(0, 0),
			Vec2 tamanio = Vec2(0, 0), float angulo = 0.0f);
	virtual ~EntidadPelota();

	virtual bool esPelota() const;
	virtual bool esMovil() const;

};

} /* namespace Modelo */

#endif /* ENTIDADMOVILPELOTA_H_ */
