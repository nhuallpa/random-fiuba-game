#include "ModoEdicion.h"

#include "Log/Suceso.h"
#include "Modelo/Escenario.h"
#include "Modo/ModoSimulacion.h"
#include "Utils/make_unique.h"
#include "Vista/Boton.h"
#include "Vista/Botones/Guardar.h"
#include "Vista/Botones/Cargar.h"
#include "Vista/Botones/Salir.h"
#include "Vista/Botones/FlechaUp.h"
#include "Vista/Botones/FlechaDown.h"
#include "Vista/Canvas.h"
#include "Vista/Contenedor.h"
#include "Vista/ContenedorLayout.h"
#include "Vista/FiguraVista.h"
#include "Vista/FalsaFigura.h"
#include "Vista/FuentesPosicion/FuenteLayout.h"
#include "Vista/FuentesPosicion/FuenteModelo.h"
#include "Vista/FuentesPosicion/FuenteToolBar.h"
#include "Vista/FuentesPosicion/FuenteVentana.h"
#include "Vista/Imagen.h"
#include "Vista/ToolBar.h"
#include "Vista/Ventana.h"

namespace Modo {

void cargarToolBar (ToolBar* toolbar, Ventana* window) {
	for (Modelo::TipoElemento tipo : Modelo::listaTipoElemento) {
		FuenteToolBar fuente(toolbar);
		vista::FalsaFigura *falsa = new vista::FalsaFigura(fuente, tipo, window);
		toolbar->addElemento(falsa);
	}
}

ModoEdicion::ModoEdicion ()
	: window()
	, escenario()
	, pathEscenario()
	, izquierda()
	, cambioModo()
	, salir()
	, proximoEstado()
	, ultimoUpdate()
{
}

ModoEdicion::ModoEdicion (Ventana *ventana, Escenario *escenario, std::string pathEscenario)
	: window(ventana)
	, escenario(escenario)
	, pathEscenario(pathEscenario)
	, izquierda(nullptr)
	, cambioModo(nullptr)
	, salir(nullptr)
	, proximoEstado(EstadoJuego::edicion)
	, ultimoUpdate(0)
{
	// Creo el canvas con enlace al modelo
	FuenteLayout fuenteIzquierda;
	izquierda = new Canvas(fuenteIzquierda, window, escenario, Rect(0, 0, 10, 10));
	izquierda->setBackground(escenario->pathFondo, window);
	izquierda->setPermitirEliminaciones(true);

	// Creo y agrego vistas al toolbar
	FuenteLayout fuenteDerecha;
	ContenedorLayout *derecha = new ContenedorLayout(fuenteDerecha, window, false);
	derecha->setSeparacion(0.02);
	derecha->setBackground("imagenes/fondos/fondoGris.png", window);

	FuenteLayout fuenteCambio;
	cambioModo = new Boton(fuenteCambio,
		Imagen("imagenes/botones/play.png", window),
		[&proximoEstado] () {
			proximoEstado = EstadoJuego::simulacion;
		}
	);
	derecha->addElemento(cambioModo);

	FuenteLayout fuenteToolbar;
	ToolBar *toolbar = new ToolBar(fuenteToolbar, window, izquierda);
	toolbar->setBackground("imagenes/fondos/fondoBlanco.png", window);

	FuenteLayout fuenteBotonUp;
	Boton *botonUp = new FlechaUp(fuenteBotonUp, window, toolbar);
	derecha->addElemento(botonUp);

	cargarToolBar(toolbar, window);

	derecha->addElemento(toolbar);

	FuenteLayout fuenteBotonDown;
	Boton *botonDown = new FlechaDown(fuenteBotonDown, window, toolbar);
	derecha->addElemento(botonDown);

	FuenteLayout fuenteArriba;
	ContenedorLayout* contenedorArriba = new ContenedorLayout(fuenteArriba, window, true);
	contenedorArriba->setSeparacion(0.05);
	contenedorArriba->setBackground("imagenes/fondos/fondoGris.png", window);
	contenedorArriba->addElemento(izquierda);
	contenedorArriba->addElemento(derecha);

	// Creo y agrego botones al contenedor
	FuenteLayout fuenteTextbox;
	Textbox *vistaTextbox = new Textbox(fuenteTextbox, window, escenario->pathFondo);
	vistaTextbox->setRespuestaEnter([izquierda, window] (std::string texto) {
		izquierda->setBackground(texto, window);
	});

	FuenteLayout fuenteCargar;
	Cargar *vistaCargar = new Cargar(fuenteCargar, window, vistaTextbox);

	FuenteLayout fuenteGuardar;
	Guardar *vistaGuardar = new Guardar(fuenteGuardar, window, escenario, pathEscenario);

	FuenteLayout fuenteSalir;
	salir = new Salir(fuenteSalir, window);

	FuenteLayout fuenteAbajo;
	ContenedorLayout *contenedorAbajo = new ContenedorLayout(fuenteAbajo, window, true);
	contenedorAbajo->setSeparacion(0.02);
	contenedorAbajo->setBackground("imagenes/fondos/fondoGris.png", window);
	contenedorAbajo->addElemento(vistaTextbox);
	contenedorAbajo->addElemento(vistaCargar);
	contenedorAbajo->addElemento(vistaGuardar);
	contenedorAbajo->addElemento(salir);

	FuenteVentana fuenteVentana(window);
	ContenedorLayout *contenedorVentana = new ContenedorLayout(fuenteVentana, window, false);
	contenedorVentana->setSeparacion(0.02);
	contenedorVentana->setBackground("imagenes/fondos/fondoGris.png", window);
	contenedorVentana->addElemento(contenedorArriba);
	contenedorVentana->addElemento(contenedorAbajo, vista::PrioridadDibujo::barraAbajo);

	window->setRaiz(std::unique_ptr<Contenedor>(contenedorVentana));
}

ModoEdicion::ModoEdicion (ModoSimulacion&& origen)
	: window()
	, escenario()
	, pathEscenario()
	, izquierda()
	, cambioModo()
	, salir()
	, proximoEstado()
	, ultimoUpdate()
{
	ModoEdicion temp(std::move(origen.base));
	using std::swap;
	swap(*this, temp);
	proximoEstado = EstadoJuego::edicion;
	*cambioModo = Boton(*cambioModo->getFuente(),
		Imagen("imagenes/botones/play.png", window),
		[&proximoEstado] () {
			proximoEstado = EstadoJuego::simulacion;
		}
	);
}

ModoEdicion::~ModoEdicion()
{
}

EstadoJuego ModoEdicion::estado ()
{
	return EstadoJuego::edicion;
}

EstadoJuego ModoEdicion::iteracionPrincipal (float ms)
{
	ultimoUpdate += ms;
	if (ultimoUpdate > float(1000) / fps_deseado) {
		window->update();
		ultimoUpdate -= float(1000) / fps_deseado;
	}
	return proximoEstado;
}

std::unique_ptr<ModoJuego> ModoEdicion::transicion(EstadoJuego proximo)
{
	switch (proximo) {
	case EstadoJuego::simulacion:
		return make_unique<ModoSimulacion>(std::move(*this));
	case EstadoJuego::edicion:
		throw Log::Suceso(Log::DEBUG, "Cambio de modo invalido (Edicion->Edicion)");
	}
	throw Log::Suceso(Log::DEBUG, "Cambio de modo invalido (Edicion->?)");
}

} /* namespace Modo */
