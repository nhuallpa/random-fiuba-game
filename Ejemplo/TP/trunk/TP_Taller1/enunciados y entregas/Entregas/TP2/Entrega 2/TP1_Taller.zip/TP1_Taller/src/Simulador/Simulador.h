/*
 * Simulador.h
 *
 *  Created on: Oct 5, 2013
 *      Author: lucia
 */

#ifndef SIMULADOR_H_
#define SIMULADOR_H_
#include "../Modelo/Mundo.h"
#include "../Modelo/Entidad.h"
#include "Cuerpo.h"
#include <list>
#include <iostream>

namespace simulador {

class Simulador {
public:
	Simulador();
	//Se modelan todos los elementos del mundo para arrancar la simulación.
	bool inicializar(Modelo::Mundo* mundo);
	//Arranca la simulación.
	bool play();
	//Da un paso en la simulación.
	bool step();
	//Finaliza la simulacion.
	bool stop();
	bool destruir();
	virtual ~Simulador();
	void restaurar();

private:
	void modelarMundo(Modelo::Mundo* mundo);
	void modelarCuerpos(Modelo::Mundo* mundo);
	void modelarContactos();
	float32 timeStep;      //el tiempo entre simulaciones
	int32 velocityIterations;   //esto tiene que ver con cuantas iteraciones
	int32 positionIterations;

	b2World* m_mundo;
	//Lista de cuerpos que se va a recorrer y hacer vivir en
	//cada step del simulador.
	std::list<Cuerpo*> cuerpos;
	bool estaInicializado;
	bool estaCorriendo;
	Cuerpo* buscarCuerpo(Modelo::Entidad* entidad);
	void modelarContactosADistancia(std::list<Modelo::EntidadWrapper> uniones);
	void modelarCuerpoRotativoCinta(Modelo::EntidadWrapper entidad);
	void modelarCuerposRotativos(Modelo::EntidadWrapper entidad);
};

} /* namespace simulador */
#endif /* SIMULADOR_H_ */
