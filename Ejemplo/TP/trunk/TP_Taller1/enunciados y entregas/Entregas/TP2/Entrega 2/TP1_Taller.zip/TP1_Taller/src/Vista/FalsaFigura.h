#ifndef FALSAFIGURA_H_
#define FALSAFIGURA_H_

#include "Vista/Imagen.h"
#include "Vista/FiguraVista.h"
#include "Vista/Interfases/Elemento.h"

class FuentePosicion;

namespace vista {

// Recibe clicks como un rectangulo, clona como una FiguraVista arbitraria. Para la toolbar.
class FalsaFigura : public Elemento
{
public:
	FalsaFigura (const FuentePosicion& fuente, Modelo::TipoElemento tipo, Dibujable *dib);
	FalsaFigura (const FuentePosicion& fuente, FiguraVista real);
	FalsaFigura (const FuentePosicion& fuente, FiguraVista real, Imagen apariencia);

	FalsaFigura (const FalsaFigura&) = default;
	FalsaFigura (FalsaFigura&&) = default;
	FalsaFigura& operator= (const FalsaFigura&) = default;
	FalsaFigura& operator= (FalsaFigura&&) = default;
	virtual ~FalsaFigura();

	virtual void setSuperfice (const Rect& val);
	virtual void dibujarse (DestinoDibujo* window);
	virtual bool dirty ();

	virtual LayoutInfo getLayoutInfo ();

	virtual ClickInfo recibirClick (Vec2 pos);
	virtual Elemento* clonar () const;

private:
	Imagen imagen;
	FiguraVista real;
};

} /* namespace vista */
#endif /* FALSAFIGURA_H_ */
