/*
 * CintaTransportadora.cpp
 *
 *  Created on: 04/10/2013
 *      Author: stephanie
 */

#include "CintaTransportadora.h"
#include "../JointMaker.h"
#include "Engranaje.h"
#include <stdio.h>
#include <iostream>
#include <math.h>

namespace simulador {

CintaTransportadora::CintaTransportadora(b2Vec2 posInicial, b2World* mundo, b2Vec2 tam, Modelo::Entidad* entidad)
     : posicion(posInicial)
     , dimensiones(tam)
{
	this->posicionInicial = posInicial;
	this->impulso = 0;
	this->velocidad = 0;
	this->m_mundo = mundo;
	this->crearCinta(mundo);
	//el cuerpo es igual al engranaje central (?)
	this->cuerpo = rectArriba;//engranaje_Central->getCuerpo();
	this->entidad = entidad;
	this->conectadoACuerpo = NULL;
	this->engranajesSeteados = false;
	//cambio el userData
	this->cuerpo->SetUserData(this);
}

CintaTransportadora::~CintaTransportadora() {
	// TODO Auto-generated destructor stub
	m_mundo->DestroyBody(rectAbajo);
	m_mundo->DestroyBody(rectArriba);

}

void CintaTransportadora::crearCinta(b2World* mundo){
	float ancho = dimensiones.x;
	float alto = dimensiones.y;
	rectArriba = crearBox(posicion.x, posicion.y, ancho);
	rectAbajo = crearBox(posicion.x, posicion.y - alto*2, ancho);
    //b2Vec2 pos1(posicion.x - ancho + alto/2, posicion.y);
    b2Vec2 pos1(posicion.x - ancho + alto, posicion.y);
	gear1 = new Engranaje(pos1, m_mundo, 0, alto, true, false, entidad);
	//b2Vec2 pos2(posicion.x + ancho - alto/2, posicion.y);//-dimensiones.y);
	b2Vec2 pos2(posicion.x + ancho - alto, posicion.y);
	gear2 = new Engranaje(pos2, m_mundo, 0, alto, true, false, entidad);

}


b2Body* CintaTransportadora::crearBox(float x, float y, float ancho){
     b2FixtureDef fixture;
	 b2PolygonShape polygon;
	 //aca hago ancho - ancho/5 para que la plataforma se adapte mas a la figura
	 polygon.SetAsBox(ancho - dimensiones.y/2, 0);
	 fixture.shape = &polygon;
	 //Creo el cuerpo
	 b2BodyDef def;
	 def.type = b2_staticBody;
	 def.position.Set(x, y + dimensiones.y); //hago esta suma porque sino se crea muy abajo la plataforma ¬¬
	 	 	 	 	 //(x,y+o.5)	 	 	 //esto debido al setAsBox, por ese 0,00..01 que le pongo
	 	 	 	 	 	 	 	 //para que sea una plataforma super fina
	 b2Body* body = m_mundo->CreateBody(&def);
	 body->CreateFixture(&fixture);

	 return body;

}


void CintaTransportadora::vivir(){
	setearVelocidad();
	if (conectadoACuerpo){
		if (conectadoACuerpo->entidad->clase == Modelo::TipoElemento::Engranaje){
			if (conectadoACuerpo->cuerpo->GetAngularVelocity() > 0){ //van en sentido horario
				if (velocidad > 0)
					velocidad*=(-1);
				if (engranajesSeteados){
					gear1->getJoint()->SetMotorSpeed(-Constantes::Instancia()->motorSpeed);
					gear2->getJoint()->SetMotorSpeed(-Constantes::Instancia()->motorSpeed);
				}


			}else{
				if (velocidad < 0)
					velocidad*=(-1);
				if (engranajesSeteados){
					gear1->getJoint()->SetMotorSpeed(Constantes::Instancia()->motorSpeed);
					gear2->getJoint()->SetMotorSpeed(Constantes::Instancia()->motorSpeed);
				}
			}
		}
		engranajesSeteados = true;
	}
	modelarContacto();
}

void CintaTransportadora::modelarContacto(){
	for(b2Contact* contact = m_mundo->GetContactList(); contact; contact = contact->GetNext()){
		b2Body* a = contact->GetFixtureA()->GetBody();
		b2Body* b = contact->GetFixtureB()->GetBody();

		b2Vec2 aLinearVelocity = a->GetLinearVelocity();
		b2Vec2 bLinearVelocity = b->GetLinearVelocity();

		if (a == rectArriba){
            //impulso = velocidad/b->GetMass();
			//b->ApplyForceToCenter(b2Vec2(-velocidad,0));
			if (contact->IsTouching()){
	            b->SetLinearVelocity(b2Vec2(-velocidad,bLinearVelocity.y));
			}
		}
		if (b == rectArriba){
			//impulso = velocidad/a->GetMass();
			//a->ApplyForceToCenter(b2Vec2(-velocidad,0));
			if (contact->IsTouching()){
				a->SetLinearVelocity(b2Vec2(-velocidad,aLinearVelocity.y));
			}
		}

		if (a == rectAbajo){
			//impulso = velocidad/b->GetMass();
			//b->ApplyForceToCenter(b2Vec2(velocidad,0));
			if (contact->IsTouching()){
				b->SetLinearVelocity(b2Vec2(velocidad,bLinearVelocity.y));
			}
		}

		if (b == rectAbajo){
			//impulso = velocidad/a->GetMass();
			//a->ApplyForceToCenter(b2Vec2(velocidad,0));
			if (contact->IsTouching()){
				a->SetLinearVelocity(b2Vec2(velocidad,aLinearVelocity.y));
			}
		}
	}

}

void CintaTransportadora::setSentidoSegunCuerpoRotativo(CuerpoRotativo* cuerpoRotativo){
	conectadoACuerpo = cuerpoRotativo;
	gear1->getJoint()->EnableMotor(true);
	gear2->getJoint()->EnableMotor(true);

	conectadoACuerpo = cuerpoRotativo;

	if (cuerpoRotativo->getSentidoHorario()){
		gear1->setSentidoAntihorario(true);
		gear2->setSentidoHorario(false);
		gear1->getJoint()->SetMotorSpeed(-Constantes::Instancia()->motorSpeed);
		gear2->getJoint()->SetMotorSpeed(-Constantes::Instancia()->motorSpeed);

	}else{
		gear1->setSentidoAntihorario(false);
		gear2->setSentidoHorario(true);
		gear1->getJoint()->SetMotorSpeed(Constantes::Instancia()->motorSpeed);
		gear2->getJoint()->SetMotorSpeed(Constantes::Instancia()->motorSpeed);
	}
}

void CintaTransportadora::setearVelocidad(){
	if (conectadoACuerpo){
		velocidad = -conectadoACuerpo->getCuerpo()->GetAngularVelocity()*0.3;
	}
}
} /* namespace simulador */
