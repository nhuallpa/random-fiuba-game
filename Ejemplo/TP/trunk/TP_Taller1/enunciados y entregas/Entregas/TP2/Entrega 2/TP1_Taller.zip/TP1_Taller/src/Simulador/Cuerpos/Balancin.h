/*
 * Balancin.h
 *
 *  Created on: Oct 4, 2013
 *      Author: lucia
 */

#ifndef BALANCIN_H_
#define BALANCIN_H_
#include "../Cuerpo.h"

namespace simulador {

class Balancin: public Cuerpo {
public:
	Balancin(b2Vec2 dimensiones, b2Vec2 posInicial, float anguloIncial, b2World* mundo, Modelo::Entidad* entidad);
	virtual ~Balancin();
	void vivir();
//	void restaurarPos();
	void restaurarCuerpo();

private:
	b2Body* crearCuerpo(b2World* mundo);
	b2Body* crearSoporte(b2Body* plataforma, b2World* mundo);
	void crearJuntura(b2Body* plataforma, b2Body* soporte, b2World* mundo);
	b2Vec2 dimensiones;
	b2Body* soporte;
	float anguloInicial;
};

} /* namespace simulador */
#endif /* BALANCIN_H_ */
