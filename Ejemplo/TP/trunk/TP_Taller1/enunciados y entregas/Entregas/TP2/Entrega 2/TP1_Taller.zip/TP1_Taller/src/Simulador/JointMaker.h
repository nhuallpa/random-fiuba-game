/*
 * JointMaker.h
 *
 *  Created on: Oct 9, 2013
 *      Author: lucia
 */

#ifndef JOINTMAKER_H_
#define JOINTMAKER_H_
#include "Constantes.h"
namespace simulador {

class JointMaker {
public:
	static b2GearJoint* crearGearJoint(b2World* mundo, b2Body* bodyA, b2Body* bodyB,
			b2Joint* jointA, b2Joint* jointB, float ratio);
	//RECORDAR SIEMPRE PASAR EL SOPORTE PRIMERO PORQUE SI NO BOX2D CUANDO
	//HAGA EL GEAR JOINT NECESITA EL CUERPO ESTÁTICO COMO BODY A :(
	static b2RevoluteJoint* crearRevoluteJoint(b2World* mundo, b2Body* soporte,
				b2Body* cuerpo, bool habilitarMotor, float velocidadMotor, float maxTorque);

	static b2RevoluteJoint* crearRevoluteJoint(b2World* mundo, b2Body* soporte,
			b2Body* cuerpo, bool habilitarMotor, float velocidadMotor, float maxTorque, b2Vec2 anchor);
	static b2Body* crearEdge(b2Vec2 desde, b2Vec2 hasta, b2World* mundo);
};

} /* namespace simulador */
#endif /* JOINTMAKER_H_ */
