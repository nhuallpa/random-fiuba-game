/*
 * CuerpoRotativo.h
 *
 *  Created on: 08/10/2013
 *      Author: stephanie
 */

#ifndef CUERPOROTATIVO_H_
#define CUERPOROTATIVO_H_

#include "../Cuerpo.h"

namespace simulador {

class CuerpoRotativo: public simulador::Cuerpo {
public:
	CuerpoRotativo(b2Vec2 posInicial, b2World* mundo, float angulo,
			float radio,bool sentidoHorario, bool sentidoAntiHorario, bool isMotor, Modelo::Entidad* entidad);
	virtual ~CuerpoRotativo();
	virtual void setRadio(float radio);
	float getRadio();
	//Lo necesito para usar la correa
	virtual b2RevoluteJoint* getJoint();
	b2Body* getSoporte();

	bool getSentidoHorario();
	bool getSentidoAntihorario();
	void setSentidoHorario(bool sentido);
	void setSentidoAntihorario(bool sentido);

	virtual void setSentidoSegunCuerpoRotativo(CuerpoRotativo* cuerpoRotativo);
	virtual void restaurarCuerpo();

protected:
	b2RevoluteJoint* rJoint;
	b2Vec2 posicion;
	float angulo;
	float radio;
	b2Body* soporte;
	bool sentidoAntihorario;
	bool sentidoHorario;

	b2Body* crearCuerpo(b2World* mundo);
	b2Body* crearSoporte(b2World* mundo);
};

} /* namespace simulador */
#endif /* CUERPOROTATIVO_H_ */
