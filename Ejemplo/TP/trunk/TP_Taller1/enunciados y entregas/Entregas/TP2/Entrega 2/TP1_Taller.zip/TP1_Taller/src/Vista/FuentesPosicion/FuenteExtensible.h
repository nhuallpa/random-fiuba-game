/*
 * FuenteExtensible.h
 *
 *  Created on: Oct 13, 2013
 *      Author: lucia
 */

#ifndef FUENTEEXTENSIBLE_H_
#define FUENTEEXTENSIBLE_H_

#include "FuentePosicion.h"
#include "Utils/Rect.h"
#include "Modelo/EntidadWrapper.h"
#include <math.h>

class Canvas;

class FuenteExtensible : public FuentePosicion {
public:
	FuenteExtensible(Modelo::EntidadWrapper entidad, Canvas *canvas);

	Rect getSuperficie () const;
	void setSuperficie (const Rect& val);

	Vec2 getTamPadre () const;
	void padreResizeado (Vec2);

	float getAngulo () const;
	void setAngulo (float val);
	virtual FuentePosicion* clonar() const;

	Modelo::EntidadWrapper getEntidad();

	virtual ~FuenteExtensible();
private:
	Modelo::EntidadWrapper entidad;
	Canvas *canvas;
	float anchoLinea;
};

#endif /* FUENTEEXTENSIBLE_H_ */
