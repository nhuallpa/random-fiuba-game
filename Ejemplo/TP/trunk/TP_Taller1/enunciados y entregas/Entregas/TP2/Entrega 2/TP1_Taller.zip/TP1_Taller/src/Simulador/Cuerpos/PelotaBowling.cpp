/*
 * PelotaBowling.cpp
 *
 *  Created on: Oct 4, 2013
 *      Author: lucia
 */

#include "PelotaBowling.h"

namespace simulador {

PelotaBowling::PelotaBowling(b2Vec2 posInicial, b2World* mundo, float radio, Modelo::Entidad* entidad):
	Pelota(Constantes::Instancia()->coeficienteRestitucionPelotaBowling,
	Constantes::Instancia()->densidadPelotaBowling,
	radio,
	posInicial, mundo, entidad)
{
	//cambio el userData
	this->cuerpo->SetUserData(this);
}

PelotaBowling::~PelotaBowling() {
	// TODO Auto-generated destructor stub
}

} /* namespace simulador */
