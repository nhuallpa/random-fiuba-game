#include "Mundo.h"

#include "Entidad.h"
#include "Log/Suceso.h"
#include "Utils/Vec2.h"
#include "Utils/Rect.h"
#include "Modelo/TipoElemento.h"
#include <iostream>
#include <cstddef>

namespace Modelo {

Mundo::Mundo() : contenido() {
}


Mundo::~Mundo() {
	//TODO: el codigo elimina las entidades aun si siguen en uso
/*	while ( !this->contenido.empty() ) {
		delete this->contenido.front(),
		this->contenido.pop_front();
	}
*/
}


void Mundo::agregarEntidad (EntidadWrapper unaEntidad) {
	if ( this->colicionaConAlgo(unaEntidad) ) {
		Log::Suceso (Log::ERROR, "Se intento agregar una entidad que colisiona con otra.");
	}

	contenido.push_back(std::move(unaEntidad));
}


void Mundo::quitarEntidad (EntidadWrapper unaEntidad) {
	contenido.remove(unaEntidad);
}


Mundo::iterator Mundo::begin() {
	return contenido.begin();
}


Mundo::iterator Mundo::end() {
	return contenido.end();
}


Mundo::const_iterator Mundo::begin() const {
	return contenido.begin();
}


Mundo::const_iterator Mundo::end() const {
	return contenido.end();
}


bool Mundo::colicionaConAlgo(EntidadWrapper unaEntidad) {

	if (unaEntidad.esElementoPuente()) {
		return false;
	}

	for (auto& entidad : contenido) {
		if (entidad.esElementoPuente()) {
			continue;
		}
		if (unaEntidad.colicionaCon(entidad.base.get())) {
			return true;
		}
	}
	return false;
}


EntidadWrapper Mundo::buscarElemento(Vec2 punto) {
	for (auto& entidad : contenido) {
		Rect sup = Rect::deCentro(entidad.centro(), entidad.tamanio());
		if (sup.contiene(punto, entidad.angulo())) {
			return entidad;
		}
	}
	return EntidadWrapper();
}


Mundo& Mundo::operator =(const Mundo& otroMundo) {
	if (this == &otroMundo) {
		return *this;
	}

	contenido = otroMundo.contenido;

	return *this;
}


// http://stackoverflow.com/questions/12886036/deep-copying-a-graph-structure
Mundo* Mundo::copiaProfunda() {
	Mundo* nuevoMundo = new Mundo();
	std::map<Entidad*,Entidad*> mapaDeEntidades = std::map<Entidad*,Entidad*>();

	for (Modelo::Mundo::const_iterator iter = contenido.begin(); iter != contenido.end(); ++iter) {
		EntidadWrapper unaEntidad = *iter;
		//nuevoMundo->agregarEntidad(unaEntidad->copiaProfunda(mapaDeEntidades)));
	}

	return nuevoMundo;
}


} /* namespace Modelo */
