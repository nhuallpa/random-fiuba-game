/*
 * Correa.h
 *
 *  Created on: Oct 9, 2013
 *      Author: lucia
 */

#ifndef CORREA_H_
#define CORREA_H_
#include <Box2D/Box2D.h>
#include "../JointMaker.h"
#include "../Cuerpo.h"
#include "CuerpoRotativo.h"

namespace simulador {

class Correa: public simulador::Cuerpo {
public:
	//TODO no se usa.
	Correa(b2World* mundo, b2Body* cuerpo1, b2Body* cuerpo2,
			b2Joint* joint1, b2Joint* joint2, float ratio, Modelo::Entidad* entidad);
	Correa(b2World* mundo, Cuerpo* ca, Cuerpo* cb,
			float ratio, Modelo::Entidad* entidad);
	virtual ~Correa();
private:
	b2GearJoint* junturaEngranaje;
};

} /* namespace simulador */
#endif /* CORREA_H_ */
