/*
 * TipoElemento.h
 *
 *  Created on: Oct 11, 2013
 *      Author: lucia
 */

#ifndef TIPOELEMENTO_H_
#define TIPOELEMENTO_H_

#include <string>
#include <list>

namespace Modelo {

enum class TipoElemento
{
	PelotaBasquet,
	PelotaBowling,
	Globo,
	Plataforma,
	Balancin,
	Soga,
	Motor,
	Correa,
	Engranaje,
	CintaTransportadora,
};

extern std::list<TipoElemento> listaTipoElemento;

std::string tipoElementoToString (TipoElemento clase);
TipoElemento stringToTipoElemento (std::string clase);

} /* namespace Modelo */
#endif /* TIPOELEMENTO_H_ */
