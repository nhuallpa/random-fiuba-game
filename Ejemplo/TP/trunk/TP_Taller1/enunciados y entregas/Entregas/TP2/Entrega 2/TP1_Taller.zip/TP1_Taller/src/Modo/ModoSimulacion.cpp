#include "ModoSimulacion.h"

#include "Log/Suceso.h"
#include "Modelo/Escenario.h"
#include "Modo/ModoEdicion.h"
#include "Simulador/Constantes.h"
#include "Utils/make_unique.h"
#include "Vista/Boton.h"
#include "Vista/Contenedor.h"
#include "Vista/Imagen.h"
#include "Vista/Botones/Salir.h"
#include "Vista/FuentesPosicion/FuentePosicion.h"
#include "Vista/FuentesPosicion/FuenteFuncion.h"
#include <utility>

namespace Modo {

ModoSimulacion::ModoSimulacion ()
	: base()
	, raizOriginal(nullptr)
	, fondo(nullptr)
	, sim(nullptr)
	, proximoEstado(EstadoJuego::simulacion)
	, ultimoGrafico()
	, ultimaSimulacion()
{
}

ModoSimulacion::ModoSimulacion (ModoEdicion&& origen)
	: base(std::move(origen))
	, raizOriginal(base.window->extraerRaiz())
	, fondo(make_unique<Textura>(*base.window, base.window->tamDibujo()))
	, sim(new simulador::Simulador())
	, proximoEstado(EstadoJuego::simulacion)
	, ultimoGrafico(0)
	, ultimaSimulacion(0)
{
	sim->inicializar(&this->base.escenario->mundo);
	sim->play();

	//para las fuentes
	std::function<Vec2()> fnPadre = [&base] () -> Vec2 {
		return base.window->tamDibujo();
	};
	std::function<float()> fnAngulo = [] () -> float {
		return 0;
	};

	FuenteFuncion fuenteRaiz([&raizOriginal] () -> Rect {
		return raizOriginal->getSuperficie();
	}, fnAngulo, fnPadre);
	auto nuevaRaiz = make_unique<Contenedor>(fuenteRaiz, base.window);

	FuenteFuncion fuenteCambio([&base, &raizOriginal] () -> Rect {
		return raizOriginal->superficieAbsoluta(base.cambioModo).second;
	}, fnAngulo, fnPadre);
	Boton *nuevoCambio = new Boton(fuenteCambio,
		Imagen("imagenes/botones/stop.png", base.window),
		[&proximoEstado] () {
			proximoEstado = EstadoJuego::edicion;
		}
	);
	nuevaRaiz->addElemento(nuevoCambio);

	FuenteFuncion fuenteSalir([&base, &raizOriginal] () -> Rect {
		return raizOriginal->superficieAbsoluta(base.salir).second;
	}, fnAngulo, fnPadre);
	Boton *nuevoSalir = new Salir(fuenteSalir, base.window);
	nuevaRaiz->addElemento(nuevoSalir);

	base.window->setRaiz(std::move(nuevaRaiz));
}

ModoSimulacion::~ModoSimulacion()
{
	delete sim;
}

EstadoJuego ModoSimulacion::estado ()
{
	return EstadoJuego::simulacion;
}

EstadoJuego ModoSimulacion::iteracionPrincipal (float ms)
{
	ultimoGrafico += ms;
	if (ultimoGrafico > float(1000)/fps_deseado) {
		if (fondo == nullptr || fondo->tamDibujo() != base.window->tamDibujo()) {
			fondo = make_unique<Textura>(*base.window, base.window->tamDibujo());
		}
		raizOriginal->dibujarse(fondo.get());
		//TODO: oscurecer fondo
		base.window->getRaiz()->setBackground(std::move(fondo));

		base.window->update();
		ultimoGrafico -= float(1000)/fps_deseado;
	}

	ultimaSimulacion += ms;
	if (ultimaSimulacion > float(1000)/simulador::Constantes::Instancia()->iteracionesPorSegundo) {
		sim->step();
		ultimaSimulacion -= float(1000)/simulador::Constantes::Instancia()->iteracionesPorSegundo;
	}

	return proximoEstado;
}

std::unique_ptr<ModoJuego> ModoSimulacion::transicion(EstadoJuego proximo)
{
	base.window->setRaiz(std::move(raizOriginal));

	switch (proximo) {
	case EstadoJuego::simulacion:
		throw Log::Suceso(Log::DEBUG, "Cambio de modo invalido (Simulacion->Simulacion)");
	case EstadoJuego::edicion:
		sim->stop();
		return make_unique<ModoEdicion>(std::move(*this));
	}
	throw Log::Suceso(Log::DEBUG, "Cambio de modo invalido (Simulacion->?)");
}

} /* namespace Modo */
