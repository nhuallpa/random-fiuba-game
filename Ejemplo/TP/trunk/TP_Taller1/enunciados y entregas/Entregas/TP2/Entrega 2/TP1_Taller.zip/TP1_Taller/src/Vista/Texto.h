/*
 * Texto.h
 *
 *  Created on: 02/10/2013
 *  Last Amended: 02/10/2013
 *      Author: natuchis
 */

#ifndef TEXTO_H_
#define TEXTO_H_

#include "Interfases/OrigenDestinoDibujo.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "Textura.h"

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <memory>
#include <string>

class Texto: public OrigenDibujo {
public:
	Texto();
	Texto(const FuentePosicion& fuente, Dibujable* destino, std::string textoInicial);

	Texto (const Texto&) = delete;
	Texto (Texto&&) = default;
	Texto& operator= (const Texto&) = delete;
	Texto& operator= (Texto&&) = default;
	virtual ~Texto();

	virtual bool valido ();
	virtual SDL_Renderer* getRenderer ();
	virtual SDL_Texture* getTexture ();

	virtual void dibujarse(DestinoDibujo* destino);
	Vec2 tamDibujo () const;
	FuentePosicion *getFuente ();

	std::string getTexto();
	void setTexto(std::string unTexto);

	void limpiarTexto();

private:
	std::unique_ptr<FuentePosicion> fuente;
	Textura apariencia;
	TTF_Font* fuenteTexto;
	SDL_Color colorTexto;
	SDL_Color colorFondo;
	std::string texto;
	bool necesitaRegenerar;

	void regenerar();
	void setApariencia (Dibujable& destino);

};

#endif /* TEXTO_H_ */
