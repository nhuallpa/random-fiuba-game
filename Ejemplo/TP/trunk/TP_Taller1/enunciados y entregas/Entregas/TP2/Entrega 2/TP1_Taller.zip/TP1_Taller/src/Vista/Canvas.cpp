#include "Canvas.h"

#include "Utils/make_unique.h"
#include "Modelo/Entidad.h"
#include "Modelo/Mundo.h"
#include "Modelo/Escenario.h"
#include "Vista/FiguraVista.h"
#include "Vista/LayoutInfo.h"
#include "Vista/FuentesPosicion/FuenteModelo.h"
#include "Vista/FuentesPosicion/FuenteExtensible.h"
#include "Modelo/EntidadElementoPuente.h"

Canvas::Canvas (const FuentePosicion& fuente, Dibujable* destino, Escenario *escenario,
                const Rect& regionModelo)
	: Contenedor(fuente, destino)
	, escenario(escenario)
	, regionModelo(regionModelo)
{
	using Modelo::TipoElemento;
	std::list<Modelo::EntidadWrapper> elementosUniones;
	for (Modelo::EntidadWrapper entidad : escenario->mundo) {
		//TODO: cambiar por entidad.esElementoPuente
		if (entidad.clase() == TipoElemento::Soga || entidad.clase() == TipoElemento::Correa) {
			elementosUniones.push_back(entidad);
			continue;
		}

		FuenteModelo nFuente(entidad, this);
		FiguraVista *nFig = new FiguraVista(entidad.clase(), nFuente, destino);
		this->addElemento(nFig);
	}

	//Las sogas y correas se modelan después que todos los cuerpos.
	for (Modelo::EntidadWrapper entidad : elementosUniones) {
		FuenteExtensible nFuente(entidad, this);
		Modelo::EntidadWrapper entidad1 = escenario->mundo.buscarElemento(entidad.puntoDeLigaduraEntidadA());
		Modelo::EntidadWrapper entidad2 = escenario->mundo.buscarElemento(entidad.puntoDeLigaduraEntidadB());
		if (entidad.vincular(entidad1, entidad2, entidad.puntoDeLigaduraEntidadA(), entidad.puntoDeLigaduraEntidadB())) {
			FiguraVista *nFig = new FiguraVista(entidad.clase(), nFuente, destino);
			elementosPuente.push_back(nFig);
			if(entidad.clase() == Modelo::TipoElemento::Soga) {
				this->addElemento(nFig, vista::PrioridadDibujo::soga);
			} else {
				this->addElemento(nFig);
			}
		}
	}
}

Canvas::~Canvas ()
{
}

Vec2 Canvas::tamUnidadLogica() const
{
	return getSuperficie().tam() / regionModelo.tam();
}

LayoutInfo Canvas::getLayoutInfo()
{
	return LayoutInfo(Vec2(100, 100), Vec2(100, 100), true, true, true);
}

bool Canvas::recibirFigura (const FiguraVista *figura, Vec2, vista::PrioridadDibujo prioridad)
{
	FiguraVista *nFigura = new FiguraVista(*figura);

	Rect supFiguraVista = figura->getSuperficie();
	Rect regionVista = this->getSuperficie();
	Rect supFiguraModelo = supFiguraVista.cambioCoordenadas(regionVista, regionModelo);

	Modelo::EntidadWrapper nEntidad(nFigura->getClase(), supFiguraModelo.centro(),
	                                supFiguraModelo.tam(), 0.0);
	nEntidad.angulo() = nFigura->getFuente()->getAngulo();

	if(!escenario->mundo.colicionaConAlgo(nEntidad)) {
		FuentePosicion* nFuente = new FuenteModelo(nEntidad, this);
		nFuente->setAngulo(nFigura->getFuente()->getAngulo());

		escenario->mundo.agregarEntidad(nEntidad);
		nFigura->setFuente(nFuente);

		this->addElemento(nFigura, prioridad);
	}

	return true;
}

bool Canvas::recibirElementoPuente(FiguraVista *figura, Vec2 extremoA, Vec2 extremoB, vista::PrioridadDibujo prioridad) {
	Rect regionVista = this->getSuperficie();
	Vec2 puntoAmodelo = extremoA.cambioCoordenadas(regionVista, regionModelo);
	Vec2 puntoBmodelo = extremoB.cambioCoordenadas(regionVista, regionModelo);
	Modelo::EntidadWrapper e1 = escenario->mundo.buscarElemento(puntoAmodelo);
	Modelo::EntidadWrapper e2 = escenario->mundo.buscarElemento(puntoBmodelo);
	if(e1==e2){
		return false;
	}

	Rect supFiguraVista = figura->getSuperficie();
	Rect supFiguraModelo = supFiguraVista.cambioCoordenadas(regionVista, regionModelo);

	FiguraVista *nFigura = new FiguraVista(*figura);
	Modelo::EntidadWrapper nUnion(nFigura->getClase(), supFiguraModelo.centro(),
			                                supFiguraModelo.tam(), 0.0);

	if (nUnion.vincular(e1, e2, puntoAmodelo, puntoBmodelo)) {
		FuentePosicion* nFuente = new FuenteExtensible(nUnion, this);

		escenario->mundo.agregarEntidad(nUnion);
		nFigura->setFuente(nFuente);
		this->elementosPuente.push_back(nFigura);
		if (nUnion.esElementoPuente()) {
			this->addElemento(nFigura, vista::PrioridadDibujo::soga);
		} else {
			this->addElemento(nFigura, prioridad);
		}
	}
	return true;
}

bool Canvas::aEliminar (Vec2 posicionRespectoPadre){
	auto elemento = buscar_base(posicionRespectoPadre);
	if (elemento != nullptr) {
		Vec2 posicion = posicionRespectoPadre - fuente->getSuperficie().origen();
		if (elemento->aEliminar(posicion) && permitirEliminaciones) {
			FuentePosicion *fuente = elemento->getFuente();
			FuenteModelo *fuenteCasteada = dynamic_cast<FuenteModelo*>(fuente);
			if(fuenteCasteada->getEntidad().tieneElemPuenteAtado()) {
				std::list<Modelo::Entidad*> elementosPuenteEnlazados = fuenteCasteada->getEntidad().desenlazarElemPuente();
				for(Modelo::Entidad* elemPuente: elementosPuenteEnlazados){
					Modelo::EntidadWrapper elemPuenteWrapper;
					std::shared_ptr<Modelo::Entidad> ent(elemPuente);
					elemPuenteWrapper.base=ent;
					FiguraVista* unionVista = findUnion(elemPuenteWrapper);
					escenario->mundo.quitarEntidad(elemPuenteWrapper);
					quitarElemento(unionVista);
				}
			}
			escenario->mundo.quitarEntidad(fuenteCasteada->getEntidad());
			quitarElemento(elemento);
		}
	}
	return false;
}

FiguraVista* Canvas::findUnion(Modelo::EntidadWrapper entidadPuente){
	for(FiguraVista* elemento : elementosPuente) {
		FuenteExtensible *fuenteCasteada = dynamic_cast<FuenteExtensible*>(elemento->getFuente());
		if(entidadPuente.base.get() == fuenteCasteada->getEntidad().base.get()){
			return elemento;
		}
	}
	return nullptr;
}

void Canvas::setBackground(std::string filename, DestinoDibujo* destino){
	Contenedor::setBackground(filename, destino);
	escenario->pathFondo = filename;
}

Rect Canvas::getRegionModelo () {
	return regionModelo;
}
