#ifndef MODOJUEGO_H_
#define MODOJUEGO_H_

#include <memory>

namespace Modo {

enum class EstadoJuego : int
{
	edicion,
	simulacion,
};

class ModoJuego
{
public:
	virtual ~ModoJuego() {};

	// devuelve el estado actual de juego
	virtual EstadoJuego estado () = 0;
	// realiza una iteracion de su ciclo principal correspondiente a un tiempo dt
	// devuelve el proximo estado de juego
	virtual EstadoJuego iteracionPrincipal (float ms) = 0;
	// invalida la interfaz sobre la que se llama
	virtual std::unique_ptr<ModoJuego> transicion(EstadoJuego proximo) = 0;
};

} /* namespace Modo */
#endif /* MODOJUEGO_H_ */
