/*
 * EntidadNoMovilElementoPuente.h
 *
 *  Created on: Oct 12, 2013
 *      Author: rick
 */

#ifndef ENTIDADNOMOVILELEMENTOPUENTE_H_
#define ENTIDADNOMOVILELEMENTOPUENTE_H_

#include "Entidad.h"

namespace Modelo {


class EntidadElementoPuente: public Modelo::Entidad {

public:
	EntidadElementoPuente();
	explicit EntidadElementoPuente (Modelo::TipoElemento clase, Vec2 centro = Vec2(0, 0),
			Vec2 tamanio = Vec2(0, 0), float angulo = 0.0f);
	explicit EntidadElementoPuente(Modelo::TipoElemento clase, Entidad* entidadEnlazadaA, Vec2 puntoLigaduraA,
			Entidad* entidadEnlazadaB = NULL, Vec2 puntoLigaduraB = Vec2(0, 0));
	virtual ~EntidadElementoPuente();

	// Soga y correa no colisionan con otros objetos
	virtual bool colicionaCon(Entidad* otraEntidad) const;

	virtual bool esElementoPuente() const;
	virtual bool esNoMovil() const;

	virtual bool tieneLosDosExtremosLibres() const;
	virtual bool tieneUnExtremoLibre() const;
	virtual bool puedeUnirseA(Entidad* unaEntidad) const;

};


} /* namespace Modelo */

#endif /* ENTIDADNOMOVILELEMENTOPUENTE_H_ */
