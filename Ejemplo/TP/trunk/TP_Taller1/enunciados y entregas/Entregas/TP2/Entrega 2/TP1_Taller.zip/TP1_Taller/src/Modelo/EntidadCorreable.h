/*
 * EntidadCorreable.h
 *
 *  Created on: Oct 13, 2013
 *      Author: rick
 */

#ifndef ENTIDADCORREABLE_H_
#define ENTIDADCORREABLE_H_

#include "Entidad.h"

namespace Modelo {


class EntidadCorreable: public Modelo::Entidad {

public:
	EntidadCorreable();
	explicit EntidadCorreable (Modelo::TipoElemento clase, Vec2 centro = Vec2(0, 0),
			Vec2 tamanio = Vec2(0, 0), float angulo = 0.0f);
	virtual ~EntidadCorreable();

	virtual bool esCorreable() const;
	virtual bool esNoMovil() const;
	virtual bool tieneElemPuenteAtado() const;

	virtual std::list<Vec2> lugarDondeSePuedeUnirBase() const;

};


} /* namespace Modelo */

#endif /* ENTIDADCORREABLE_H_ */
