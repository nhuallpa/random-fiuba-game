/*
 * Globo.cpp
 *
 *  Created on: Oct 13, 2013
 *      Author: rick
 */

#include "Globo.h"

namespace Modelo {

Globo::Globo()
	: Modelo::EntidadSogeable()
{
}


Globo::Globo(Modelo::TipoElemento clase, Vec2 centro, Vec2 tamanio, float angulo)
	: Modelo::EntidadSogeable(clase, centro, tamanio, angulo)
{
}


Globo::~Globo() {
	for(Entidad* puente: this->elemPuenteAtado){
		if ( puente != NULL ) {
			if ( puente->entidadExtremoA == this ) {
				puente->entidadExtremoA = NULL;
				puente->puntoDeLigaduraEntidadA = Vec2();
			}

			if ( puente->entidadExtremoB == this ) {
				puente->entidadExtremoB = NULL;
				puente->puntoDeLigaduraEntidadB = Vec2();
			}
		}
	}
}


bool Globo::esMovil() const {
	return true;
}


std::list<Vec2> Globo::lugarDondeSePuedeUnirBase() const {
	std::list<Vec2> lista;
	lista.push_back(centro - Vec2(0, 0.4) * tamanio); // punto central inferior
	return lista;
}


} /* namespace Modelo */
