/*
 * EntidadNoMovilElementoPuente.cpp
 *
 *  Created on: Oct 12, 2013
 *      Author: rick
 */

#include "EntidadElementoPuente.h"
#include "Log/Logger.h"
#include "Log/Suceso.h"

namespace Modelo {

EntidadElementoPuente::EntidadElementoPuente()
	: Modelo::Entidad()
{
}


EntidadElementoPuente::EntidadElementoPuente(Modelo::TipoElemento clase, Vec2 centro, Vec2 tamanio, float angulo)
	: Modelo::Entidad(clase, centro, tamanio, angulo)
{
}


EntidadElementoPuente::EntidadElementoPuente(Modelo::TipoElemento clase, Entidad* entidadEnlazadaA, Vec2 puntoLigaduraA, Entidad* entidadEnlazadaB, Vec2 puntoLigaduraB)
	: Modelo::Entidad(clase, Vec2(0, 0), Vec2(0, 0), 0.0f)
{
	if (clase == Modelo::TipoElemento::Soga) {
		if (entidadEnlazadaA != NULL) {
			if ( entidadEnlazadaA->esSogeable() ) {
				this->entidadExtremoA = entidadEnlazadaA;
				this->puntoDeLigaduraEntidadA = puntoLigaduraA;
			}
			else {
				Log::Suceso (Log::ERROR, "Se ha pasado una clase no sogeable al constructor de una soga.");
			}
		}

		if (entidadEnlazadaB != NULL) {
			if ( entidadEnlazadaB->esSogeable() ) {
				this->entidadExtremoB = entidadEnlazadaB;
				this->puntoDeLigaduraEntidadB = puntoLigaduraB;
			}
			else {
				Log::Suceso (Log::ERROR, "Se ha pasado una clase no sogeable al constructor de una soga.");
			}
		}
	}

	if (clase == Modelo::TipoElemento::Correa) {
		if (entidadEnlazadaA != NULL) {
			if ( entidadEnlazadaA->esCorreable() ) {
				this->entidadExtremoA = entidadEnlazadaA;
				this->puntoDeLigaduraEntidadA = puntoLigaduraA;
			}
			else {
				Log::Suceso (Log::ERROR, "Se ha pasado una clase no correable al constructor de una correa.");
			}
		}

		if (entidadEnlazadaB != NULL) {
			if ( entidadEnlazadaB->esCorreable() ) {
				this->entidadExtremoB = entidadEnlazadaB;
				this->puntoDeLigaduraEntidadB = puntoLigaduraB;
			}
			else {
				Log::Suceso (Log::ERROR, "Se ha pasado una clase no correable al constructor de una correa.");
			}
		}
	}

	throw Log::Suceso(Log::ERROR, "Clase incorrecta para constructor de entidad elemento puente.");
}


EntidadElementoPuente::~EntidadElementoPuente() {
	if ( this->entidadExtremoA != NULL ) {
		this->entidadExtremoA->elemPuenteAtado.remove(this);
	}

	if ( this->entidadExtremoB != NULL ) {
		this->entidadExtremoB->elemPuenteAtado.remove(this);
	}
}


bool EntidadElementoPuente::colicionaCon(Entidad* otraEntidad) const {
	(void)otraEntidad;	// unused parameter
	return false;
}


bool EntidadElementoPuente::esElementoPuente() const {
	return true;
}


bool EntidadElementoPuente::esNoMovil() const {
	return true;
}


bool EntidadElementoPuente::tieneLosDosExtremosLibres() const {
	if (this->entidadExtremoA == NULL  and  this->entidadExtremoB == NULL) {
		return true;
	}
	return false;
}


bool EntidadElementoPuente::tieneUnExtremoLibre() const {
	if (this->entidadExtremoA == NULL  or  this->entidadExtremoB == NULL) {
		return true;
	}
	return false;
}


bool EntidadElementoPuente::puedeUnirseA(Entidad* unaEntidad) const {

	if (this->clase == Modelo::TipoElemento::Soga) {
		if ( this->tieneUnExtremoLibre()  &&  unaEntidad->esSogeable() ) {
			return true;
		}
		return false;
	}

	if (this->clase == Modelo::TipoElemento::Correa) {
		if ( this->tieneUnExtremoLibre()  &&  unaEntidad->esCorreable() ) {
			return true;
		}
		return false;
	}

	throw Log::Suceso(Log::ERROR, "Elemento puente que no es soga ni correa.");
}


} /* namespace Modelo */
