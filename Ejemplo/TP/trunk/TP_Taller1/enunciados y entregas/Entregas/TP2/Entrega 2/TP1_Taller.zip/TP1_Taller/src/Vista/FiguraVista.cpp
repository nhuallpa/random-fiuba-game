/*
 * Figura.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: lucia
 */

#include "FiguraVista.h"

#include "ClickInfo.h"
#include "Imagen.h"
#include "LayoutInfo.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "FuentesPosicion/FuenteModelo.h"
#include "Vista/InfoFiguras.h"
#include "Log/Suceso.h"
#include "Utils/Rect.h"
#include "Modelo/Constantes.h"
#include "Modelo/EntidadWrapper.h"
#include <cmath>
#include <vector>

std::map<Modelo::TipoElemento, FiguraVista> FiguraVista::prototipos;

FiguraVista::FiguraVista ()
	: vista::Elemento()
	, imagen()
	, pathImagen("")
	, clase()
{
}

FiguraVista::FiguraVista (Modelo::TipoElemento tipo, const FuentePosicion& fuente,
	                  Dibujable *destino)
	: vista::Elemento(fuente)
	, imagen()
	, pathImagen()
	, clase(tipo)
{
	if (prototipos.empty()) {
		construirPrototipos();
	}
	pathImagen = prototipos[tipo].pathImagen;
	imagen = Imagen(pathImagen, destino);
	if (clase == Modelo::TipoElemento::CintaTransportadora) {
		this->verificarImagenSegunTamanio();
	}

	radioActual = Modelo::Constantes::radioEngranajeL;
	anguloActual = 0;
	if (clase == Modelo::TipoElemento::Motor) {
		FuenteModelo *fuenteActual = dynamic_cast<FuenteModelo*>(this->getFuente());
		if (fuenteActual != nullptr) {
			Modelo::EntidadWrapper entidadActual = fuenteActual->getEntidad();
			sentidoHorario = entidadActual.sentidoHorario();
			this->verificarImagenSegunGiro();
		}
	}
}

FiguraVista::~FiguraVista() {
}

void FiguraVista::dibujarse(DestinoDibujo* window) {
	//Acordarse que las posiciones de los elementos que guardamos
	//siempre son relativas a la posicion del contenedor.
	imagen.dibujar(*window, *fuente);
}

void FiguraVista::setSuperfice(const Rect& val){
	this->fuente->setSuperficie(val);
}

LayoutInfo FiguraVista::getLayoutInfo(){
	return LayoutInfo(imagen.tamDibujo());
}

bool FiguraVista::contiene(Vec2 punto) {
	Vec2 puntoParalelo = punto - fuente->getSuperficie().origen() - fuente->getSuperficie().tam() / 2;

	Vec2 puntoRotado = puntoParalelo.rotar(fuente->getAngulo());

	Rect sistemaLocal = Rect::deCentro(Vec2(), fuente->getSuperficie().tam());
	Rect sistemaImagen(Vec2(), imagen.tamDibujo());
	Vec2 puntoImagen = puntoRotado.cambioCoordenadas(sistemaLocal, sistemaImagen);
	return !imagen.esTransparente(puntoImagen);
}

vista::ClickInfo FiguraVista::recibirClick(Vec2 pos) {
	vista::ClickInfo retval(this, pos);
	if (clase == Modelo::TipoElemento::Soga || clase == Modelo::TipoElemento::Correa) {
		retval.puedeArrastrar = false;
	} else {
		retval.puedeArrastrar = true;
	}

	if (clase == Modelo::TipoElemento::Plataforma) {
		retval.puedeRotar = true;
	} else {
		retval.puedeRotar = false;
	}

	if (clase == Modelo::TipoElemento::Plataforma || clase == Modelo::TipoElemento::CintaTransportadora) {
		retval.puedeResizear = true;
	} else {
		retval.puedeResizear = false;
	}

	if (clase == Modelo::TipoElemento::PelotaBasquet || clase == Modelo::TipoElemento::PelotaBowling ||
			clase == Modelo::TipoElemento::Correa || clase == Modelo::TipoElemento::Plataforma ||
			clase == Modelo::TipoElemento::Soga) {
		retval.puedeUnirse = false;
	} else {
		retval.puedeUnirse = true;
	}
	return retval;
}

void FiguraVista::mover(Vec2 incremento) {
	fuente->setSuperficie(fuente->getSuperficie() + incremento);
}

void FiguraVista::rotar(Vec2 respectoA) {
	//Calculo el angulo de rotacion
	this->fuente->setAngulo(this->getAnguloRotacion(respectoA));
}

bool FiguraVista::aEliminar (Vec2) {
	return true;
}

void FiguraVista::resizear(Vec2 respectoA) {
	Rect sup(fuente->getSuperficie());
	sup.setTam(Vec2(sup.tam() + Vec2(1,0)*respectoA));
	this->fuente->setSuperficie(sup);
	if (clase == Modelo::TipoElemento::CintaTransportadora) {
		this->verificarImagenSegunTamanio();
	}
}

void FiguraVista::cambiarForma() {
	if (clase == Modelo::TipoElemento::Engranaje) {
		this->ciclarEntreRadios();
	} else if (clase == Modelo::TipoElemento::Motor) {
		this->ciclarEntreGiros();
	} else if (clase == Modelo::TipoElemento::Balancin) {
		this->ciclarEntreAngulos();
	}
}

const std::map<Modelo::TipoElemento, FiguraVista>& FiguraVista::getPrototipos() {
	if (prototipos.empty()) {
		construirPrototipos();
	}
	return prototipos;
}

Modelo::TipoElemento FiguraVista::getClase(){
	return this->clase;
}

double FiguraVista::getAnguloRotacion(Vec2 respectoA){
	Vec2 posMouse = respectoA;
	double distX = posMouse.x - this->fuente->getSuperficie().centro().x ;
	double distY = posMouse.y - this->fuente->getSuperficie().centro().y ;
	double result = atan2(distY,distX) * 180 / M_PI;
	return result;
}

vista::Elemento* FiguraVista::clonar() const{
	return new FiguraVista(*this);
}

void FiguraVista::construirPrototipos(){
	using Modelo::TipoElemento;
	for (auto& par : vista::InfoFiguras::datos) {
		prototipos[par.first] = FiguraVista(par.second.pathImagenCanvas, par.first);
	}
}

FiguraVista::FiguraVista(std::string pathImagen, Modelo::TipoElemento clase)
	: vista::Elemento()
	, imagen()
	, pathImagen(pathImagen)
	, clase(clase)
{
}

void FiguraVista::finalizar(){
	prototipos.clear();
}

void FiguraVista::ciclarEntreRadios() {
	FuenteModelo *fuenteActual = dynamic_cast<FuenteModelo*>(fuente.get());
	if (fuenteActual != nullptr) {
		Modelo::EntidadWrapper entidadActual = fuenteActual->getEntidad();

		if (radioActual == Modelo::Constantes::radioEngranajeL) {
			radioActual = Modelo::Constantes::radioEngranajeM;
		}
		else if (radioActual == Modelo::Constantes::radioEngranajeM) {
			radioActual = Modelo::Constantes::radioEngranajeS;
		}
		else if (radioActual == Modelo::Constantes::radioEngranajeS) {
			radioActual = Modelo::Constantes::radioEngranajeL;
		}
		entidadActual.tamanio() = Vec2(2*radioActual, 2*radioActual);
	}
}

void FiguraVista::ciclarEntreAngulos()  {
	FuenteModelo *fuenteActual = dynamic_cast<FuenteModelo*>(fuente.get());
	if (fuenteActual != nullptr) {
		Modelo::EntidadWrapper entidadActual = fuenteActual->getEntidad();

		auto iniciales = entidadActual.lugarDondeSePuedeUnir();
		std::vector<Vec2> puntosIniciales(begin(iniciales), end(iniciales));

		if (anguloActual <= 0) {
			anguloActual = 45;
		} else {
			anguloActual = -45;
		}
		entidadActual.angulo() = anguloActual;

		auto finales = entidadActual.lugarDondeSePuedeUnir();
		std::vector<Vec2> puntosFinales(begin(finales), end(finales));

		auto vinculos = entidadActual.elemPuenteAtado();
		for (Modelo::Entidad* vinculo : vinculos) {
			for (unsigned i = 0; i < puntosIniciales.size(); ++i) {
				if (vinculo->puntoDeLigaduraEntidadA == puntosIniciales[i]) {
					vinculo->puntoDeLigaduraEntidadA = puntosFinales[i];
				}
				if (vinculo->puntoDeLigaduraEntidadB == puntosIniciales[i]) {
					vinculo->puntoDeLigaduraEntidadB = puntosFinales[i];
				}
				vinculo->regenerar();
			}
		}
	}
}

void FiguraVista::ciclarEntreGiros() {
	FuenteModelo *fuenteActual = dynamic_cast<FuenteModelo*>(fuente.get());
	if (fuenteActual != nullptr) {
		Modelo::EntidadWrapper entidadActual = fuenteActual->getEntidad();
		sentidoHorario = !sentidoHorario;
		this->verificarImagenSegunGiro();
		entidadActual.sentidoHorario() = sentidoHorario;
	}
}

void FiguraVista::cambiarImagen(std::string path){
	imagen = Imagen(path, &imagen);
}

void FiguraVista::verificarImagenSegunTamanio() {
	float anchoFig = fuente->getSuperficie().tam().x;
	float diametro = fuente->getSuperficie().tam().y;
	std::string pathTemp;
	if (anchoFig <= (2*diametro)) {
		pathTemp = "imagenes/objetos/cinta0.png";
	} else if (anchoFig <= (3*diametro)) {
		pathTemp = "imagenes/objetos/cinta1.png";
	} else if (anchoFig <= (4*diametro)) {
		pathTemp = "imagenes/objetos/cinta2.png";
	} else if (anchoFig <= (5*diametro)) {
		pathTemp = "imagenes/objetos/cinta3.png";
	} else if (anchoFig <= (6*diametro)) {
		pathTemp = "imagenes/objetos/cinta4.png";
	} else if (anchoFig <= (7*diametro)) {
		pathTemp = "imagenes/objetos/cinta5.png";
	} else if (anchoFig <= (8*diametro)) {
		pathTemp = "imagenes/objetos/cinta6.png";
	} else if (anchoFig <= (9*diametro)) {
		pathTemp = "imagenes/objetos/cinta7.png";
	} else if (anchoFig <= (10*diametro)) {
		pathTemp = "imagenes/objetos/cinta8.png";
	} else if (anchoFig <= (11*diametro)) {
		pathTemp = "imagenes/objetos/cinta9.png";
	} else if (anchoFig <= (12*diametro)) {
		pathTemp = "imagenes/objetos/cinta10.png";
	} else if (anchoFig <= (13*diametro)) {
		pathTemp = "imagenes/objetos/cinta11.png";
	} else if (anchoFig <= (14*diametro)) {
		pathTemp = "imagenes/objetos/cinta12.png";
	} else {
		pathTemp = "imagenes/objetos/cinta13.png";
	}

	if (pathImagen != pathTemp) {
		this->cambiarImagen(pathTemp);
	}
}

void FiguraVista::verificarImagenSegunGiro() {
	if (sentidoHorario) {
		this->cambiarImagen("imagenes/objetos/motorRaton.png");
	} else {
		this->cambiarImagen("imagenes/objetos/motorRatonEspejado.png");
	}
}
