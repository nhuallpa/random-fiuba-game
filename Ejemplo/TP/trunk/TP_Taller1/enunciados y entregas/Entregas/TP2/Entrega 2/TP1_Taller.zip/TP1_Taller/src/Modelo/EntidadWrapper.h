#ifndef ENTIDADWRAPPER_H_
#define ENTIDADWRAPPER_H_

#include "Modelo/Entidad.h"
#include <memory>

namespace Modelo {

class EntidadWrapper
{
public:
	EntidadWrapper();
	explicit EntidadWrapper(TipoElemento clase, Vec2 centro = Vec2(0, 0),
	                  Vec2 tamanio = Vec2(0, 0), float angulo = 0.0f);

	EntidadWrapper (const EntidadWrapper&) = default;
	EntidadWrapper (EntidadWrapper&&) = default;
	EntidadWrapper& operator= (const EntidadWrapper&) = default;
	EntidadWrapper& operator= (EntidadWrapper&&) = default;
	~EntidadWrapper() = default;

	// La soga y la correa son los unicos que no colisionan con otras entidades.
	bool colicionaCon(Entidad* otraEntidad) const;

	// Aca sigue una serie de checkeos booleanos, que en principio todas retornan "false".
	// En cada clase heredada, en las cuales correspondan y se apliquen, retornara "true".
	bool esMovil() const;		// pelotaBasquet, pelotaBowling, globo
	bool esNoMovil() const;		// plataforma, soga, balancin, engranaje, motor, correa, cinta

	bool esElementoPuente() const;	// EntidadElementoPuente: 	correa, soga					(1)
	bool esSogeable() const;		// EntidadSogeable:			globo, balancin					(2)
	bool esCorreable() const;		// EntidadCorreable:		engranaje, motor, cinta			(3)
	bool esPelota() const;			// EntidadPelota:			pelotaBasquet, pelotaBowling	(4)

	// (1) Para soga y correa:
	bool tieneLosDosExtremosLibres() const;
	bool tieneUnExtremoLibre() const;
	bool puedeUnirseA(Entidad* unaEntidad) const;
	bool vincular(EntidadWrapper, EntidadWrapper, Vec2 a = Vec2(0,0), Vec2 b = Vec2(0,0));

	// (2) (3) Para globo y balancin, como tambien engranaje, motor y cinta:
	bool tieneElemPuenteAtado() const;

	// (2) (3) Devuelve el punto en donde el objeto se puede unirse a una soga o una correa (segun corresponda).
	// Devuelve "pares" de Vec2, en donde el primero es la posicion (centro), y el segundo el tamanio.
	// Lista vacia seria que no se puede unirse.
	// No checkea si el objeto ya esta unido a algo.
	std::list<Vec2> lugarDondeSePuedeUnir() const;

	bool& sentidoHorario() const;

	// (2) (3) Si hay soga o correa unida, elimina la union en la entidad enlazada, y devuelve el elmento puente unido.
	std::list<Entidad*> desenlazarElemPuente();

	bool operator== (EntidadWrapper rhs) const;

	// accesores de atributos
	Modelo::TipoElemento& clase();
	Modelo::TipoElemento clase() const;
	Vec2& centro();  // (x, y)
	Vec2 centro() const;
	Vec2& tamanio(); // (ancho, alto)
	Vec2 tamanio() const;
	float& angulo(); // Para plataforma (en grados)
	float angulo() const;
	float radio() const;

	// (1) Para soga y correa: objetos atados
	Entidad*& entidadExtremoA();
	const Entidad* entidadExtremoA() const;
	Entidad*& entidadExtremoB();
	const Entidad* entidadExtremoB() const;
	// (1) Para soga y correa: en qué punto de los objetos esta atado el elemento puente
	Vec2& puntoDeLigaduraEntidadA();
	Vec2 puntoDeLigaduraEntidadA() const;
	Vec2& puntoDeLigaduraEntidadB();
	Vec2 puntoDeLigaduraEntidadB() const;

	// (2) (3) Para globo y balancin, como tambien engranaje, motor y cinta:
	std::list<Entidad*>& elemPuenteAtado();
	const std::list<Entidad*> elemPuenteAtado() const;

//private:
	std::shared_ptr<Entidad> base;
};

} /* namespace Modelo */
#endif /* ENTIDADWRAPPER_H_ */
