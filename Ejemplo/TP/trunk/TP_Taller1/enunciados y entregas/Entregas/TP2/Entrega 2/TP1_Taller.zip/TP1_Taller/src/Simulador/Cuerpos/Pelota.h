/*
 * Pelota.h
 *
 *  Created on: Oct 3, 2013
 *      Author: lucia
 */

#ifndef PELOTA_H_
#define PELOTA_H_
#include "../Cuerpo.h"

namespace simulador {

class Pelota : public Cuerpo{
public:
	Pelota(float coefRestitucion, float densidad,
			float radio, b2Vec2 posInicial, b2World* mundo, Modelo::Entidad* entidad);
	virtual ~Pelota();
	void vivir();
	virtual void restaurarCuerpo();

protected:
	float coeficienteRestitucion;
	float densidad;
	float radio;
	float anguloInicial;

private:
	b2Body* crearCuerpo(b2World* mundo);
};

} /* namespace simulador */
#endif /* PELOTA_H_ */
