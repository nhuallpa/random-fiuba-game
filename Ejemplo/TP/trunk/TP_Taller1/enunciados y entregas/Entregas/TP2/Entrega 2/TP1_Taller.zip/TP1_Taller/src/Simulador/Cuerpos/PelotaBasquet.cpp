/*
 * PelotaBasquet.cpp
 *
 *  Created on: Oct 4, 2013
 *      Author: lucia
 */

#include "PelotaBasquet.h"

namespace simulador {

PelotaBasquet::PelotaBasquet(b2Vec2 posInicial, b2World* mundo, float radio, Modelo::Entidad* entidad)
 : Pelota(Constantes::Instancia()->coeficienteRestitucionPelotaBasquet,
		 Constantes::Instancia()->densidadPelotaBasquet,
		 radio,
		 posInicial, mundo, entidad)
{
	//cambio el userData
	this->cuerpo->SetUserData(this);
}

PelotaBasquet::~PelotaBasquet() {
}

} /* namespace simulador */
