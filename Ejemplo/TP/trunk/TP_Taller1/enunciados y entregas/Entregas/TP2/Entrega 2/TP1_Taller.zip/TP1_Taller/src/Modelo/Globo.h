/*
 * Globo.h
 *
 *  Created on: Oct 13, 2013
 *      Author: rick
 */

#ifndef GLOBO_H_
#define GLOBO_H_

#include "EntidadSogeable.h"

namespace Modelo {


class Globo: public Modelo::EntidadSogeable {

public:
	Globo();
	explicit Globo (Modelo::TipoElemento clase, Vec2 centro = Vec2(0, 0),
			Vec2 tamanio = Vec2(0, 0), float angulo = 0.0f);
	virtual ~Globo();

	virtual bool esMovil() const;

	virtual std::list<Vec2> lugarDondeSePuedeUnirBase() const;

};


} /* namespace Modelo */

#endif /* GLOBO_H_ */
