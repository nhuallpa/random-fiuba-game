/*
 * Boton.cpp
 *
 *  Created on: 14/09/2013
 *  Last Amended: 14/09/2013
 *      Author: natuchis
 */

#include "Boton.h"

#include "ClickInfo.h"
#include "LayoutInfo.h"
#include "Interfases/Elemento.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "Log/Suceso.h"
#include "Utils/Vec2.h"
#include "Utils/Rect.h"

Boton::Boton(const FuentePosicion& fuente, Imagen imagen, std::function<void()> reaccion)
	: vista::Elemento(fuente)
	, imagen(imagen)
	, reaccion(reaccion)
{
}

Boton::~Boton() {
}

void Boton::dibujarse(DestinoDibujo* window) {
	//Acordarse que las posiciones de los elementos que guardamos
	//siempre son relativas a la posicion del contenedor.
	imagen.dibujar(*window, *fuente);
}

vista::ClickInfo Boton::recibirClick (Vec2) {
	reaccion();
	return vista::ClickInfo();
}

bool Boton::dirty() {
	return true;
}

LayoutInfo Boton::getLayoutInfo(){
	return LayoutInfo(imagen.tamDibujo());
}
