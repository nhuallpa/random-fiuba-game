/*
 * Controlador.cpp
 *
 *  Created on: Sep 12, 2013
 *      Author: lucia
 */

#include "Controlador.h"
#include "Vista/ClickInfo.h"
#include "Vista/Ventana.h"
#include "Vista/Contenedor.h"
#include "Vista/Interfases/Elemento.h"
#include <SDL2/SDL.h>
#include <iostream>

using namespace std;


Controlador::Controlador(Ventana* window)
	: mouse()
	, teclado()
	, window(window)
{
}


void Controlador::handle(SDL_Event event) {
	// Chequeo los eventos que me interesan
	// SDL_Quit se maneja antes de entrar a este metodo
	switch (event.type) {

	case SDL_WINDOWEVENT:
		if (event.window.event == SDL_WINDOWEVENT_RESIZED) {
			Vec2 tam(event.window.data1, event.window.data2);
			window->resized(tam);
			//TODO: contenedorRaiz->resized(tam)
		}
		break;

	case SDL_MOUSEBUTTONDOWN: {
		vista::ClickInfo info = window->getRaiz()->recibirClick(mouse.getPosicionMouse());

		if (event.button.button == SDL_BUTTON_LEFT) {
			if (teclado.shift()) {
				window->getRaiz()->aEliminar(mouse.getPosicionMouse());
			} else {
				if (!mouse.estoyClickeando()) {
					if (info.puedeArrastrar) {
						mouse.iniciarSeleccion(window, info);
					} else {
						mouse.iniciarClickeo(info);
					}
				} else {
					if (info.puedeUnirse) {
						mouse.unir(window, info);
					}
				}
			}
		} else if (event.button.button == SDL_BUTTON_RIGHT) {
			if (teclado.ctrl() && info.puedeResizear) {
				mouse.iniciarResize(info);
			} else if (info.puedeRotar) {
				mouse.iniciarRotacion(info);
			} else if(teclado.r() || teclado.ctrl()) {
				mouse.cambiarFormas(info);
			}
		}

		if (info.tomaFocoTeclado) {
			teclado.enfocar(info.clickeado);
		}
		break;
	}

	case SDL_MOUSEBUTTONUP:
		mouse.soltar(window);
		break;

	case SDL_MOUSEMOTION:
		mouse.realizarMovimiento(&event);
		break;

	case SDL_MOUSEWHEEL:
		if (event.wheel.y > 0) {
			window->getRaiz()->desplazarHaciaAbajo(mouse.getPosicionMouse());
		} else if (event.wheel.y < 0) {
			window->getRaiz()->desplazarHaciaArriba(mouse.getPosicionMouse());
		}
		break;

	case SDL_KEYDOWN:
		teclado.presionar(event.key.keysym.sym);
		if(teclado.esc()) {
			mouse.finalizarUnion();
		}
		break;

	case SDL_KEYUP:
		teclado.soltar(event.key.keysym.sym);
		break;

	case SDL_TEXTINPUT:
		teclado.input(event.text.text);
		break;
	}
}


Controlador::~Controlador() {
}
