#include "EntidadWrapper.h"

#include "Log/Suceso.h"
#include "Modelo/Balancin.h"
#include "Modelo/Globo.h"
#include "Modelo/Plataforma.h"
#include "Modelo/EntidadPelota.h"
#include "Modelo/EntidadCorreable.h"
#include "Modelo/EntidadElementoPuente.h"
#include "Utils/make_unique.h"

namespace Modelo {

EntidadWrapper::EntidadWrapper()
	: base(nullptr)
{
}

EntidadWrapper::EntidadWrapper (TipoElemento clase, Vec2 centro, Vec2 tamanio, float angulo)
	: base(nullptr)
{
	switch (clase) {

	case TipoElemento::PelotaBasquet:
	case TipoElemento::PelotaBowling:
		base = make_unique<EntidadPelota>(clase, centro, tamanio, angulo);
		break;
	case TipoElemento::Globo:
		base = make_unique<Globo>(clase, centro, tamanio, angulo);
		break;
	case TipoElemento::Plataforma:
		base = make_unique<Plataforma>(clase, centro, tamanio, angulo);
		break;
	case TipoElemento::Balancin:
		base = make_unique<Balancin>(clase, centro, tamanio, angulo);
		break;
	case TipoElemento::Soga:
	case TipoElemento::Correa:
		base = make_unique<EntidadElementoPuente>(clase, centro, tamanio, angulo);
		break;
	case TipoElemento::Motor:
	case TipoElemento::Engranaje:
	case TipoElemento::CintaTransportadora:
		base = make_unique<EntidadCorreable>(clase, centro, tamanio, angulo);
		break;
	}
}

bool EntidadWrapper::colicionaCon(Entidad* otraEntidad) const
{
	return base->colicionaCon(otraEntidad);
}

bool EntidadWrapper::esMovil() const
{
	return base->esMovil();
}

bool EntidadWrapper::esNoMovil() const
{
	return base->esNoMovil();
}

bool EntidadWrapper::esElementoPuente() const
{
	return base->esElementoPuente();
}

bool EntidadWrapper::esSogeable() const
{
	return base->esSogeable();
}

bool EntidadWrapper::esCorreable() const
{
	return base->esCorreable();
}

bool EntidadWrapper::esPelota() const
{
	return base->esPelota();
}

bool EntidadWrapper::tieneLosDosExtremosLibres() const
{
	return base->tieneLosDosExtremosLibres();
}

bool EntidadWrapper::tieneUnExtremoLibre() const
{
	return base->tieneUnExtremoLibre();
}

bool EntidadWrapper::puedeUnirseA(Entidad* unaEntidad) const
{
	return base->puedeUnirseA(unaEntidad);
}

bool EntidadWrapper::vincular(EntidadWrapper lhs, EntidadWrapper rhs, Vec2 a, Vec2 b)
{
	if (!esElementoPuente()) {
		throw Log::Suceso(Log::DEBUG, "Mal vinculo");
	}

	auto infoA = lhs.base->lugarUnionMasCercano(a);
	auto infoB = rhs.base->lugarUnionMasCercano(b);
	if (!infoA.first || !infoB.first) {
		throw Log::Suceso(Log::DEBUG, "Mal vinculo");
	}

	auto puntoUnionUsado = [] (EntidadWrapper ent, Vec2 punto) -> bool {
		for (Entidad* vinculo : ent.elemPuenteAtado()) {
			if (vinculo->puntoDeLigaduraEntidadA == punto ||
			    vinculo->puntoDeLigaduraEntidadB == punto) {
				return true;
			}
		}
		return false;
	};
	if (puntoUnionUsado(lhs, infoA.second) || puntoUnionUsado(rhs, infoB.second)) {
		return false;
	}

	lhs.base->elemPuenteAtado.push_back(base.get());
	rhs.base->elemPuenteAtado.push_back(base.get());
	base->puntoDeLigaduraEntidadA = infoA.second;
	base->puntoDeLigaduraEntidadB = infoB.second;
	base->entidadExtremoA = lhs.base.get();
	base->entidadExtremoB = rhs.base.get();
	base->regenerar();
	return true;
}

bool EntidadWrapper::tieneElemPuenteAtado() const
{
	return base->tieneElemPuenteAtado();
}

std::list<Vec2> EntidadWrapper::lugarDondeSePuedeUnir() const
{
	return base->lugarDondeSePuedeUnir();
}

std::list<Entidad*> EntidadWrapper::desenlazarElemPuente()
{
	return base->desenlazarElemPuente();
}

bool EntidadWrapper::operator== (EntidadWrapper rhs) const
{
	return base.get() == rhs.base.get();
}

Modelo::TipoElemento& EntidadWrapper::clase()
{
	return base->clase;
}

Vec2& EntidadWrapper::centro()
{
	return base->centro;
}

Vec2& EntidadWrapper::tamanio()
{
	return base->tamanio;
}

float& EntidadWrapper::angulo()
{
	return base->angulo;
}

Entidad*& EntidadWrapper::entidadExtremoA()
{
	return base->entidadExtremoA;
}

Entidad*& EntidadWrapper::entidadExtremoB()
{
	return base->entidadExtremoB;
}

Vec2& EntidadWrapper::puntoDeLigaduraEntidadA()
{
	return base->puntoDeLigaduraEntidadA;
}

Vec2& EntidadWrapper::puntoDeLigaduraEntidadB()
{
	return base->puntoDeLigaduraEntidadB;
}

std::list<Entidad*>& EntidadWrapper::elemPuenteAtado()
{
	return base->elemPuenteAtado;
}

Modelo::TipoElemento EntidadWrapper::clase() const
{
	return base->clase;
}

Vec2 EntidadWrapper::centro() const
{
	return base->centro;
}

Vec2 EntidadWrapper::tamanio() const
{
	return base->tamanio;
}

float EntidadWrapper::angulo() const
{
	return base->angulo;
}

float EntidadWrapper::radio() const
{
	return std::max(base->tamanio.x, base->tamanio.y) / 2;
}

const Entidad* EntidadWrapper::entidadExtremoA() const
{
	return base->entidadExtremoA;
}

const Entidad* EntidadWrapper::entidadExtremoB() const
{
	return base->entidadExtremoB;
}

Vec2 EntidadWrapper::puntoDeLigaduraEntidadA() const
{
	return base->puntoDeLigaduraEntidadA;
}

Vec2 EntidadWrapper::puntoDeLigaduraEntidadB() const
{
	return base->puntoDeLigaduraEntidadB;
}

const std::list<Entidad*> EntidadWrapper::elemPuenteAtado() const
{
	return base->elemPuenteAtado;
}

bool& EntidadWrapper::sentidoHorario() const
{
	return base->sentidoHorario;
}

} /* namespace Modelo */
