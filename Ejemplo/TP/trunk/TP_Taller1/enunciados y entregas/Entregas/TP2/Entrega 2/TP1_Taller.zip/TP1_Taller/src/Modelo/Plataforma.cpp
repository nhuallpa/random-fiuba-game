/*
 * Plataforma.cpp
 *
 *  Created on: Oct 13, 2013
 *      Author: rick
 */

#include "Plataforma.h"

namespace Modelo {

Plataforma::Plataforma()
	: Modelo::Entidad()
{
}


Plataforma::Plataforma(Modelo::TipoElemento clase, Vec2 centro, Vec2 tamanio, float angulo)
	: Modelo::Entidad(clase, centro, tamanio, angulo)
{
}


Plataforma::~Plataforma() {
}


bool Plataforma::esNoMovil() const {
	return true;
}


} /* namespace Modelo */
