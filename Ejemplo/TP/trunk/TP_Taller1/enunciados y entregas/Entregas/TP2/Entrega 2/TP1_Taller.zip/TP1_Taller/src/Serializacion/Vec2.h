#ifndef SERIALIZACION_VEC2_H_
#define SERIALIZACION_VEC2_H_

#include "Utils/Vec2.h"
#include <yaml-cpp/node/convert.h>

namespace YAML {
template<>
struct convert<Vec2> {
	static Node encode(const Vec2& rhs);

	/* EL NODO ENTREGADO DEBE SER DISTINTO DE NULL Y DEFINIDO.
	 * En caso de que ambos valores esten vacios, se rellenan por defecto en (0,0).
	 * Idem si no es una secuencia o no tiene tamaño 2.
	 * En caso de que uno de los valores este vacio o no sea escalar, se rellena por 0.
	 * Idem si no puede leerse como float.
	 */
	static bool decode(const Node& node, Vec2& rhs);
};
}

#endif /* SERIALIZACION_VEC2_H_ */
