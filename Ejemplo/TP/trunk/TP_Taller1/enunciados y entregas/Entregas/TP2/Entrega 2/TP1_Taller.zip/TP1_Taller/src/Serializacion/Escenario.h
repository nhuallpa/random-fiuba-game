#ifndef SERIALIZACION_ESCENARIO_H_
#define SERIALIZACION_ESCENARIO_H_

#include "Modelo/Escenario.h"
#include <yaml-cpp/node/convert.h>

namespace YAML {
template<>
struct convert<Escenario> {
	static Node encode(const Escenario& rhs);

	// EL NODO ENTREGADO DEBE SER DISTINTO DE NULL Y DEFINIDO.
	static bool decode(const Node& node, Escenario& rhs);
};
}

#endif /* SERIALIZACION_ESCENARIO_H_ */
