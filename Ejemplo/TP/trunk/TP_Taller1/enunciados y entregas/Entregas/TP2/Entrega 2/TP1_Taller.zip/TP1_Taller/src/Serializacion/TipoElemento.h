/*
 * TipoElemento.h
 *
 *  Created on: Oct 11, 2013
 *      Author: lucia
 */

#ifndef SERIALIZACION_TIPOELEMENTO_H_
#define SERIALIZACION_TIPOELEMENTO_H_
#include "../Modelo/TipoElemento.h"
#include <yaml-cpp/node/convert.h>

namespace YAML {

template<>
struct convert<Modelo::TipoElemento> {
	static Node encode(const Modelo::TipoElemento& rhs);

	/* EL NODO ENTREGADO DEBE SER DISTINTO DE NULL Y DEFINIDO.
	 */
	static bool decode(const Node& node, Modelo::TipoElemento& rhs);
};

} /* namespace YAML */
#endif /* SERIALIZACION_TIPOELEMENTO_H_ */
