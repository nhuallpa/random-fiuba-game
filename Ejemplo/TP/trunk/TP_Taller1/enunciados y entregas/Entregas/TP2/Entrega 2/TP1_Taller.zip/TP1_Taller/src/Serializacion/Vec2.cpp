#include "Vec2.h"

#include "Log/Suceso.h"
#include "Utils/ConvertStr.h"
#include "Utils/YAMLHelper.h"

namespace YAML {
	Node convert<Vec2>::encode(const Vec2& rhs) {
		Node node;
		node.push_back(rhs.x);
		node.push_back(rhs.y);
		return node;
	}

	bool convert<Vec2>::decode(const Node& node, Vec2& rhs) {
		YAML::Mark marca = node.mark();
		std::string msj = "";

		if (!node.IsSequence() || node.size() != 2) {
			ConvertStr output(marca, "No se puede leer Vec2, no es secuencia o no tiene 2 atributos. Creado por defecto (0,0).");
			Log::Suceso (Log::ERROR, output.getString());
		} else {
			rhs.x = YAML_leer<float>(node[0], "x");
			rhs.y = YAML_leer<float>(node[1], "y");
		}
		return true;
	}
}
