#ifndef ITERACION_H_
#define ITERACION_H_

template <class T>
struct AdaptadorInvierteIteracion
{
	const T& it;

	AdaptadorInvierteIteracion(T&& it) : it(it) {}

	auto begin () -> decltype(it.rbegin())
	{
		return it.rbegin();
	}

	auto end () -> decltype(it.rend())
	{
		return it.rend();
	}
};

template <class T>
AdaptadorInvierteIteracion<T> invertir_iteracion (T&& t)
{
	return AdaptadorInvierteIteracion<T>(t);
}


#endif /* ITERACION_H_ */
