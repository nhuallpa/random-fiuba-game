#include "Vista/InfoFiguras.h"

using namespace Modelo;

namespace vista {

InfoFiguras::InfoFiguras ()
	: tipo()
	, pathImagenToolbar()
	, pathImagenCanvas()
	, tamCanvas()
	, anguloCanvas()
{
}

InfoFiguras::InfoFiguras (Modelo::TipoElemento tipo,
                          std::string pathImagenToolbar,
                          std::string pathImagenCanvas,
                          Vec2 tamCanvas,
                          float anguloCanvas)
	: tipo(tipo)
	, pathImagenToolbar(pathImagenToolbar)
	, pathImagenCanvas(pathImagenCanvas)
	, tamCanvas(tamCanvas)
	, anguloCanvas(anguloCanvas)
{
}

std::map<TipoElemento, InfoFiguras> InfoFiguras::datos = {
	{TipoElemento::PelotaBasquet, {TipoElemento::PelotaBasquet
			, "imagenes/objetos/pelotaBasquet.png"
			, "imagenes/objetos/pelotaBasquet.png"
			, Vec2(1, 1)
			, 0}},
	{TipoElemento::PelotaBowling, {TipoElemento::PelotaBowling
			, "imagenes/objetos/pelotaBowling.png"
			, "imagenes/objetos/pelotaBowling.png"
			, Vec2(1, 1)
			, 0}},
	{TipoElemento::Balancin, {TipoElemento::Balancin
			, "imagenes/objetos/balancin.png"
			, "imagenes/objetos/balancin.png"
			, Vec2(3, 0.5)
			, 0}},
	{TipoElemento::CintaTransportadora, {TipoElemento::CintaTransportadora
			, "imagenes/objetos/cintaTransportadora.png"
			, "imagenes/objetos/cintaTransportadora.png"
			, Vec2(3, 0.8)
			, 0}},
	{TipoElemento::Correa, {TipoElemento::Correa
			, "imagenes/objetos/correa.png"
			, "imagenes/objetos/correa.png"
			, Vec2(1, 0.5)
			, 0}},
	{TipoElemento::Globo, {TipoElemento::Globo
			, "imagenes/objetos/globo.png"
			, "imagenes/objetos/globo.png"
			, Vec2(0.9, 1)
			, 0}},
	{TipoElemento::Motor, {TipoElemento::Motor
			, "imagenes/objetos/motorRaton.png"
			, "imagenes/objetos/motorRaton.png"
			, Vec2(1.4, 1)
			, 0}},
	{TipoElemento::Plataforma, {TipoElemento::Plataforma
			, "imagenes/objetos/plataformaMadera.png"
			, "imagenes/objetos/plataformaMadera.png"
			, Vec2(3, 0.5)
			, 0}},
	{TipoElemento::Soga, {TipoElemento::Soga
			, "imagenes/objetos/soga.png"
			, "imagenes/objetos/soga.png"
			, Vec2(1, 0.15)
			, 0}},
	{TipoElemento::Engranaje, {TipoElemento::Engranaje
			, "imagenes/objetos/engranajeM.png"
			, "imagenes/objetos/engranajeM.png"
			, Vec2(1, 1)
			, 0}},
};

} /* namespace vista */
