/*
 * EntidadSogeable.cpp
 *
 *  Created on: Oct 13, 2013
 *      Author: rick
 */

#include "EntidadSogeable.h"

namespace Modelo {

EntidadSogeable::EntidadSogeable()
	: Modelo::Entidad()
{
}


EntidadSogeable::EntidadSogeable(Modelo::TipoElemento clase, Vec2 centro, Vec2 tamanio, float angulo)
	: Modelo::Entidad(clase, centro, tamanio, angulo)
{
}


EntidadSogeable::~EntidadSogeable() {
}


bool EntidadSogeable::esSogeable() const {
	return true;
}


bool EntidadSogeable::tieneUnElemPuenteAtado() const {
	if (!this->elemPuenteAtado.empty()) {
		return true;
	}
	return false;
}


} /* namespace Modelo */
