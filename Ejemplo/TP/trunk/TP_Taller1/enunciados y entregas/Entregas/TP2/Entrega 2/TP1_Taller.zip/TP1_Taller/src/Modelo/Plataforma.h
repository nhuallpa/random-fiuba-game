/*
 * Plataforma.h
 *
 *  Created on: Oct 13, 2013
 *      Author: rick
 */

#ifndef PLATAFORMA_H_
#define PLATAFORMA_H_

#include "Entidad.h"

namespace Modelo {


class Plataforma: public Modelo::Entidad {

public:
	Plataforma();
	explicit Plataforma (Modelo::TipoElemento clase, Vec2 centro = Vec2(0, 0),
			Vec2 tamanio = Vec2(0, 0), float angulo = 0.0f);
	virtual ~Plataforma();

	virtual bool esNoMovil() const;

};


} /* namespace Modelo */

#endif /* PLATAFORMA_H_ */
