#ifndef MODOSIMULACION_H_
#define MODOSIMULACION_H_

#include "Modo/ModoUsuario.h"
#include "Modo/ModoEdicion.h"
#include "Simulador/Simulador.h"

class Ventana;
class Escenario;

namespace Modo {

class ModoEdicion;

class ModoSimulacion : public ModoJuego
{
public:
	ModoSimulacion ();
	ModoSimulacion (ModoEdicion&&);

	ModoSimulacion (const ModoSimulacion&) = delete;
	ModoSimulacion (ModoSimulacion&&) = default;
	ModoSimulacion& operator= (const ModoSimulacion&) = delete;
	ModoSimulacion& operator= (ModoSimulacion&&) = default;
	virtual ~ModoSimulacion ();

	virtual EstadoJuego estado ();
	virtual EstadoJuego iteracionPrincipal (float ms);
	virtual std::unique_ptr<ModoJuego> transicion(EstadoJuego proximo);

private:
	ModoEdicion base;
	std::unique_ptr<Contenedor> raizOriginal;
	std::unique_ptr<Textura> fondo;
	simulador::Simulador *sim;
	EstadoJuego proximoEstado;
	float ultimoGrafico;
	float ultimaSimulacion;

	static constexpr unsigned fps_deseado = 60;

	friend class ModoEdicion;
};

} /* namespace Modo */
#endif /* MODOSIMULACION_H_ */
