#include "Entidad.h"

#include "Serializacion/Vec2.h"
#include "Serializacion/TipoElemento.h"
#include "Utils/ConvertStr.h"
#include "Utils/YAMLHelper.h"
#include "../Modelo/TipoElemento.h"

namespace YAML
{

Node convert<Modelo::EntidadWrapper>::encode(const Modelo::EntidadWrapper& rhs) {
	Node node;
	node["clase"] = rhs.clase();
	node["posicion"] = rhs.centro();
	node["tamanio"] = rhs.tamanio();
	node["angulo"] = rhs.angulo();
	node["puntoDeLigaduraEntidadA"] = rhs.puntoDeLigaduraEntidadA();
	node["puntoDeLigaduraEntidadB"] = rhs.puntoDeLigaduraEntidadB();
	node["sentidoHorario"] = rhs.sentidoHorario();
	return node;
}

bool convert<Modelo::EntidadWrapper>::decode(const Node& node, Modelo::EntidadWrapper& rhs) {
	YAML::Mark marca = node.mark();

	if (!node.IsMap()) {
		ConvertStr output(marca, "No se puede leer Entidad, no es mapa o no tiene 3 atributos. Omitido.");
		Log::Suceso (Log::ERROR, output.getString());
		return false;
	} else {
		try {
			Modelo::TipoElemento tipo;
			try{
				tipo = YAML_leerFatal<Modelo::TipoElemento>(node["clase"], "clase");
			} catch(Log::Suceso) {
				std::string msg("Intento crear clase inexistente '");
				ConvertStr output(marca, msg);
				throw Log::Suceso(Log::ERROR, output.getString());
			}
			rhs = Modelo::EntidadWrapper(tipo);
			rhs.centro() = YAML_leer<Vec2>(node["posicion"], "posicion");
			rhs.tamanio() = YAML_leer<Vec2>(node["tamanio"], "tamanio");
			rhs.angulo() = YAML_leer<float>(node["angulo"], "angulo");

			rhs.puntoDeLigaduraEntidadA() = YAML_leer<Vec2>(node["puntoDeLigaduraEntidadA"], "puntoDeLigaduraEntidadA");
			rhs.puntoDeLigaduraEntidadB() = YAML_leer<Vec2>(node["puntoDeLigaduraEntidadB"], "puntoDeLigaduraEntidadB");

			rhs.sentidoHorario() = YAML_leer<bool>(node["sentidoHorario"], "sentidoHorario");

			if (rhs.tamanio().x < 0) {
				rhs.tamanio().x = std::abs(rhs.tamanio().x);
				ConvertStr output(marca, "El atributo tamanio.x no puede ser negativo. Se completo con su valor absoluto.");
				Log::Suceso(Log::ERROR, output.getString());
			}
			if (rhs.tamanio().y < 0) {
				rhs.tamanio().y = std::abs(rhs.tamanio().y);
				ConvertStr output(marca, "El atributo tamanio.y no puede ser negativo. Se completo con su valor absoluto.");
				Log::Suceso(Log::ERROR, output.getString());
			}
		} catch (Log::Suceso&) {
			return false;
		}
	}
	return true;
}

} /* namespace YAML */
