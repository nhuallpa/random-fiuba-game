/*
 * Mouse.cpp
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#include "Mouse.h"

#include "Utils/make_unique.h"
#include "Vista/ClickInfo.h"
#include "Vista/FiguraVista.h"
#include "Vista/Ventana.h"
#include "Vista/Interfases/Elemento.h"
#include "Vista/FuentesPosicion/FuenteLayout.h"
#include "Vista/FuentesPosicion/FuenteMouse.h"
#include "Vista/FuentesPosicion/FuenteModelo.h"
#include "Vista/FuentesPosicion/FuenteExtensible.h"
#include "Modelo/Entidad.h"
#include "Modelo/EntidadElementoPuente.h"
#include <SDL2/SDL.h>
#include <iostream>


namespace controlador {

Mouse::Mouse()
	: arrastrando(false)
	, rotando(false)
	, clickeando(false)
	, resizeando(false)
	, elemento(NULL)
	, cursorDefault(NULL)
	, cursorRotar(NULL)
	, cursorDosClicks(NULL)
	, cursorResize(NULL)
	, cantClickeados(0)
	, figura(NULL)
{
	cursorDefault = new Cursor("imagenes/punteros/single-click.png");
	cursorRotar = new Cursor("imagenes/punteros/rotate.png");
	cursorDosClicks = new Cursor("imagenes/punteros/wizard.png");
	cursorResize = new Cursor("imagenes/punteros/arrow_resize.png");

	cursorDefault->activar();
}

Mouse::~Mouse() {
	if (arrastrando) {
		delete elemento;
	}
	delete cursorDefault;
	delete cursorRotar;
	delete cursorDosClicks;
	delete cursorResize;
}

void Mouse::iniciarSeleccion(const Ventana *ventana, vista::ClickInfo info)
{
	auto elementoBuscado = info.clickeado->clonar();
	if (elementoBuscado == NULL) return;

	elemento = elementoBuscado;
	arrastrando = true;

	FuenteMouse *nFuente = new FuenteMouse(ventana, this, elemento->getFuente());
	elemento->setFuente(nFuente);

	ventana->getRaiz()->aEliminar(getPosicionMouse());
	ventana->getRaiz()->addElemento(elemento, vista::PrioridadDibujo::arrastrando);
}

void Mouse::iniciarClickeo(vista::ClickInfo info) {
	if (elemento == NULL && info.clickeado != NULL) {
		auto elementoBuscado = info.clickeado->clonar();
		if (elementoBuscado == NULL) return;

		elemento = elementoBuscado;
		figura = dynamic_cast<FiguraVista*>(elemento);
		clickeando = true;
		cantClickeados = 0;
		cambiarModoCursor();
	}
}

void Mouse::iniciarResize(vista::ClickInfo info) {
	if (elemento == NULL && info.clickeado != NULL) {
		resizeando = true;
		elemento = info.clickeado;
		cambiarModoCursor();
	}
}

void Mouse::iniciarRotacion(vista::ClickInfo info) {
	if (elemento == NULL && info.clickeado != NULL) {
		rotando = true;
		elemento = info.clickeado;
		cambiarModoCursor();
	}
}
// TODO ver como acceder a los chequeos de las entidades e indicar union.
// Necesito ventana??
void Mouse::unir(const Ventana *ventana, vista::ClickInfo info) {
	// figura corresponde a la soga o la correa, cuando inicio el clickeo
	// info.clickeado corresponde al elemento clickeado para unir
	bool primerClick = (cantClickeados == 0);
	if (figura != NULL && info.clickeado != NULL) {
		if (cantClickeados < 2) {
			Modelo::TipoElemento clase = figura->getClase();
			FiguraVista *figuraActual = dynamic_cast<FiguraVista*>(info.clickeado);
			Modelo::TipoElemento claseActual = figuraActual->getClase();
			FuenteModelo *fuenteActual = dynamic_cast<FuenteModelo*>(figuraActual->getFuente());
			Modelo::EntidadWrapper entidadActual = fuenteActual->getEntidad();
			if (clase == Modelo::TipoElemento::Correa &&
					(claseActual == Modelo::TipoElemento::CintaTransportadora ||
					 claseActual == Modelo::TipoElemento::Engranaje ||
					 claseActual == Modelo::TipoElemento::Motor) &&
					 entidadActual.base.get()->elemPuenteAtado.empty()) {
				if(primerClick)
					posClickAnterior = getPosicionMouse();
				cantClickeados++;
			}
			else if (clase == Modelo::TipoElemento::Soga && claseActual == Modelo::TipoElemento::Balancin &&
						(entidadActual.entidadExtremoA() == NULL || entidadActual.entidadExtremoB() == NULL)) {
				if(primerClick)
					posClickAnterior = getPosicionMouse();
				cantClickeados++;
			}
			else if (clase == Modelo::TipoElemento::Soga && claseActual == Modelo::TipoElemento::Globo &&
						entidadActual.base.get()->elemPuenteAtado.empty()) {
				if(primerClick)
					posClickAnterior = getPosicionMouse();
				cantClickeados++;
			}
		}
		if (cantClickeados == 2) {
			ventana->getRaiz()->recibirElementoPuente(figura, posClickAnterior, getPosicionMouse());
			finalizarUnion();
		}
	}
}

bool Mouse::estoyClickeando() {
	return clickeando;
}

void Mouse::cambiarFormas(vista::ClickInfo info) {
	if (elemento == NULL && info.clickeado != NULL) {
//		auto elementoBuscado = info.clickeado->clonar();
//		if (elementoBuscado == NULL) return;
//
//		elemento = elementoBuscado;
		elemento = info.clickeado;
		elemento->cambiarForma();
	}
}

void Mouse::realizarMovimiento(SDL_Event* event){
	Vec2 movimiento(event->motion.xrel, event->motion.yrel);
	if (arrastrando) {
		elemento->mover(movimiento);
	} else if (rotando) {
		elemento->rotar(this->getPosicionMouse());
	} else if (resizeando) {
		elemento->resizear(movimiento);
	}
}

Vec2 Mouse::getPosicionMouse() const{
	int x, y;
	SDL_GetMouseState(&x, &y);
	return Vec2(x, y);
}

void Mouse::soltar(Ventana *ventana){
	if (arrastrando) {
		ventana->getRaiz()->quitarElemento(elemento);
		//TODO: manejar si falla el dynamic_cast (pero no deberia!)
		ventana->getRaiz()->recibirFigura(dynamic_cast<FiguraVista*>(elemento), getPosicionMouse());
		delete elemento;
	}
	elemento = NULL;
	arrastrando = false;
	rotando = false;
	resizeando = false;
	cambiarModoCursor();
}

void Mouse::cambiarModoCursor() {
	if (rotando) {
		cursorRotar->activar();
	} else if (clickeando) {
		cursorDosClicks->activar();
	} else if (resizeando) {
		cursorResize->activar();
	} else {
		cursorDefault->activar();
	}
}

void Mouse::finalizarUnion(){
	clickeando = false;
	figura = NULL;
	elemento = NULL;
	cambiarModoCursor();
}

} /* namespace controlador */
