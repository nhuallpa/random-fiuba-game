#include "TipoElemento.h"

#include "Log/Suceso.h"

#include <list>
#include <utility>

namespace Modelo {

std::list<TipoElemento> listaTipoElemento = {
	TipoElemento::PelotaBasquet,
	TipoElemento::PelotaBowling,
	TipoElemento::Globo,
	TipoElemento::Plataforma,
	TipoElemento::Balancin,
	TipoElemento::Soga,
	TipoElemento::Motor,
	TipoElemento::Correa,
	TipoElemento::Engranaje,
	TipoElemento::CintaTransportadora,
};

/* static en variable global := solo visible desde esta unidad de compilacion */
static std::list<std::pair<TipoElemento, std::string>> valores = {
	make_pair(TipoElemento::PelotaBasquet, std::string("PelotaBasquet")),
	make_pair(TipoElemento::PelotaBowling, std::string("PelotaBowling")),
	make_pair(TipoElemento::Globo, std::string("Globo")),
	make_pair(TipoElemento::Plataforma, std::string("Plataforma")),
	make_pair(TipoElemento::Balancin, std::string("Balancin")),
	make_pair(TipoElemento::Soga, std::string("Soga")),
	make_pair(TipoElemento::Motor, std::string("Motor")),
	make_pair(TipoElemento::Correa, std::string("Correa")),
	make_pair(TipoElemento::Engranaje, std::string("Engranaje")),
	make_pair(TipoElemento::CintaTransportadora, std::string("CintaTransportadora"))
};

std::string tipoElementoToString(TipoElemento clase) {
	for (auto par : valores) {
		if (par.first == clase) {
			return par.second;
		}
	}
	throw Log::Suceso(Log::DEBUG, "Intento convertir clase desconocida a string");
}

TipoElemento stringToTipoElemento(std::string clase) {
	for (auto par : valores) {
		if (par.second == clase) {
			return par.first;
		}
	}
	std::string mensaje = std::string("Intento convertir string desconocido ")
		+ "'" + clase + "'"
		+ " a clase";
	throw Log::Suceso(Log::ERROR, mensaje);
}

} /* namespace Modelo */
