/*
 * Globo.cpp
 *
 *  Created on: Oct 4, 2013
 *      Author: lucia
 */

#include "Globo.h"

namespace simulador {

Globo::Globo(b2Vec2 posInicial, b2World* mundo, float radio, Modelo::Entidad* entidad):
	Pelota(Constantes::Instancia()->coeficienteRestitucionGlobo,
			Constantes::Instancia()->densidadGlobo,
			radio,
			posInicial, mundo, entidad){
	this->posicionInicial = posInicial;
	//cambio el userData
	this->cuerpo->SetUserData(this);

}

void Globo::vivir(){
	//Le doy una fuerza que corresponderia si hubiera aire
	Constantes* cte = Constantes::Instancia();
	float volumen = this->cuerpo->GetMass() / cte->densidadGlobo;
	float fuerzaFlotacion = volumen * cte->densidadAire * cte->gravedad;
	this->cuerpo->ApplyForceToCenter(b2Vec2(0, -fuerzaFlotacion));
	entidad->centro = Vec2(cuerpo->GetPosition());
	entidad->angulo = cuerpo->GetAngle() * cte->RADTODEG;
}

Globo::~Globo() {
}

} /* namespace simulador */
