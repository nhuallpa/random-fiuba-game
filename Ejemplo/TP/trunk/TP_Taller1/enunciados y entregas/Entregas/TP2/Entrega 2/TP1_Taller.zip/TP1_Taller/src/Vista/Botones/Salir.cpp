/*
 * Salir.cpp
 *
 *  Created on: 14/09/2013
 *  Last Amended: 15/09/2013
 *      Author: natuchis
 */

#include "Salir.h"

#include "Global/terminarPrograma.h"
#include "Vista/ClickInfo.h"

Salir::Salir(const FuentePosicion& fuente, Dibujable *destino)
	: Boton(fuente
	       , Imagen("imagenes/botones/Salir.png", destino)
	       , [] { terminarPrograma(); })
{
}

Salir::~Salir() {
}
