/*
 * Guardar.cpp
 *
 *  Created on: 14/09/2013
 *  Last Amended: 15/09/2013
 *      Author: natuchis
 */

#include "Guardar.h"

#include "Vista/ClickInfo.h"
#include "Serializacion/Escenario.h"
#include <yaml-cpp/yaml.h>

Guardar::Guardar(const FuentePosicion& fuente, Dibujable *destino, Escenario* escenario, std::string pathArch)
	: Boton(fuente
		, Imagen("imagenes/botones/Guardar.png", destino)
		, [pathArch, escenario] () {
			std::ofstream sal;
			sal.open(pathArch.c_str(), ofstream::out | ofstream::trunc);

			YAML::Node nodo_out;
			nodo_out["escenario"] = *escenario;

			sal << nodo_out << std::endl;
			sal.close();

			Log::Suceso (Log::INFO, "Se guardo el escenario.");
		})
{
}

Guardar::~Guardar() {
}
