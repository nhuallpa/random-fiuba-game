/*
 * Texto.cpp
 *
 *  Created on: 02/10/2013
 *  Last Amended: 02/10/2013
 *      Author: natuchis
 */

#include "Texto.h"

#include "Log/Suceso.h"
#include "Utils/Vec2.h"
#include <utility>

Texto::Texto()
	: fuente()
	, apariencia()
	, fuenteTexto(nullptr)
	, colorTexto()
	, colorFondo()
	, texto()
	, necesitaRegenerar(false)
{
}

Texto::Texto(const FuentePosicion& fuente, Dibujable* destino, std::string textoInicial)
	: fuente (fuente.clonar())
	, apariencia()
	, fuenteTexto(nullptr)
	, colorTexto({0, 0, 0, 255})
	, colorFondo({255, 255, 240, 255})
	, texto(textoInicial)
	, necesitaRegenerar(false)
{
	this->fuenteTexto = TTF_OpenFont("fonts/Arial_Bold.ttf", 14);
	if (this->fuenteTexto == NULL) {
		std::string mensaje("Fallo al iniciar la fuente: ");
		mensaje += TTF_GetError();
		throw Log::Suceso(Log::FATAL, mensaje);
	}
	else {
		Log::Suceso(Log::INFO, "Fuente arial bold iniciado correctamente.");
	}

	setApariencia(*destino);
}

Texto::~Texto() {
	if (fuenteTexto != nullptr && TTF_WasInit()) {
		// para no liberar si ya cerre SDL_ttf
		TTF_CloseFont(this->fuenteTexto);
	}
}

bool Texto::valido() {
	return this->apariencia.valido();
}

SDL_Renderer* Texto::getRenderer() {
	return this->apariencia.getRenderer();
}

SDL_Texture *Texto::getTexture() {
	return this->apariencia.getTexture();
}

void Texto::dibujarse(DestinoDibujo* destino) {
	if (necesitaRegenerar) {
		regenerar();
	}
	apariencia.dibujar(*destino, *fuente);
}

Vec2 Texto::tamDibujo () const {
	return apariencia.tamDibujo();
}

FuentePosicion *Texto::getFuente () {
	return fuente.get();
}

std::string Texto::getTexto() {
	return this->texto;
}

void Texto::setTexto(std::string unTexto) {
	this->texto = unTexto;
	this->necesitaRegenerar = true;
}

void Texto::regenerar() {
	setApariencia((DestinoDibujo&)apariencia);
}

void Texto::setApariencia (Dibujable& destino) {
	std::string aUsar(texto);
	if (aUsar == "") {
		aUsar = " ";
	}
	SDL_Surface *render = TTF_RenderText_Shaded(this->fuenteTexto, aUsar.c_str(),
	                                            this->colorTexto, this->colorFondo);
	if (render == nullptr) {
		std::string mensaje("No se pudo crear texto: ");
		throw Log::Suceso(Log::FATAL, mensaje + TTF_GetError());
	}

	// llamado automaticamente al salir de la funcion, preserva la posible excepcion
	auto deleter = [] (SDL_Surface *val) { SDL_FreeSurface(val); };
	std::unique_ptr<SDL_Surface, decltype(deleter)> puntero(render, deleter);

	apariencia = Textura(destino, render);
}
