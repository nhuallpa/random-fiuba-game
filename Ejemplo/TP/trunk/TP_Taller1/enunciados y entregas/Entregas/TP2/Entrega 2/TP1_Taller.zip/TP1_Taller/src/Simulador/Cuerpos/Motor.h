/*
 * Motor.h
 *
 *  Created on: 04/10/2013
 *      Author: stephanie
 */

#ifndef MOTOR_H_
#define MOTOR_H_

#include "../Cuerpo.h"
#include "CuerpoRotativo.h"
#include "../JointMaker.h"

namespace simulador {

class Motor: public CuerpoRotativo {
public:
	Motor(b2Vec2 posInicial, b2World* mundo, float angulo,
			float radio, bool sentidoHorario, bool sentidoAntihorario, Modelo::Entidad* entidad);
	virtual ~Motor();

};

} /* namespace simulador */
#endif /* MOTOR_H_ */
