#include "ClickInfo.h"

namespace vista {

ClickInfo::ClickInfo()
	: puedeArrastrar(false)
	, puedeRotar(false)
	, puedeResizear(false)
	, puedeUnirse(false)
	, tomaFocoTeclado(true)
	, clickeado(nullptr)
	, posicionClick()
{
}

ClickInfo::ClickInfo(vista::Elemento *clickeado, Vec2 posicionClick)
	: puedeArrastrar(false)
	, puedeRotar(false)
	, puedeResizear(false)
	, puedeUnirse(false)
	, tomaFocoTeclado(true)
	, clickeado(clickeado)
	, posicionClick(posicionClick)
{
}

} /* namespace vista */
