#include "FalsaFigura.h"

#include "Vista/ClickInfo.h"
#include "Vista/InfoFiguras.h"
#include "Vista/LayoutInfo.h"
#include "Vista/FuentesPosicion/FuenteFuncion.h"

namespace vista {

FalsaFigura::FalsaFigura (const FuentePosicion& fuente, Modelo::TipoElemento tipo, Dibujable *dib)
	: Elemento(fuente)
	, imagen()
	, real()
{
	imagen = Imagen(InfoFiguras::datos[tipo].pathImagenToolbar, dib);
	FuenteFuncion fuenteReal(
		[this, tipo] () -> Rect {
			Rect base = this->fuente->getSuperficie();
			base.setTam(base.tam() * InfoFiguras::datos[tipo].tamCanvas);
			return std::move(base);},
		[this, tipo] () -> float {
			return this->fuente->getAngulo() + InfoFiguras::datos[tipo].anguloCanvas;},
		[this] () -> Vec2 {
			return this->fuente->getTamPadre();});
	real = FiguraVista(tipo, fuenteReal, dib);
}

FalsaFigura::FalsaFigura (const FuentePosicion& fuente, FiguraVista real)
	: Elemento(fuente)
	, imagen()
	, real(real)
{
	this->real.setFuente(new FuenteFuncion(
		[this] () { return this->fuente->getSuperficie(); },
		[this] () { return this->fuente->getAngulo(); },
		[this] () { return this->fuente->getTamPadre(); }));
}

FalsaFigura::FalsaFigura (const FuentePosicion& fuente, FiguraVista real, Imagen apariencia)
	: Elemento(fuente)
	, imagen(apariencia)
	, real(real)
{
}

FalsaFigura::~FalsaFigura ()
{
}

void FalsaFigura::setSuperfice (const Rect& val)
{
	fuente->setSuperficie(val);
}

void FalsaFigura::dibujarse (DestinoDibujo* window)
{
	if (imagen.valido()) {
		imagen.dibujar(*window, *fuente);
	} else {
		real.dibujarse(window);
	}
}

bool FalsaFigura::dirty ()
{
	return true;
}

LayoutInfo FalsaFigura::getLayoutInfo ()
{
	if (imagen.valido()) {
		return LayoutInfo(imagen.tamDibujo());
	} else {
		return real.getLayoutInfo();
	}
}

ClickInfo FalsaFigura::recibirClick (Vec2 pos)
{
	auto retval = real.recibirClick(pos);
	retval.puedeResizear = false;
	retval.puedeRotar = false;
	retval.puedeUnirse = false;
	return retval;
}

Elemento* FalsaFigura::clonar () const
{
	return real.clonar();
}

} /* namespace vista */
