#ifndef SERIALIZACION_ENTIDAD_H_
#define SERIALIZACION_ENTIDAD_H_

#include "Modelo/EntidadWrapper.h"
#include <yaml-cpp/node/convert.h>

namespace YAML
{

template<>
struct convert<Modelo::EntidadWrapper> {
	static Node encode(const Modelo::EntidadWrapper& rhs);

	/* EL NODO ENTREGADO DEBE SER DISTINTO DE NULL Y ESTAR DEFINIDO.
	 * En caso de que los valores de posicion o tamanio esten vacios, se rellenan por defecto en (0,0).
	 * En caso de que angulo este vacio o no sea escalar, se rellena por 0.
	 * Idem si no puede leerse como float.
	 * Si no es un mapa o no tiene tamaño 3, sus atributos se rellenan con valores por defecto.
	 */
	static bool decode(const Node& node, Modelo::EntidadWrapper& rhs);
};

} /* namespace YAML */

#endif /* SERIALIZACION_ENTIDAD_H_ */
