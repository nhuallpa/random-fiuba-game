/*
 * JointMaker.cpp
 *
 *  Created on: Oct 9, 2013
 *      Author: lucia
 */

#include "JointMaker.h"

namespace simulador {

b2GearJoint* JointMaker::crearGearJoint(b2World* mundo, b2Body* bodyA, b2Body* bodyB,
		b2Joint* jointA, b2Joint* jointb, float ratio) {
	if ((bodyA != NULL) && (bodyB != NULL) && (jointA != NULL) && (jointb != NULL)){
		b2GearJointDef gearJointDef;
		gearJointDef.bodyA = bodyA;
		gearJointDef.bodyB = bodyB;
		gearJointDef.joint1 = jointA;
		gearJointDef.joint2 = jointb;
		gearJointDef.ratio = ratio;
		//No sé si este casteo es necesario.
		b2GearJoint* engranaje = (b2GearJoint*) mundo->CreateJoint( &gearJointDef );
		return engranaje;
	}
	return NULL;
}

b2RevoluteJoint* JointMaker::crearRevoluteJoint(b2World* mundo, b2Body* soporte,
	b2Body* cuerpo, bool habilitarMotor, float velocidadMotor, float maxTorque) {
	b2RevoluteJointDef revoluteJointDef;
	revoluteJointDef.bodyA = soporte;
	revoluteJointDef.bodyB = cuerpo;
	revoluteJointDef.collideConnected = false;
	revoluteJointDef.localAnchorA.Set(0,0);
	revoluteJointDef.localAnchorB.Set(0,0);
	revoluteJointDef.enableMotor = habilitarMotor;
	revoluteJointDef.motorSpeed = velocidadMotor;
	revoluteJointDef.maxMotorTorque = maxTorque;
	//No sé si este casteo es necesario.
	b2RevoluteJoint* joint = (b2RevoluteJoint*) mundo->CreateJoint( &revoluteJointDef );
	return joint;

}

b2RevoluteJoint* JointMaker::crearRevoluteJoint(b2World* mundo, b2Body* soporte,
	b2Body* cuerpo, bool habilitarMotor, float velocidadMotor, float maxTorque, b2Vec2 anchor) {
	b2RevoluteJointDef revoluteJointDef;
	revoluteJointDef.bodyA = soporte;
	revoluteJointDef.bodyB = cuerpo;
	revoluteJointDef.collideConnected = false;
	revoluteJointDef.localAnchorA.Set(0,0);
	revoluteJointDef.localAnchorB.Set(anchor.x,anchor.y);
	revoluteJointDef.enableMotor = habilitarMotor;
	revoluteJointDef.motorSpeed = velocidadMotor;
	revoluteJointDef.maxMotorTorque = maxTorque;
	//No sé si este casteo es necesario.
	b2RevoluteJoint* joint = (b2RevoluteJoint*) mundo->CreateJoint( &revoluteJointDef );
	return joint;

}

b2Body* JointMaker::crearEdge(b2Vec2 desde, b2Vec2 hasta, b2World* mundo) {
	b2BodyDef myBodyDef;
	b2FixtureDef myFixtureDefBorde;
	b2EdgeShape edgeShape;
	edgeShape.Set( desde, hasta );
	myFixtureDefBorde.shape = &edgeShape;
	myBodyDef.type = b2_staticBody;
	myBodyDef.position.Set(0,0);
	b2Body* staticBody = mundo->CreateBody(&myBodyDef);
	staticBody->CreateFixture(&myFixtureDefBorde);
	return staticBody;
}

} /* namespace simulador */
