/*
 * EntidadCorreable.cpp
 *
 *  Created on: Oct 13, 2013
 *      Author: rick
 */

#include "EntidadCorreable.h"

namespace Modelo {

EntidadCorreable::EntidadCorreable()
	: Modelo::Entidad()
{
}


EntidadCorreable::EntidadCorreable(Modelo::TipoElemento clase, Vec2 centro, Vec2 tamanio, float angulo)
	: Modelo::Entidad(clase, centro, tamanio, angulo)
{
}


EntidadCorreable::~EntidadCorreable() {
	for(Entidad* puente: this->elemPuenteAtado){
		if (puente != NULL) {
			if (puente->entidadExtremoA == this) {
				puente->entidadExtremoA = NULL;
				puente->puntoDeLigaduraEntidadA = Vec2();
			}

			if (puente->entidadExtremoB == this) {
				puente->entidadExtremoB = NULL;
				puente->puntoDeLigaduraEntidadB = Vec2();
			}
		}
	}
}


bool EntidadCorreable::esCorreable() const {
	return true;
}


bool EntidadCorreable::esNoMovil() const {
	return true;
}


bool EntidadCorreable::tieneElemPuenteAtado() const {
	if (!this->elemPuenteAtado.empty()) {
		return true;
	}
	return false;
}


std::list<Vec2> EntidadCorreable::lugarDondeSePuedeUnirBase() const {
	std::list<Vec2> lista;
	lista.push_back(centro);
	return lista;
}


} /* namespace Modelo */
