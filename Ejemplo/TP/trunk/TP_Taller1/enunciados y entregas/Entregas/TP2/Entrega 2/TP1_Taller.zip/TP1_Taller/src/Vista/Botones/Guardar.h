/*
 * Guardar.h
 *
 *  Created on: 14/09/2013
 *  Last Amended: 15/09/2013
 *      Author: natuchis
 */

#ifndef GUARDAR_H_
#define GUARDAR_H_

#include "Vista/Boton.h"
#include "Modelo/Escenario.h"
#include "Log/Suceso.h"

#include <fstream>
#include <iostream>
using namespace std;

class Guardar: public Boton {
public:
	Guardar(const FuentePosicion& fuente, Dibujable *destino, Escenario* escenario, std::string pathArch);
	virtual ~Guardar();
};

#endif /* GUARDAR_H_ */
