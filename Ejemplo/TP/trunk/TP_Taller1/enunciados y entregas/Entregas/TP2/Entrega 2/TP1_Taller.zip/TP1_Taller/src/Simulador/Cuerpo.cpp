/*
 * Cuerpo.cpp
 *
 *  Created on: Oct 4, 2013
 *      Author: lucia
 */

#include "Cuerpo.h"
#include <iostream>
#include <stdio.h>
namespace simulador {

Cuerpo::Cuerpo()
	: cuerpo(nullptr)
	, posicionInicial()
	, m_mundo(nullptr)
{
}

Cuerpo::Cuerpo(b2Body *cuerpo, b2Vec2 posicionInicial, b2World *m_mundo)
	: cuerpo(cuerpo)
	, posicionInicial(posicionInicial)
	, m_mundo(m_mundo)
{
}

Cuerpo::~Cuerpo() {
}

void Cuerpo::tocarse(Cuerpo*, b2World*) {
}

void Cuerpo::conectarA(simulador::Engranaje*, b2World*) {
}

} /* namespace simulador */
