#include "Controlador/Controlador.h"
#include "Log/Logger.h"
#include "Log/Suceso.h"
#include "Modelo/Escenario.h"
#include "Modo/ModoUsuario.h"
#include "Modo/ModoEdicion.h"
#include "Serializacion/Escenario.h"
#include "Utils/ConvertStr.h"
#include "Utils/make_unique.h"
#include "Vista/Contenedor.h"
#include "Vista/FiguraVista.h"
#include "Vista/Ventana.h"
#include "Simulador/Simulador.h"

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <yaml-cpp/yaml.h>
#include <iostream>
#include <memory>

using namespace std;

void cargarEscenario (std::string path, Escenario& escenario) {
	try {
		YAML::Node nodo = YAML::LoadFile (path);
		YAML::Mark marca = nodo.mark();

		if (nodo["escenario"].IsNull() || !nodo["escenario"].IsDefined()) {
			ConvertStr output(marca, "No existe el Escenario.");
			Log::Suceso (Log::ERROR, output.getString());
		}
		else {
			escenario = nodo["escenario"].as<Escenario>();
//
//			Modelo::Mundo re_mundo = escenario.mundo;
//			string path = escenario.pathFondo;
//			for (Modelo::Mundo::iterator iter = re_mundo.begin(); iter != re_mundo.end(); ++iter) {
//				cout << (*iter)->centro.x << " "
//						<< (*iter)->centro.y << " "
//						<< (*iter)->tamanio.x << " "
//						<< (*iter)->tamanio.y << " "
//						<< (*iter)->angulo << endl;
//			}
//			cout << "Path: " << path << endl;
		}

	} catch(YAML::ParserException& e) {
		cout << e.what() << "\n";
	}
	catch (YAML::BadFile& e) {
		string output("No se puede cargar el archivo especificado. Se crea Escenario vacio con imagen por defecto.");
		Log::Suceso (Log::ERROR, output);
	}
	catch (YAML::TypedBadConversion<Escenario>& e) {
		ConvertStr output(e.mark, "No se puede convertir a Escenario.");
		Log::Suceso (Log::ERROR, output.getString());
	}
}

/* Usado para garantizar que tengo todas las librerias andando antes de empezar a trabajar
 * sobre la logica del programa, y para forzar que se destruyan todos los objetos del
 * programa antes de cerrar las librerias.
 */
int mainJuego (char *pathEscenario) {

	Escenario escenario;
	cargarEscenario(pathEscenario, escenario);

	//Se crea la ventana principal.
	Ventana window(600, 500, "The Incredible Machine");
	Controlador controlador(&window);
	std::unique_ptr<Modo::ModoJuego> modo;
	modo = make_unique<Modo::ModoEdicion>(&window, &escenario, pathEscenario);

	uint32 ultimo = SDL_GetTicks();
	//Ciclo infinito principal
	while (true) {
		SDL_Event event;
		while (SDL_PollEvent(&event) != 0) {
			if (event.type == SDL_QUIT) {
				FiguraVista::finalizar();
				return 0;
			} else {
				controlador.handle(event);
			}
		}

		/* cada modo es responsable de regular su tiempo */
		uint32 ahora = SDL_GetTicks();
		Modo::EstadoJuego estado = modo->iteracionPrincipal(ahora - ultimo);
//		cout << ahora - ultimo << endl;
		if (estado != modo->estado()) {
			modo = modo->transicion(estado);
		}
		SDL_Delay(5);
		ultimo = ahora;
	}

	return 0;
}

int main (int argc, char *argv[]) {

	//Creo los logger
	Log::Logger cout_logger(Log::FATAL | Log::ERROR);
	Log::Logger file_logger("Log.txt", Log::ALL);

	if (argc != 2) {
		Log::Suceso(Log::FATAL, "Cantidad de argumentos invalido. \n Ingreso correcto: TP_Taller1 <path de archivo YAML>");
		return -1;
	}

	if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
		std::string mensaje("Fallo al iniciar SDL: ");
		mensaje += SDL_GetError();
		Log::Suceso(Log::FATAL, mensaje);
		return -2;
	} else {
		Log::Suceso(Log::INFO, "SDL2 iniciado correctamente.");
	}

	if (TTF_Init() != 0) {
		std::string mensaje("Fallo al iniciar SDL2_ttf: ");
		mensaje += TTF_GetError();
		Log::Suceso(Log::FATAL, mensaje);
		return -3;
	} else {
		Log::Suceso(Log::INFO, "SDL2_ttf iniciado correctamente.");
	}

	int retval = mainJuego(argv[1]);

	TTF_Quit();
	SDL_Quit();

	return retval;
}
