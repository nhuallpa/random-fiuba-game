/*
 * Globo.h
 *
 *  Created on: Oct 4, 2013
 *      Author: lucia
 */

#ifndef GLOBO_H_
#define GLOBO_H_
#include "Pelota.h"
namespace simulador {

//Implementa pelota porque básicamente es una pelota de helio.
class Globo: public Pelota {
public:
	Globo(b2Vec2 posInicial, b2World* mundo, float radio, Modelo::Entidad* entidad);
	void vivir();
	virtual ~Globo();
};

} /* namespace simulador */
#endif /* GLOBO_H_ */
