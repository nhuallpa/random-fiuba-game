/*
 * TipoElemento.cpp
 *
 *  Created on: Oct 11, 2013
 *      Author: lucia
 */

#include "TipoElemento.h"

#include "Log/Suceso.h"
#include "Utils/ConvertStr.h"
#include "Utils/YAMLHelper.h"

namespace YAML {

Node convert<Modelo::TipoElemento>::encode(const Modelo::TipoElemento& rhs) {
		Node node;
		node.push_back(Modelo::tipoElementoToString(rhs));
		return node;
}

bool convert<Modelo::TipoElemento>::decode(const Node& node, Modelo::TipoElemento& rhs) {
	YAML::Mark marca = node.mark();
	std::string msj = "";

	if (!node.IsSequence() || node.size() != 1) {
		ConvertStr output(marca, "No se puede leer clase.");
		Log::Suceso (Log::ERROR, output.getString());
	} else {
		rhs = Modelo::stringToTipoElemento(YAML_leer<std::string>(node[0], "clase"));
	}
	return true;
}

} /* namespace YAML */
