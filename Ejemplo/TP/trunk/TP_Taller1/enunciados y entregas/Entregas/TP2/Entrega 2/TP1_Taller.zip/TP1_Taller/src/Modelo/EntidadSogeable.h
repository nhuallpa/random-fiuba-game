/*
 * EntidadSogeable.h
 *
 *  Created on: Oct 13, 2013
 *      Author: rick
 */

#ifndef ENTIDADSOGEABLE_H_
#define ENTIDADSOGEABLE_H_

#include "Entidad.h"

namespace Modelo {


class EntidadSogeable: public Modelo::Entidad {

public:
	EntidadSogeable();
	explicit EntidadSogeable (Modelo::TipoElemento clase, Vec2 centro = Vec2(0, 0),
			Vec2 tamanio = Vec2(0, 0), float angulo = 0.0f);
	virtual ~EntidadSogeable();

	virtual bool esSogeable() const;
	virtual bool tieneUnElemPuenteAtado() const;

};

} /* namespace Modelo */

#endif /* ENTIDADSOGEABLE_H_ */
