/*
 * PelotaBasquet.h
 *
 *  Created on: Oct 4, 2013
 *      Author: lucia
 */

#ifndef PELOTABASQUET_H_
#define PELOTABASQUET_H_
#include "Pelota.h"
namespace simulador {

class PelotaBasquet:public Pelota {
public:
	PelotaBasquet(b2Vec2 posInicial, b2World* mundo, float radio, Modelo::Entidad* entidad);
	virtual ~PelotaBasquet();
};

} /* namespace simulador */
#endif /* PELOTABASQUET_H_ */
