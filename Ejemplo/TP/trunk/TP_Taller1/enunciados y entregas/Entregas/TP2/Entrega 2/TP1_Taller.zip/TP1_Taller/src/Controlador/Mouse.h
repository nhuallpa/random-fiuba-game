/*
 * Mouse.h
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#ifndef MOUSE_H_
#define MOUSE_H_

#include "Vista/Interfases/OrigenDestinoDibujo.h"
#include "Vista/Contenedor.h"
#include "Utils/Rect.h"
#include "Cursor.h"

union SDL_Event;
class Vec2;
class Cursor;

namespace vista {
	class Elemento;
	class ClickInfo;
}

namespace controlador {

class Mouse {
public:
	Mouse();
	virtual ~Mouse();

	void iniciarSeleccion(const Ventana *ventana, vista::ClickInfo info);
	void iniciarClickeo(vista::ClickInfo info);
	void iniciarResize(vista::ClickInfo info);
	void iniciarRotacion(vista::ClickInfo info);
	void unir(const Ventana *ventana, vista::ClickInfo info);
	bool estoyClickeando();
	void cambiarFormas(vista::ClickInfo info);

	void realizarMovimiento(SDL_Event* event);
	Vec2 getPosicionMouse() const;

	void soltar(Ventana *ventana);

	vista::Elemento* clonarDeToolbar(Dibujable* window, Contenedor* contenedorRaiz);

	void cambiarModoCursor();
	void finalizarUnion();

private:
	bool arrastrando;
	bool rotando;
	bool clickeando;
	bool resizeando;
	bool uniendo;
	vista::Elemento* elemento;
	Vec2 posClickAnterior;

	Cursor *cursorDefault;
	Cursor *cursorRotar;
	Cursor *cursorDosClicks;
	Cursor *cursorResize;

	unsigned cantClickeados;
	FiguraVista *figura;
};

} /* namespace controlador */
#endif /* MOUSE_H_ */
