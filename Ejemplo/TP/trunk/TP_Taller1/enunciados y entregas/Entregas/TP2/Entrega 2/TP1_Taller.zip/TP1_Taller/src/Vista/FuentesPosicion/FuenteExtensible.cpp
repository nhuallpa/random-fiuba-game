/*
 * FuenteExtensible.cpp
 *
 *  Created on: Oct 13, 2013
 *      Author: lucia
 */

#include "FuenteExtensible.h"

#include "Log/Suceso.h"
#include "Vista/Canvas.h"
#include "Vista/InfoFiguras.h"

FuenteExtensible::FuenteExtensible(Modelo::EntidadWrapper nEntidad, Canvas *canvas)
	: entidad(std::move(nEntidad))
	, canvas(canvas)
	, anchoLinea(vista::InfoFiguras::datos[entidad.clase()].tamCanvas.y)
{
}

Rect FuenteExtensible::getSuperficie () const {
	Vec2 tamModelo = entidad.tamanio();
	tamModelo.y = anchoLinea;
	Rect modelado = Rect::deCentro(entidad.centro(), tamModelo);
	Rect destinoVista = Rect(Vec2(), canvas->getSuperficie().tam());
	Rect visible = modelado.cambioCoordenadas(canvas->getRegionModelo(), destinoVista);
	return visible;
}

void FuenteExtensible::setSuperficie (const Rect& val)
{
}

Vec2 FuenteExtensible::getTamPadre () const {
	return canvas->getSuperficie().tam();
}

void FuenteExtensible::padreResizeado (Vec2) {
}

float FuenteExtensible::getAngulo () const {
	return entidad.angulo();
}

void FuenteExtensible::setAngulo (float val) {
	entidad.angulo() = val;
}

FuentePosicion* FuenteExtensible::clonar() const {
	return new FuenteExtensible(*this);
}

Modelo::EntidadWrapper FuenteExtensible::getEntidad()
{
	return entidad;
}

FuenteExtensible::~FuenteExtensible() {
}

