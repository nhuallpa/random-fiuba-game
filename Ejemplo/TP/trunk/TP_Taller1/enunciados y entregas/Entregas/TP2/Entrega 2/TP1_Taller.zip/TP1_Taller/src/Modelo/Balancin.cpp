/*
 * Balancin.cpp
 *
 *  Created on: Oct 13, 2013
 *      Author: rick
 */

#include "Balancin.h"

namespace Modelo {

Balancin::Balancin()
	: Modelo::EntidadSogeable()
{
}


Balancin::Balancin(Modelo::TipoElemento clase, Vec2 centro, Vec2 tamanio, float angulo)
	: Modelo::EntidadSogeable(clase, centro, tamanio, angulo)
{
}


Balancin::~Balancin() {
	if ( !this->elemPuenteAtado.empty() ) {
		for(Entidad* puente: this->elemPuenteAtado) {
			if ( puente->entidadExtremoA == this ) {
				puente->entidadExtremoA = NULL;
				puente->puntoDeLigaduraEntidadA = Vec2();
			}

			if ( puente->entidadExtremoB == this ) {
				puente->entidadExtremoB = NULL;
				puente->puntoDeLigaduraEntidadB = Vec2();
			}
		}
	}
}


bool Balancin::esNoMovil() const {
	return true;
}


std::list<Vec2> Balancin::lugarDondeSePuedeUnirBase() const {
	std::list<Vec2> lista;
	Vec2 offset = Vec2(0.4, 0) * tamanio.x;
	lista.push_back(centro + offset);	// puntos extremos izquierda y derecho, centrales
	lista.push_back(centro - offset);
	return lista;
}


} /* namespace Modelo */
