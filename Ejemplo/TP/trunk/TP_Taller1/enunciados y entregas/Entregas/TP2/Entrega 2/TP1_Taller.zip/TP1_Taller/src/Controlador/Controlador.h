/*
 * Controlador.h
 *
 *  Created on: Sep 12, 2013
 *      Author: lucia
 */

#ifndef CONTROLADOR_H_
#define CONTROLADOR_H_

#include "Mouse.h"
#include "Teclado.h"

class Ventana;
class Contenedor;

class Controlador {
public:
	Controlador(Ventana*);
	void handle(SDL_Event event);
	virtual ~Controlador();
	Contenedor* getContenedorClickeado();
private:
	controlador::Mouse mouse;
	controlador::Teclado teclado;
	Ventana* window;
};

#endif /* CONTROLADOR_H_ */
