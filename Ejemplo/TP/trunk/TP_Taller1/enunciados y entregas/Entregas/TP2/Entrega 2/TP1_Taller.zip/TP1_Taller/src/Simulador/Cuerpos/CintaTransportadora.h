/*
 * CintaTransportadora.h
 *
 *  Created on: 04/10/2013
 *      Author: stephanie
 */

#ifndef CINTATRANSPORTADORA_H_
#define CINTATRANSPORTADORA_H_

#include "../Cuerpo.h"
#include "CuerpoRotativo.h"
#include "Motor.h"
#include <list>
#include "../../Modelo/Entidad.h"

namespace simulador {

class CintaTransportadora: public simulador::Cuerpo {
public:
	CintaTransportadora(b2Vec2 posInicial, b2World* mundo, b2Vec2 tam, Modelo::Entidad* entidad);
	virtual ~CintaTransportadora();
	void vivir();
	void setSentidoSegunCuerpoRotativo(CuerpoRotativo* cuerpoRotativo);

private:

	void crearCinta(b2World* mundo);
	b2Body* crearBox(float x, float y, float ancho);
	void modelarContacto();
	void setearVelocidad();

	b2Vec2 posicion;
	b2Vec2 dimensiones;

	b2Body* rectArriba;
	b2Body* rectAbajo;

	Engranaje* gear1;
	Engranaje* gear2;
	float impulso;
	CuerpoRotativo* conectadoACuerpo;
	float velocidad;
	bool engranajesSeteados;

};

} /* namespace simulador */
#endif /* CINTATRANSPORTADORA_H_ */
