/*
 * Motor.cpp
 *
 *  Created on: 04/10/2013
 *      Author: stephanie
 */

#include "Motor.h"

namespace simulador {

Motor::Motor(b2Vec2 posInicial, b2World* mundo, float angulo, float radio, bool sentidoHorario, bool sentidoAntihorario, Modelo::Entidad* entidad)
     : CuerpoRotativo(posInicial, mundo, angulo, radio, sentidoHorario, sentidoAntihorario, true, entidad)
{
	//cambio el userData
	this->cuerpo->SetUserData(this);
	Vec2 p1;
	p1.x = entidad->centro.x-entidad->tamanio.x/2;
	p1.y = entidad->centro.y+entidad->tamanio.y/2;
	Vec2 p2;
	p2.x = entidad->centro.x+entidad->tamanio.x/2;
	p2.y = entidad->centro.y+entidad->tamanio.y/2;
	Vec2 p3;
	p3.x = entidad->centro.x-entidad->tamanio.x/2;
	p3.y = entidad->centro.y-entidad->tamanio.y/2;
	Vec2 p4;
	p4.x = entidad->centro.x+entidad->tamanio.x/2;
	p4.y = entidad->centro.y-entidad->tamanio.y/2;

	JointMaker::crearEdge(p1, p2, mundo);
	JointMaker::crearEdge(p3, p4, mundo);
	JointMaker::crearEdge(p1, p3, mundo);
	JointMaker::crearEdge(p2, p4, mundo);

}


Motor::~Motor() {
	// TODO Auto-generated destructor stub
}

} /* namespace simulador */
