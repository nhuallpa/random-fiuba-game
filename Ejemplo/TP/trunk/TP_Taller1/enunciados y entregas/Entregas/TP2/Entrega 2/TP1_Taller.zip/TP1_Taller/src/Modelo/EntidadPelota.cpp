/*
 * EntidadMovilPelota.cpp
 *
 *  Created on: Oct 12, 2013
 *      Author: rick
 */

#include "EntidadPelota.h"

namespace Modelo {

EntidadPelota::EntidadPelota()
	: Modelo::Entidad()
{
}


EntidadPelota::EntidadPelota(Modelo::TipoElemento clase, Vec2 centro, Vec2 tamanio, float angulo)
	: Modelo::Entidad(clase, centro, tamanio, angulo)
{
}


EntidadPelota::~EntidadPelota() {
}


bool EntidadPelota::esPelota() const {
	return true;
}


bool EntidadPelota::esMovil() const {
	return true;
}


} /* namespace Modelo */
