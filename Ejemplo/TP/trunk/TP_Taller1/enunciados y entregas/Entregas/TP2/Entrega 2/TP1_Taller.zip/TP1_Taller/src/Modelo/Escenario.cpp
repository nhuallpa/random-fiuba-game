/*
 * Escenario.cpp
 *
 *  Created on: 25/09/2013
 *  Last Amended: 25/09/2013
 *      Author: natuchis
 */

#include "Escenario.h"

#include "Log/Suceso.h"
#include <string>

Escenario::Escenario()
	: pathFondo("imagenes/fondos/url.jpeg")
	, mundo()
{
}


Escenario::Escenario(std::string path, Modelo::Mundo mundo)
	: pathFondo(path)
	, mundo(mundo)
{
}

/*
Escenario::Escenario(const Escenario& unEscenario)
	: pathFondo(unEscenario.pathFondo)
	, mundo()
{
	this->mundo = *(unEscenario.mundo.copiaProfunda());
}
*/

Escenario::~Escenario() {
}
