#ifndef CANVAS_H_
#define CANVAS_H_

#include "Contenedor.h"

#include "Utils/Rect.h"

class FuentePosicion;
class DestinoDibujo;
class FiguraVista;
class Escenario;
namespace Modelo {
	class Mundo;
}

class Canvas : public Contenedor
{
public:
	Canvas (FuentePosicion* fuente, DestinoDibujo* destino,
	        Escenario *escenario, const Rect& regionModeloAMostrar);
	virtual ~Canvas ();

	Vec2 tamUnidadLogica() const;
	bool aEliminar (Vec2 posicionRespectoPadre);
	virtual bool recibirFigura (const FiguraVista *elemento);

	void setBackground(std::string filename, DestinoDibujo* destino);

private:
	Escenario* escenario;
	Rect regionModelo;
};

#endif /* CANVAS_H_ */
