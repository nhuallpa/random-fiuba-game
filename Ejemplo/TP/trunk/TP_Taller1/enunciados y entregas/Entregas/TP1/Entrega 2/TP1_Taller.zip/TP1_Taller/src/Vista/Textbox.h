/*
 * Textbox.h
 *
 *  Created on: 24/09/2013
 *      Author: rick
 */

#ifndef TEXTBOX_H_
#define TEXTBOX_H_

#include "Textura.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "FuentesPosicion/FuenteTexto.h"
#include "Interfases/Elemento.h"
#include "LayoutInfo.h"
#include "Texto.h"
#include "Imagen.h"

class Textbox : public interfases::Elemento {

public:

	Textbox(FuentePosicion* fuente, DestinoDibujo* destino);
	virtual ~Textbox();
	virtual LayoutInfo getLayoutInfo();
	
	void regenerar();
	virtual void dibujarse(DestinoDibujo* destino);
	virtual void grabarCaracter(char caracter);
	virtual bool preparadoParaTexto();
	virtual void prepararParaEscritura();
	virtual void reaccionar();
	void limpiarTexto();

	std::string getTexto();

private:
	Textura* apariencia;
	Texto* texto;
	bool preparadoParaEscritura;
	Imagen* fondo;
};

#endif /* TEXTBOX_H_ */

