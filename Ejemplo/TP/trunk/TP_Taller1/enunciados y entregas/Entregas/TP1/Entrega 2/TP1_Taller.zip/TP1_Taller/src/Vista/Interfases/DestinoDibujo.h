#ifndef DESTINODIBUJO_H_
#define DESTINODIBUJO_H_

struct SDL_Texture;
struct SDL_Renderer;
class Vec2;

class DestinoDibujo
{
public:
	DestinoDibujo () {}
	virtual ~DestinoDibujo () {}

	virtual SDL_Texture* getTextureW() = 0;
	virtual SDL_Renderer* getRenderer() = 0;
	virtual Vec2 tamDestino() const = 0;
};

#endif /* DESTINODIBUJO_H_ */
