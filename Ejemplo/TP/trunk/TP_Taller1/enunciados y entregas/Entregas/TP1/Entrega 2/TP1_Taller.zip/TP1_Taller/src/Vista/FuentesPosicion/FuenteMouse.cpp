#include "FuenteMouse.h"

#include "Controlador/Mouse.h"
#include "Vista/Ventana.h"

FuenteMouse::FuenteMouse (const Ventana *ventana, const controlador::Mouse *mouse,
                          FuentePosicion* fuenteVieja)
	: ventana(ventana)
	, mouse(mouse)
	, superficieBase()
	, angulo(fuenteVieja->getAngulo())
{
	superficieBase.setTam(fuenteVieja->getSuperficie().tam());
	superficieBase.setCentro(Vec2());
}

FuenteMouse::FuenteMouse (const FuenteMouse &rhs)
	: ventana(rhs.ventana)
	, mouse(rhs.mouse)
	, superficieBase(rhs.superficieBase)
	, angulo(rhs.angulo)
{
}

FuenteMouse::~FuenteMouse ()
{
}

Rect FuenteMouse::getSuperficie ()
{
	Rect retval(superficieBase);
	retval.trasladar(mouse->getPosicionMouse());
	return retval;
}

void FuenteMouse::setSuperficie (const Rect&)
{
}

Vec2 FuenteMouse::getTamPadre ()
{
	return ventana->tamDestino();
}

float FuenteMouse::getAngulo ()
{
	return angulo;
}

void FuenteMouse::setAngulo (float nAngulo)
{
	angulo = nAngulo;
}

FuentePosicion* FuenteMouse::clonar() const
{
	return new FuenteMouse(*this);
}
