/*
 * ToolBar.cpp
 *
 *  Created on: 15/09/2013
 *      Author: stephanie
 */

#include "ToolBar.h"

#include "Canvas.h"
#include "Imagen.h"
#include "LayoutInfo.h"
#include "Textura.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "FuentesPosicion/FuenteAbsoluta.h"
#include "Utils/Rect.h"
#include <algorithm>
#include <SDL2/SDL_rect.h>

const int ToolBar::espacioEntreFiguras = 20;
const int ToolBar::desplazamientoInicial = 10;
const float ToolBar::desplazamientoFraccional = 0.02f;
const float ToolBar::tamFiguraEnUL = 10.0;

ToolBar::ToolBar(FuentePosicion* fuente, DestinoDibujo* destino, Canvas *canvas)
       : Contenedor(fuente, destino)
       , posicionEnToolbar(desplazamientoInicial)
       , canvas(canvas)
{
}

ToolBar::~ToolBar() {
}

void ToolBar::addElemento(interfases::Elemento* fig) {
	listaElementos.push_back(fig);
}

void ToolBar::subirToolBar(){

	int y = listaElementos.back()->getSuperficie().origen().y;
	y = y + listaElementos.back()->getSuperficie().aSDL_Rect().h;

	if (y > fuente->getSuperficie().aSDL_Rect().h){
		posicionEnToolbar -= fuente->getSuperficie().tam().y * desplazamientoFraccional;
	}
}

void ToolBar::bajarToolBar(){
	int y = listaElementos.front()->getSuperficie().aSDL_Rect().y;
	if (y <= fuente->getSuperficie().aSDL_Rect().y){
		posicionEnToolbar += fuente->getSuperficie().tam().y * desplazamientoFraccional;
	}
}

void ToolBar::desplazarHaciaAbajo(Vec2){
	bajarToolBar();
}

void ToolBar::desplazarHaciaArriba(Vec2){
	subirToolBar();
}

void ToolBar::regenerar() {

	int posicionOrigenEnToolbar = this->posicionEnToolbar;
	for (std::list<interfases::Elemento*>::iterator it = listaElementos.begin(); it != listaElementos.end(); it++){
		interfases::Elemento* elemento = *it;
		actualizarSuperficiesFiguras(elemento);
		actualizarPosicionEnToolbar(elemento->getSuperficie());
	}
	posicionEnToolbar = posicionOrigenEnToolbar;

	Contenedor::regenerar();
}

interfases::Elemento* ToolBar::clonar(Vec2 posicionMouse) const{
	interfases::Elemento *el = const_cast<ToolBar*>(this)->buscarElemento(posicionMouse);
	interfases::Elemento *elementoCopia = NULL;
	if(el != NULL) {
		elementoCopia = el->clonar();
	}
	return elementoCopia;
}

LayoutInfo ToolBar::getLayoutInfo(){
	Vec2 tamFigura = canvas->tamUnidadLogica() * tamFiguraEnUL;

	Vec2 tamMinimo = tamFigura;
	Vec2 tamPreferido = (tamFigura * Vec2(1.5, 3.0) + getSuperficie().tam()) / 2;
	return LayoutInfo(tamPreferido, tamMinimo, false, true);
}

int ToolBar::getPosicionEnToolbar(){
	return posicionEnToolbar;
}

void ToolBar::actualizarPosicionEnToolbar(Rect fig){
	posicionEnToolbar += fig.aSDL_Rect().h + espacioEntreFiguras;
}

void ToolBar::actualizarSuperficiesFiguras(interfases::Elemento* figura){
	Rect superficie;
	float anchoToolbar = this->getSuperficie().tam().x;

	Vec2 centroSuperior(anchoToolbar/2, this->getPosicionEnToolbar());
	Vec2 nTam = canvas->tamUnidadLogica() * tamFiguraEnUL;

	superficie.setTam(nTam);
	superficie.setCentro(centroSuperior + Vec2(0.0, nTam.y/2));

	figura->setSuperfice(superficie);
}
