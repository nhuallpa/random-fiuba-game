#include "ConstantesVista.h"

namespace constantesVista {
	const std::string ConstantesVista::imagenFondo = "imagenes/fondos/wallpaperKeepItSimple.png";
	const std::string ConstantesVista::imagenCargar = "imagenes/botones/Cargar.png";
	const std::string ConstantesVista::imagenGuardar = "imagenes/botones/Guardar.png";
	const std::string ConstantesVista::imagenSalir = "imagenes/botones/Salir.png";
	const std::string ConstantesVista::imagenFlechaUp = "imagenes/botones/FlechaUp.png";
	const std::string ConstantesVista::imagenFlechaDown = "imagenes/botones/FlechaDown.png";
}
