/*
 * Texto.h
 *
 *  Created on: 02/10/2013
 *  Last Amended: 02/10/2013
 *      Author: natuchis
 */

#ifndef TEXTO_H_
#define TEXTO_H_

#include "Interfases/OrigenDibujo.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "Log/Suceso.h"
#include "Textura.h"
#include "Utils/Rect.h"

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>

class Texto: public OrigenDibujo {
public:
	Texto(FuentePosicion* fuente, DestinoDibujo* destino);
	virtual ~Texto();

	virtual SDL_Texture* getTextureR();

	virtual void dibujarse(DestinoDibujo* destino);
	Vec2 tamanio ();
	FuentePosicion *getFuente ();

	std::string getTexto();
	void setTexto(std::string unTexto);

	void regenerar();
	void limpiarTexto();

private:
	FuentePosicion* fuente;
	Textura* apariencia;

	TTF_Font* fuenteTexto;
	SDL_Color colorTexto;
	SDL_Color colorFondo;

	std::string texto;
};

#endif /* TEXTO_H_ */
