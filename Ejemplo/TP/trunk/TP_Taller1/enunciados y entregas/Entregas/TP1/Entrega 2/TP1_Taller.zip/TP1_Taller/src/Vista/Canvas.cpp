#include "Canvas.h"

#include "Modelo/Entidad.h"
#include "Modelo/Mundo.h"
#include "Modelo/Escenario.h"
#include "Vista/FiguraVista.h"
#include "Vista/FuentesPosicion/FuenteModelo.h"

Canvas::Canvas (FuentePosicion* fuente, DestinoDibujo* destino, Escenario *escenario,
                const Rect& regionModelo)
	: Contenedor(fuente, destino)
	, escenario(escenario)
	, regionModelo(regionModelo)
{
	typedef Modelo::Mundo::iterator iter;
	for (iter it = escenario->mundo.begin(); it != escenario->mundo.end(); ++it) {
		FuenteModelo *nFuente = new FuenteModelo(*it, &regionModelo, this);
		FiguraVista *nFig = new FiguraVista((*it)->clase, nFuente, destino);
		this->addElemento(nFig);
	}
}

Canvas::~Canvas ()
{
}

Vec2 Canvas::tamUnidadLogica() const
{
	return getSuperficie().tam() / regionModelo.tam();
}

bool Canvas::recibirFigura (const FiguraVista *figura)
{
	FiguraVista *nFigura = new FiguraVista(*figura);

	Rect supFiguraVista = figura->getSuperficie();
	Rect regionVista = this->getSuperficie();
	Rect supFiguraModelo = supFiguraVista.cambioCoordenadas(regionVista, regionModelo);

	Modelo::Entidad nEntidad(nFigura->getClase(), supFiguraModelo.centro(),
	                        supFiguraModelo.tam(), 0.0);
	Modelo::Entidad *pEntidad = escenario->mundo.agregarEntidad(nEntidad);

	FuenteModelo *nFuente = new FuenteModelo(pEntidad, &regionModelo, this);
	nFuente->setAngulo(nFigura->getFuente()->getAngulo());
	nFigura->setFuente(nFuente);

	this->addElemento(nFigura);

	return true;
}

bool Canvas::aEliminar (Vec2 posicionRespectoPadre){
	Vec2 posicion = posicionRespectoPadre - this->fuente->getSuperficie().origen();

	typedef std::list<interfases::Elemento*>::iterator iterator;
	for (iterator iter = listaElementos.begin(); iter != listaElementos.end(); ++iter) {
		if ((*iter)->contiene(posicion)) {
			if ((*iter)->aEliminar(posicion) && permitirEliminaciones) {
				FuentePosicion *fuente = (*iter)->getFuente();
				FuenteModelo *fuenteCasteada = dynamic_cast<FuenteModelo*>(fuente);
				escenario->mundo.quitarEntidad(fuenteCasteada->getEntidad());
				listaElementos.remove(*iter);
			}
			break;
		}
	}
	return false;
}

void Canvas::setBackground(std::string filename, DestinoDibujo* destino){
	Contenedor::setBackground(filename, destino);
	escenario->pathFondo = filename;
}
