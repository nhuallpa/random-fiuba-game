/*
 * FuenteTexto.cpp
 *
 *  Created on: 02/10/2013
 *  Last Amended: 02/10/2013
 *      Author: natuchis
 */

#include "FuenteTexto.h"

FuenteTexto::FuenteTexto(Textbox* textbox)
	: textbox(textbox)
	, superficie()
{
}

FuenteTexto::FuenteTexto(const FuenteTexto& rhs)
	: textbox(rhs.textbox)
	, superficie(rhs.superficie)
{
}

FuenteTexto::~FuenteTexto() {
}

Rect FuenteTexto::getSuperficie() {
	return this->superficie;
}

void FuenteTexto::setSuperficie(const Rect & val) {
	this->superficie = val;
}

Vec2 FuenteTexto::getTamPadre() {
	return this->textbox->getSuperficie().tam();
}

float FuenteTexto::getAngulo() {
	return 0.0f;
}

void FuenteTexto::setAngulo(float val) {
}

FuentePosicion *FuenteTexto::clonar() const {
	return new FuenteTexto(*this);
}
