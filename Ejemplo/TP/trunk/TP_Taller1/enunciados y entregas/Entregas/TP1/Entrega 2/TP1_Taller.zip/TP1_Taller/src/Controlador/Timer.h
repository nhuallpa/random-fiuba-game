/*
 * Timer.h
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#ifndef TIMER_H_
#define TIMER_H_

namespace controlador {

class Timer {
public:
	Timer();
	virtual ~Timer();
};

} /* namespace controlador */
#endif /* TIMER_H_ */
