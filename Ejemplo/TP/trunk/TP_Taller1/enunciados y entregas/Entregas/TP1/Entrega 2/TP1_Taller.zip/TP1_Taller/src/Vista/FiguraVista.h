/*
 * FiguraVista.h
 *
 *  Created on: Sep 5, 2013
 *      Author: lucia
 */

#ifndef FIGURAVista_H_
#define FIGURAVista_H_

#include "Interfases/Elemento.h"
#include <string>

class FuentePosicion;
class Vec2;
class DestinoDibujo;
class Imagen;
class LayoutInfo;


//Esto ES una clase abstracta
class FiguraVista:public interfases::Elemento {
public:
	FiguraVista();
	FiguraVista (const FiguraVista& rhs);
	FiguraVista (const std::string& tipo, FuentePosicion *fuente, DestinoDibujo *destino);
	virtual ~FiguraVista();

	virtual void dibujarse(DestinoDibujo* window);
	virtual void setSuperfice(const Rect& val);

	virtual LayoutInfo getLayoutInfo();

	virtual bool contiene(Vec2 punto);
	virtual void mover(Vec2 incremento);
	virtual void rotar(Vec2 respectoA);
	virtual bool aEliminar (Vec2 posicion);
	virtual interfases::Elemento* clonar() const;

	static const std::map<std::string, FiguraVista>& getPrototipos();
	std::string getClase();

	static void finalizar();

private:
	Imagen* imagen;
	std::string pathImagen;
	std::string clase;

	double getAnguloRotacion(Vec2 respectoA);

	// para prototipos
	static std::map<std::string, FiguraVista> prototipos;
	static void construirPrototipos();
	FiguraVista(std::string pathImagen, std::string clase);
};

#endif /* FIGURAVista_H_ */
