#include "Elemento.h"

using namespace interfases;

#include "Vista/FuentesPosicion/FuentePosicion.h"
#include "Utils/Rect.h"

Elemento::Elemento(const FuentePosicion *nFuente)
	: visible(true)
	, fuente(NULL)
	, tienefoco(false)
{
	if (nFuente != NULL) {
		fuente = nFuente->clonar();
	}
}

Elemento::~Elemento()
{
	delete fuente;
}

void Elemento::ocultar()
{
	visible = false;
}

void Elemento::mostrar()
{
	visible = true;
}

bool Elemento::visibilidad()
{
	return visible;
}

bool Elemento::contiene(Vec2 punto)
{
	return this->getSuperficie().contiene(punto);
}

interfases::Elemento* Elemento::buscarElemento(Vec2)
{
	return this;
}

bool Elemento::aEliminar (Vec2)
{
	return false;
}

Rect Elemento::getSuperficie() const
{
	return fuente->getSuperficie();
}

FuentePosicion* Elemento::getFuente ()
{
	return fuente;
}

void Elemento::setFuente(FuentePosicion* nFuente)
{
	fuente = nFuente;
}

bool Elemento::recibirFigura (const FiguraVista *elemento)
{
	return false;
}

interfases::Elemento* Elemento::clonar() const
{
	return NULL;
}

interfases::Elemento* Elemento::clonar(Vec2 posicionMouse) const
{
	return NULL;
}

bool Elemento::preparadoParaTexto(){
	return false;
}

void Elemento::agregarFoco(){
	tienefoco = true;
}

void Elemento::quitarFoco(){
	tienefoco = false;
}

bool Elemento::tieneFoco(){
	return tienefoco;
}
