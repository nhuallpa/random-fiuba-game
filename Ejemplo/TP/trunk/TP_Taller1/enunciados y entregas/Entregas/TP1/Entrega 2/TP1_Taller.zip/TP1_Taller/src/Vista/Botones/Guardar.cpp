/*
 * Guardar.cpp
 *
 *  Created on: 14/09/2013
 *  Last Amended: 15/09/2013
 *      Author: natuchis
 */

#include "Guardar.h"

Guardar::Guardar(FuentePosicion *fuente, DestinoDibujo *destino, Escenario* escenario, std::string pathArch)
	: Boton(fuente, constantesVista::ConstantesVista::imagenGuardar, destino)
{
	this->pathImagen = constantesVista::ConstantesVista::imagenGuardar;
	this->escenario = escenario;
	this->pathArchivo = pathArch;
}

Guardar::~Guardar() {
}

std::string Guardar::getPathImagen() {
	return this->pathImagen;
}

void Guardar::reaccionar() {
	std::ofstream sal;
	sal.open(this->pathArchivo.c_str(), ofstream::out | ofstream::trunc);

	YAML::Node nodo_out;
	nodo_out["escenario"] = *escenario;

	sal << nodo_out << std::endl;
	sal.close();

	Log::Suceso (Log::INFO, "Se guardo el escenario.");
}
