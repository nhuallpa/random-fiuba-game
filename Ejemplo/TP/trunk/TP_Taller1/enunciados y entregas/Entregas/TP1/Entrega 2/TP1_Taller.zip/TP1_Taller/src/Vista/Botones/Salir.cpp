/*
 * Salir.cpp
 *
 *  Created on: 14/09/2013
 *  Last Amended: 15/09/2013
 *      Author: natuchis
 */

#include "Salir.h"

#include "Global/terminarPrograma.h"

Salir::Salir(FuentePosicion *fuente, DestinoDibujo *destino)
	: Boton(fuente, constantesVista::ConstantesVista::imagenSalir, destino)
{
	this->pathImagen = constantesVista::ConstantesVista::imagenSalir;
}

Salir::~Salir() {
}

std::string Salir::getPathImagen() {
	return this->pathImagen;
}

void Salir::reaccionar(){
	terminarPrograma();
}
