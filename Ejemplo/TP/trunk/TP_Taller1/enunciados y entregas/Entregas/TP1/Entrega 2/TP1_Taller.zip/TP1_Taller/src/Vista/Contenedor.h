/*
 * Contenedor.h
 *
 *  Created on: Sep 5, 2013
 *      Author: lucia
 */

#ifndef CONTENEDOR_H_
#define CONTENEDOR_H_

#include "Interfases/Elemento.h"
#include <list>

class FuentePosicion;
class DestinoDibujo;
class Vec2;
class Rect;
class LayoutInfo;
class Imagen;
class Textura;

class Contenedor : public interfases::Elemento {
	//Clase que contiene las figuras y esta en algun lugar de la pantalla (es dibujable)
public:
	Contenedor(FuentePosicion* fuente, DestinoDibujo* destino);
	virtual ~Contenedor();

	void addElemento(interfases::Elemento* elemento);
	virtual void quitarElemento(interfases::Elemento* elemento);

	virtual interfases::Elemento* buscarElemento(Vec2);
	virtual void actualizarElementos();

	virtual void dibujarse(DestinoDibujo* ventana);

	void setBackground(std::string filename, DestinoDibujo* destino);

	virtual LayoutInfo getLayoutInfo();

	virtual void desplazarHaciaArriba(Vec2 posicion);
	virtual void desplazarHaciaAbajo(Vec2 posicion);
	virtual bool aEliminar (Vec2 posicion);
	virtual bool recibirFigura (const FiguraVista *elemento);
	void setPermitirEliminaciones (bool permitido);

	virtual void grabarCaracter(char caracter);

	virtual interfases::Elemento* clonar(Vec2 posicionMouse ) const;
	virtual void cargar();

protected:
	std::list<interfases::Elemento*> listaElementos;
	Imagen* fondo;
	Textura* apariencia;
	bool permitirEliminaciones;

	virtual void regenerar();
};

#endif /* CONTENEDOR_H_ */
