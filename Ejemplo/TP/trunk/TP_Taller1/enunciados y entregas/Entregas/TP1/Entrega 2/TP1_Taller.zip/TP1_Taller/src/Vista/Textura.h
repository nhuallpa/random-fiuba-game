#ifndef TEXTURA_H_
#define TEXTURA_H_

#include "Interfases/DestinoDibujo.h"
#include "Interfases/OrigenDibujo.h"

class SDL_Surface;
class Vec2;

class Textura : public DestinoDibujo, public OrigenDibujo
{
public:
	Textura (DestinoDibujo& superior, SDL_Surface* surface);
	Textura (DestinoDibujo& superior, const Vec2& tam);
	virtual ~Textura ();

	void limpiar();

	virtual SDL_Renderer* getRenderer();
	virtual SDL_Texture* getTextureR();
	virtual SDL_Texture* getTextureW();
	virtual Vec2 tamDestino() const;

private:
	SDL_Renderer* renderer;
	SDL_Texture* texture;
};

#endif /* TEXTURA_H_ */
