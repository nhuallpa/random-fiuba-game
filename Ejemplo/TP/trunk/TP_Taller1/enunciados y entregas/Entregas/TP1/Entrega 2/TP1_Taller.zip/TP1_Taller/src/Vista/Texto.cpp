/*
 * Texto.cpp
 *
 *  Created on: 02/10/2013
 *  Last Amended: 02/10/2013
 *      Author: natuchis
 */

#include "Texto.h"

Texto::Texto(FuentePosicion* fuente, DestinoDibujo* destino)
	: fuente (fuente)
{
	this->fuenteTexto = TTF_OpenFont("fonts/Arial_Bold.ttf", 14);
	if (this->fuenteTexto == NULL) {
		std::string mensaje("Fallo al iniciar la fuente: ");
		mensaje += TTF_GetError();
		throw Log::Suceso(Log::FATAL, mensaje);
	}
	else {
		Log::Suceso(Log::INFO, "Fuente arial bold iniciado correctamente.");
	}

	this->texto = "imagenes/fondos/";
	this->colorTexto = {0,0,0};
	this->colorFondo = {255,255,240};

	SDL_Surface* superficieTexto = TTF_RenderText_Shaded(this->fuenteTexto, this->texto.c_str(), this->colorTexto, this->colorFondo);
	if (superficieTexto != NULL) {
		this->apariencia = new Textura(*destino,superficieTexto);
		SDL_FreeSurface(superficieTexto);
	}
}

Texto::~Texto() {
	if (apariencia != NULL) {
		delete apariencia;
	}
	if (TTF_WasInit()) {
		// para no liberar si ya cerre SDL_ttf
		TTF_CloseFont(this->fuenteTexto);
	}
}

SDL_Texture *Texto::getTextureR() {
	return this->apariencia->getTextureR();
}

void Texto::dibujarse(DestinoDibujo* destino) {
	apariencia->limpiar();
	regenerar();
	apariencia->dibujar(*destino, *fuente);
}

Vec2 Texto::tamanio () {
	return apariencia->tamDestino();
}

FuentePosicion *Texto::getFuente () {
	return fuente;
}

std::string Texto::getTexto() {
	return this->texto;
}

void Texto::setTexto(std::string unTexto) {
	this->texto = unTexto;
}

void Texto::regenerar() {
	SDL_Surface* superficieTexto = TTF_RenderText_Shaded(this->fuenteTexto, this->texto.c_str(), this->colorTexto, this->colorFondo);

	if (superficieTexto != NULL) {
		Textura* tex = new Textura(*apariencia, superficieTexto);
		SDL_FreeSurface(superficieTexto);
		if (tex != NULL){
			delete apariencia;
			apariencia = tex;
		}
	}
}

void Texto::limpiarTexto() {
	this->texto = "imagenes/fondos/";
	apariencia->limpiar();
}
