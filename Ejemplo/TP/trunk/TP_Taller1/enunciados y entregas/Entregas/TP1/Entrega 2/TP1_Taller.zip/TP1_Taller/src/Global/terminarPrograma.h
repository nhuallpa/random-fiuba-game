#ifndef TERMINARPROGRAMA_H_
#define TERMINARPROGRAMA_H_

void terminarPrograma (void);

#endif /* TERMINARPROGRAMA_H_ */
