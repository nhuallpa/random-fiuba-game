/*
 * Figura.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: lucia
 */

#include "FiguraVista.h"

#include "ConstantesVista.h"
#include "Imagen.h"
#include "LayoutInfo.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "Log/Suceso.h"
#include "Utils/Rect.h"

std::map<std::string, FiguraVista> FiguraVista::prototipos;

FiguraVista::FiguraVista ()
	: interfases::Elemento(NULL)
	, imagen(NULL)
	, pathImagen("")
	, clase("")
{
}

FiguraVista::FiguraVista (const FiguraVista& rhs)
	: interfases::Elemento(rhs)
	, imagen(NULL)
	, pathImagen(rhs.pathImagen)
	, clase(rhs.clase)
{
	if (rhs.imagen != NULL) {
		imagen = new Imagen(*rhs.imagen);
	}
}

FiguraVista::FiguraVista (const std::string& tipo, FuentePosicion *fuente,
                          DestinoDibujo *destino)
	: interfases::Elemento(fuente)
	, imagen(NULL)
	, pathImagen()
	, clase(tipo)
{
	if (prototipos.empty()) {
		construirPrototipos();
	}
	if (prototipos.find(tipo) == prototipos.end()) {
		std::string mensaje("Intento de construir figura de clase desconocida '");
		throw Log::Suceso(Log::ERROR, mensaje + tipo + "'.");
	}
	pathImagen = prototipos[tipo].pathImagen;
	imagen = new Imagen(pathImagen, destino);
}

FiguraVista::~FiguraVista() {
	delete imagen;
}

void FiguraVista::dibujarse(DestinoDibujo* window) {
	//Acordarse que las posiciones de los elementos que guardamos
	//siempre son relativas a la posicion del contenedor.
	if (visible){
		imagen->dibujar(*window, *fuente);
	}
}

void FiguraVista::setSuperfice(const Rect& val){
	this->fuente->setSuperficie(val);
}

LayoutInfo FiguraVista::getLayoutInfo(){
	return LayoutInfo(imagen->tam());
}

bool FiguraVista::contiene(Vec2 punto) {
	Vec2 puntoParalelo = punto - fuente->getSuperficie().origen() - fuente->getSuperficie().tam() / 2;

	Vec2 puntoRotado = puntoParalelo.rotar(fuente->getAngulo());

	Rect sistemaLocal = Rect::deCentro(Vec2(), fuente->getSuperficie().tam());
	Rect sistemaImagen(Vec2(), imagen->tam());
	Vec2 puntoImagen = puntoRotado.cambioCoordenadas(sistemaLocal, sistemaImagen);
	return !imagen->esTransparente(puntoImagen);
}

void FiguraVista::mover(Vec2 incremento) {
	Rect sup(fuente->getSuperficie());
	sup.trasladar(incremento);
	fuente->setSuperficie(sup);
}

void FiguraVista::rotar(Vec2 respectoA) {
	//Calculo el angulo de rotacion
	this->fuente->setAngulo(this->getAnguloRotacion(respectoA));
}

bool FiguraVista::aEliminar (Vec2 posicion) {
	return true;
}

const std::map<std::string, FiguraVista>& FiguraVista::getPrototipos() {
	if (prototipos.empty()) {
		construirPrototipos();
	}
	return prototipos;
}

std::string FiguraVista::getClase(){
	return this->clase;
}

double FiguraVista::getAnguloRotacion(Vec2 respectoA){
	Vec2 posMouse = respectoA;
	double distX = posMouse.x - this->fuente->getSuperficie().centro().x ;
	double distY = posMouse.y - this->fuente->getSuperficie().centro().y ;
	double result = atan2(distY,distX) * 180 / PI;
	return result;
}

interfases::Elemento* FiguraVista::clonar() const{
	return new FiguraVista(*this);
}

void FiguraVista::construirPrototipos(){
	prototipos["Circulo"] = FiguraVista("imagenes/objetos/figuras/Circulo.png", "Circulo");
	prototipos["Cuadrado"] = FiguraVista("imagenes/objetos/figuras/Cuadrado.png", "Cuadrado");
	prototipos["Estrella4"] = FiguraVista("imagenes/objetos/figuras/Estrella4Puntas.png", "Estrella4");
	prototipos["Estrella5"] = FiguraVista("imagenes/objetos/figuras/Estrella.png", "Estrella5");
	prototipos["Estrella6"] = FiguraVista("imagenes/objetos/figuras/Estrella6Puntas.png", "Estrella6");
	prototipos["Hexagono"] = FiguraVista("imagenes/objetos/figuras/Hexagono.png", "Hexagono");
	prototipos["Paralelogramo"] = FiguraVista("imagenes/objetos/figuras/Paralelogramo.png", "Paralelogramo");
	prototipos["Pentagono"] = FiguraVista("imagenes/objetos/figuras/Pentagono.png", "Pentagono");
	prototipos["Rombo"] = FiguraVista("imagenes/objetos/figuras/Rombo.png", "Rombo");
	prototipos["Trapecio"] = FiguraVista("imagenes/objetos/figuras/Trapecio.png", "Trapecio");
	prototipos["Triangulo"] = FiguraVista("imagenes/objetos/figuras/Triangulo.png", "Triangulo");
	prototipos["TrianguloRectangulo"] = FiguraVista("imagenes/objetos/figuras/TrianguloRect.png", "TrianguloRectangulo");
}

FiguraVista::FiguraVista(std::string pathImagen, std::string clase)
	: interfases::Elemento(NULL)
	, imagen(NULL)
	, pathImagen(pathImagen)
	, clase(clase)
{
}

void FiguraVista::finalizar(){
	prototipos.clear();
}
