/*
 * FuenteTexto.h
 *
 *  Created on: 02/10/2013
 *  Last Amended: 02/10/2013
 *      Author: natuchis
 */

#ifndef FUENTETEXTO_H_
#define FUENTETEXTO_H_

#include "FuentePosicion.h"
#include "../Textbox.h"
#include "Utils/Rect.h"

class Textbox;

class FuenteTexto: public FuentePosicion {
public:
	FuenteTexto(Textbox* textbox);
	FuenteTexto(const FuenteTexto& rhs);
	virtual ~FuenteTexto();

	virtual Rect getSuperficie ();
	virtual void setSuperficie (const Rect& val);
	virtual Vec2 getTamPadre ();

	virtual float getAngulo ();
	virtual void setAngulo (float val);

	virtual FuentePosicion* clonar() const;

private:
	Textbox* textbox;
	Rect superficie;
};

#endif /* FUENTETEXTO_H_ */
