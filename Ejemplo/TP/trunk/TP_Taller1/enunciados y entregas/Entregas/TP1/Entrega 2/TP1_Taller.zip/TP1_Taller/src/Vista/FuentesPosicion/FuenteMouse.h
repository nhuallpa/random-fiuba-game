#ifndef FUENTEMOUSE_H_
#define FUENTEMOUSE_H_

#include "Vista/FuentesPosicion/FuentePosicion.h"
#include "Utils/Rect.h"
#include "Utils/Vec2.h"

namespace controlador {
	class Mouse;
}
class Ventana;

class FuenteMouse : public FuentePosicion
{
public:
	FuenteMouse (const Ventana *ventana, const controlador::Mouse *mouse,
	             FuentePosicion* fuenteVieja);
	FuenteMouse (const FuenteMouse &rhs);
	virtual ~FuenteMouse ();

	virtual Rect getSuperficie ();
	virtual void setSuperficie (const Rect& val);
	virtual Vec2 getTamPadre ();

	virtual float getAngulo ();
	virtual void setAngulo (float val);

	virtual FuentePosicion* clonar() const;

private:
	const Ventana *ventana;
	const controlador::Mouse *mouse;
	Rect superficieBase;
	float angulo;
};

#endif /* FUENTEMOUSE_H_ */
