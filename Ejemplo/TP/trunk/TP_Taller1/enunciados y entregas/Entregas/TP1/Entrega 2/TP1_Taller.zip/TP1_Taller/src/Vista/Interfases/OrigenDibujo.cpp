#include "OrigenDibujo.h"

#include "DestinoDibujo.h"
#include "Vista/FuentesPosicion/FuentePosicion.h"
#include "Utils/Rect.h"
#include "Utils/Vec2.h"
#include <SDL2/SDL.h>

void OrigenDibujo::dibujar (DestinoDibujo& destino)
{
	SDL_Renderer *ren = destino.getRenderer();

	SDL_SetRenderTarget(ren, destino.getTextureW());
	SDL_RenderCopy(ren, getTextureR(), NULL, NULL);
	SDL_SetRenderTarget(ren, NULL);
}

void OrigenDibujo::dibujar (DestinoDibujo& destino, FuentePosicion& fuente)
{
	Rect sistOrigen(Vec2(0, 0), fuente.getTamPadre());
	Rect sistDestino(Vec2(0, 0), destino.tamDestino());
	Rect regionImagen = fuente.getSuperficie().cambioCoordenadas(sistOrigen, sistDestino);

	SDL_Rect sdlRegion(regionImagen.aSDL_Rect());

	SDL_Renderer *ren = destino.getRenderer();

	SDL_SetRenderTarget(ren, destino.getTextureW());
	SDL_RenderCopyEx(ren, getTextureR(), NULL, &sdlRegion, fuente.getAngulo(), NULL, SDL_FLIP_NONE);
	SDL_SetRenderTarget(ren, NULL);
}

