#ifndef FUENTEVENTANA_H_
#define FUENTEVENTANA_H_

#include "FuentePosicion.h"

class Ventana;

class FuenteVentana : public FuentePosicion
{
public:
	FuenteVentana (Ventana *ventana);
	FuenteVentana (const FuenteVentana& rhs);
	virtual ~FuenteVentana ();

	virtual Rect getSuperficie ();
	virtual void setSuperficie (const Rect& val);
	virtual Vec2 getTamPadre ();

	virtual float getAngulo ();
	virtual void setAngulo (float val);

	virtual FuentePosicion* clonar() const;

private:
	Ventana *ventana;
};

#endif /* FUENTEVENTANA_H_ */
