#ifndef FUENTEABSOLUTA_H_
#define FUENTEABSOLUTA_H_

#include "FuentePosicion.h"
#include "Utils/Rect.h"

class FuenteAbsoluta : public FuentePosicion
{
public:
	FuenteAbsoluta (Rect &superficie, Vec2 &tamPadre);
	FuenteAbsoluta (const FuenteAbsoluta& rhs);
	virtual ~FuenteAbsoluta ();

	virtual Rect getSuperficie ();
	virtual void setSuperficie (const Rect& val);
	virtual Vec2 getTamPadre ();

	virtual float getAngulo ();
	virtual void setAngulo (float val);

	virtual FuentePosicion* clonar() const;

private:
	Rect superficie;
	Vec2 tamPadre;
};

#endif /* FUENTEABSOLUTA_H_ */
