/*
 * FlechaDown.h
 *
 *  Created on: 16/09/2013
 *  Last Amended: 16/09/2013
 *      Author: natuchis
 */

#ifndef FLECHADOWN_H_
#define FLECHADOWN_H_

#include "Vista/Boton.h"
#include "Vista/ConstantesVista.h"
#include "Vista/Contenedor.h"
#include "Vista/ToolBar.h"

class FlechaDown: public Boton {
public:
	FlechaDown(FuentePosicion *fuente, DestinoDibujo *destino, ToolBar* toolbar);
	virtual ~FlechaDown();
	std::string getPathImagen();
	virtual void reaccionar();

private:
	std::string pathImagen;
	ToolBar* toolbar;
};

#endif /* FLECHADOWN_H_ */
