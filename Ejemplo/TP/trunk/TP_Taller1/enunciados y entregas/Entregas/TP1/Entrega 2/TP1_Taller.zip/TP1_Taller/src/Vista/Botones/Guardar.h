/*
 * Guardar.h
 *
 *  Created on: 14/09/2013
 *  Last Amended: 15/09/2013
 *      Author: natuchis
 */

#ifndef GUARDAR_H_
#define GUARDAR_H_

#include "Vista/Boton.h"
#include "Vista/ConstantesVista.h"
#include "Modelo/Escenario.h"
#include "Log/Suceso.h"

#include <fstream>
#include <iostream>
using namespace std;

class Guardar: public Boton {
public:
	Guardar(FuentePosicion *fuente, DestinoDibujo *destino, Escenario* escenario, std::string pathArch);
	virtual ~Guardar();
	std::string getPathImagen();
	virtual void reaccionar();

private:
	std::string pathImagen;
	std::string pathArchivo;
	Escenario* escenario;
};

#endif /* GUARDAR_H_ */
