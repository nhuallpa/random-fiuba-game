#include "FuenteAbsoluta.h"


FuenteAbsoluta::FuenteAbsoluta (Rect& superficie, Vec2 &tamPadre)
	: superficie(superficie)
	, tamPadre(tamPadre)
{
}

FuenteAbsoluta::FuenteAbsoluta (const FuenteAbsoluta& rhs)
	: superficie(rhs.superficie)
	, tamPadre(rhs.tamPadre)
{
}

FuenteAbsoluta::~FuenteAbsoluta ()
{
}

Rect FuenteAbsoluta::getSuperficie ()
{
	return superficie;
}

void FuenteAbsoluta::setSuperficie (const Rect& sup)
{
	superficie = sup;
}

Vec2 FuenteAbsoluta::getTamPadre ()
{
	return tamPadre;
}

float FuenteAbsoluta::getAngulo ()
{
	return 0.0f;
}

void FuenteAbsoluta::setAngulo (float)
{
}

FuentePosicion *FuenteAbsoluta::clonar() const {
	return new FuenteAbsoluta(*this);
}
