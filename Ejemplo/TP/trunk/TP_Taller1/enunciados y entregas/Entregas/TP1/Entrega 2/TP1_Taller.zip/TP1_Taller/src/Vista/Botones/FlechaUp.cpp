/*
 * FlechaUp.cpp
 *
 *  Created on: 16/09/2013
 *  Last Amended: 16/09/2013
 *      Author: natuchis
 */

#include "FlechaUp.h"

FlechaUp::FlechaUp(FuentePosicion *fuente, DestinoDibujo *destino, ToolBar* toolbar)
	: Boton(fuente, constantesVista::ConstantesVista::imagenFlechaUp, destino)
{
	this->pathImagen = constantesVista::ConstantesVista::imagenFlechaUp;
	this->toolbar = toolbar;
}

FlechaUp::~FlechaUp() {
}

std::string FlechaUp::getPathImagen() {
	return this->pathImagen;
}

void FlechaUp::reaccionar(){
	toolbar->desplazarHaciaAbajo(Vec2());
}
