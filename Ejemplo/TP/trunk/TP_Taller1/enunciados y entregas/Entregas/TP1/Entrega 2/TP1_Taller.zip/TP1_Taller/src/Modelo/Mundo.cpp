#include "Mundo.h"

#include "Entidad.h"
#include "Log/Suceso.h"
#include <cstddef>

namespace Modelo
{

Mundo::Mundo ()
{
}

Mundo::~Mundo ()
{
}

Entidad* Mundo::agregarEntidad (const Entidad &fig)
{
	if (!fig.valida()) {
		throw Log::Suceso(Log::ERROR, "Intento agregar entidad invalida");
	}
	contenido.push_back(new Entidad(fig));
	return contenido.back();
}

void Mundo::quitarEntidad (Entidad* fig)
{
	contenido.remove(fig);
	if (fig != NULL) {
		delete fig;
	}
}

Mundo::iterator Mundo::begin()
{
	return contenido.begin();
}

Mundo::iterator Mundo::end()
{
	return contenido.end();
}

Mundo::const_iterator Mundo::begin() const
{
	return contenido.begin();
}

Mundo::const_iterator Mundo::end() const
{
	return contenido.end();
}

} /* namespace Modelo */

namespace YAML
{

Node convert<Modelo::Mundo>::encode(const Modelo::Mundo& rhs) {
	Node node;
	for (Modelo::Mundo::const_iterator iter = rhs.begin(); iter != rhs.end(); ++iter) {
		node.push_back(**iter);
	}
	return node;
}

bool convert<Modelo::Mundo>::decode(const Node& node, Modelo::Mundo& rhs) {
	YAML::Mark marca = node.mark();

	if(!node.IsSequence()) {
		ConvertStr output(marca, "No se puede leer Mundo. Creado vacio.");
		Log::Suceso (Log::ERROR, output.getString());
	}
	else {
		for (unsigned i = 0; i < node.size(); ++i) {
			try {
				rhs.agregarEntidad(node[i].as<Modelo::Entidad>());
			} catch (YAML::TypedBadConversion<Modelo::Entidad>& e) {
			} catch (Log::Suceso&) {
			}
		}
	}
	return true;
}

} /* namespace YAML */
