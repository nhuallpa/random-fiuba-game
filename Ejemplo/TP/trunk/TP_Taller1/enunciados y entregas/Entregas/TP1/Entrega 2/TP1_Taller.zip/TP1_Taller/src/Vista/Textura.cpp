#include "Textura.h"

#include "Ventana.h"
#include "Log/Suceso.h"
#include "Utils/Vec2.h"
#include <SDL2/SDL.h>

Textura::Textura (DestinoDibujo& superior, SDL_Surface* surface)
	: renderer(superior.getRenderer())
	, texture(NULL)
{
	texture = SDL_CreateTextureFromSurface(superior.getRenderer(), surface);
	if (texture == NULL) {
		std::string mensaje("Textura nula: ");
		mensaje = mensaje + SDL_GetError();
		throw Log::Suceso(Log::ERROR, mensaje);
	}
}

Textura::Textura (DestinoDibujo& superior, const Vec2& tam)
	: renderer(superior.getRenderer())
	, texture(NULL)
{
	texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888,
	                            SDL_TEXTUREACCESS_TARGET, tam.x, tam.y);
	if (texture == NULL) {
		std::string mensaje("Textura nula: ");
		mensaje = mensaje + SDL_GetError();
		throw Log::Suceso(Log::ERROR, mensaje);
	}
	limpiar();
}

Textura::~Textura ()
{
	SDL_DestroyTexture(texture);
}

void Textura::limpiar()
{
	SDL_SetRenderTarget(renderer, texture);
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderClear(renderer);
	SDL_SetRenderTarget(renderer, NULL);
}

SDL_Renderer* Textura::getRenderer()
{
	return renderer;
}

SDL_Texture* Textura::getTextureR()
{
	return texture;
}

SDL_Texture* Textura::getTextureW()
{
	return texture;
}

Vec2 Textura::tamDestino() const
{
	int x, y;
	SDL_QueryTexture(texture, NULL, NULL, &x, &y);
	return Vec2(x, y);
}

