#include "Entidad.h"

#include "Log/Suceso.h"
#include "Vista/FiguraVista.h"
#include "Utils/YAMLHelper.h"

namespace Modelo
{

Entidad::Entidad ()
	: clase()
	, centro()
	, tamanio()
	, angulo()
{
}

Entidad::Entidad (std::string clase, Vec2 centro, Vec2 tamanio, float angulo)
	: clase(clase)
	, centro(centro)
	, tamanio(tamanio)
	, angulo(angulo)
{
	if (!this->valida()) {
		std::string msg("Intento crear clase inexistente '");
		msg = msg + clase + "'";
		throw Log::Suceso(Log::ERROR, msg);
	}
}

Entidad::~Entidad ()
{
}

bool Entidad::valida() const
{
	if (FiguraVista::getPrototipos().find(clase) == FiguraVista::getPrototipos().end()) {
		return false;
	} else {
		return true;
	}
}

} /* namespace Modelo */

namespace YAML
{

Node convert<Modelo::Entidad>::encode(const Modelo::Entidad& rhs) {
	Node node;
	node["clase"] = rhs.clase;
	node["posicion"] = rhs.centro;
	node["tamanio"] = rhs.tamanio;
	node["angulo"] = rhs.angulo;
	return node;
}

bool convert<Modelo::Entidad>::decode(const Node& node, Modelo::Entidad& rhs) {
	YAML::Mark marca = node.mark();

	if (!node.IsMap() || node.size() != 4) {
		ConvertStr output(marca, "No se puede leer Entidad, no es mapa o no tiene 3 atributos. Omitido.");
		Log::Suceso (Log::ERROR, output.getString());
		return false;
	} else {
		try {
			rhs.clase = YAML_leerFatal<std::string>(node["clase"], "clase");
			rhs.centro = YAML_leer<Vec2>(node["posicion"], "posicion");
			rhs.tamanio = YAML_leer<Vec2>(node["tamanio"], "tamanio");
			rhs.angulo = YAML_leer<float>(node["angulo"], "angulo");
			if (!rhs.valida()) {
				std::string msg("Intento crear clase inexistente '");
				msg = msg + rhs.clase + "'";
				ConvertStr output(marca, msg);
				throw Log::Suceso(Log::ERROR, output.getString());
			}
			if (rhs.tamanio.x < 0) {
				rhs.tamanio.x = std::abs(rhs.tamanio.x);
				ConvertStr output(marca, "El atributo tamanio.x no puede ser negativo. Se completo con su valor absoluto.");
				Log::Suceso(Log::ERROR, output.getString());
			}
			if (rhs.tamanio.y < 0) {
				rhs.tamanio.y = std::abs(rhs.tamanio.y);
				ConvertStr output(marca, "El atributo tamanio.y no puede ser negativo. Se completo con su valor absoluto.");
				Log::Suceso(Log::ERROR, output.getString());
			}
		} catch (Log::Suceso&) {
			return false;
		}
	}
	return true;
}

} /* namespace YAML */
