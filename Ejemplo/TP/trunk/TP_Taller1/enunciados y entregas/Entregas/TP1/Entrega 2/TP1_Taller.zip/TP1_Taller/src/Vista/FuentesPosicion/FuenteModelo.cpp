#include "FuenteModelo.h"

#include "Modelo/Entidad.h"
#include "Utils/Rect.h"
#include "Vista/Contenedor.h"

FuenteModelo::FuenteModelo (Modelo::Entidad *entidad
                           , const Rect *regionModelo
                           , Contenedor *contenedorDestino)
	: entidad(entidad)
	, regionModelo(regionModelo)
	, contenedorDestino(contenedorDestino)
{
}

FuenteModelo::FuenteModelo (const FuenteModelo& rhs)
	: entidad(rhs.entidad)
	, regionModelo(rhs.regionModelo)
	, contenedorDestino(rhs.contenedorDestino)
{
}

FuenteModelo::~FuenteModelo ()
{
}

Rect FuenteModelo::getSuperficie ()
{
	Rect sup(Rect::deCentro(entidad->centro, entidad->tamanio));
	return sup.cambioCoordenadas(*regionModelo, contenedorDestino->getSuperficie());
}

void FuenteModelo::setSuperficie (const Rect& val)
{
	Rect sup = val.cambioCoordenadas(contenedorDestino->getSuperficie(), *regionModelo);

	entidad->centro = sup.centro();
	entidad->tamanio = sup.tam();
}

Vec2 FuenteModelo::getTamPadre ()
{
	return contenedorDestino->getSuperficie().tam();
}

float FuenteModelo::getAngulo ()
{
	return entidad->angulo;
}

void FuenteModelo::setAngulo (float val)
{
	entidad->angulo = val;
}

Modelo::Entidad *FuenteModelo::getEntidad()
{
	return entidad;
}

FuentePosicion *FuenteModelo::clonar() const {
	return new FuenteModelo(*this);
}
