/*
 * Timer.cpp
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#include "Timer.h"

namespace controlador {

Timer::Timer() {
	// TODO Auto-generated constructor stub

}

Timer::~Timer() {
	// TODO Auto-generated destructor stub
}

} /* namespace controlador */
