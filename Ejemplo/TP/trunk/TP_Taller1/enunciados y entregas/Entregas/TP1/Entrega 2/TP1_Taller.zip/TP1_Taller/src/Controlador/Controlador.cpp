/*
 * Controlador.cpp
 *
 *  Created on: Sep 12, 2013
 *      Author: lucia
 */

#include "Controlador.h"
#include "Vista/Ventana.h"
#include "Vista/Contenedor.h"
#include "Vista/Interfases/Elemento.h"
#include <SDL2/SDL.h>
#include <iostream>

using namespace std;


Controlador::Controlador(Ventana* window, Contenedor* contenedorRaiz)
	: mouse()
	, teclado()
	, window(window)
	, contenedorRaiz(contenedorRaiz)
{
}


void Controlador::handle(SDL_Event event) {
	//Chequeo los eventos posibles:
	switch (event.type) {

	case SDL_MOUSEBUTTONDOWN:
		if (event.button.button == SDL_BUTTON_LEFT) {
			if (teclado.presionada(SDLK_LSHIFT) || teclado.presionada(SDLK_RSHIFT)) {
				contenedorRaiz->aEliminar(mouse.getPosicionMouse());
			} else {
				interfases::Elemento* elemento;
				elemento = contenedorRaiz->buscarElemento(mouse.getPosicionMouse());
				if (elemento != NULL){
					elemento->reaccionar();
					mouse.iniciarSeleccion(window, elemento, contenedorRaiz);
				}
			}
		} else if (event.button.button == SDL_BUTTON_RIGHT) {
			interfases::Elemento* elemento;
			elemento = contenedorRaiz->buscarElemento(mouse.getPosicionMouse());
			mouse.iniciarRotacion(elemento);
		}
		break;

	case SDL_MOUSEBUTTONUP:
		mouse.soltar(contenedorRaiz);
		break;

	case SDL_MOUSEMOTION:
		mouse.realizarMovimiento(&event);
		break;

	case SDL_MOUSEWHEEL:
		if (event.wheel.y > 0) {
			contenedorRaiz->desplazarHaciaAbajo(mouse.getPosicionMouse());
		} else if (event.wheel.y < 0) {
			contenedorRaiz->desplazarHaciaArriba(mouse.getPosicionMouse());
		}
		break;

	case SDL_KEYDOWN:
		teclado.presionar(event.key.keysym.sym);
		if (event.key.keysym.sym == SDLK_BACKSPACE){
			contenedorRaiz->grabarCaracter(event.key.keysym.sym);
		}

		if (event.key.keysym.sym == SDLK_RETURN){
            contenedorRaiz->cargar();
		}

		break;

	case SDL_KEYUP:
		teclado.soltar(event.key.keysym.sym);
		break;

	case SDL_TEXTINPUT:
		contenedorRaiz->grabarCaracter(*event.text.text);
		break;

	}

}


Controlador::~Controlador() {
}
