#ifndef CONTENEDORLAYOUT_H_
#define CONTENEDORLAYOUT_H_

#include "Vista/Contenedor.h"
#include "Vista/FuentesPosicion/FuenteLayout.h"
#include <utility>

class ContenedorLayout : public Contenedor
{
public:
	ContenedorLayout (FuentePosicion* fuente, DestinoDibujo* destino, bool horizontal);
	virtual ~ContenedorLayout ();

	virtual LayoutInfo getLayoutInfo();

	void setSeparacion (float fraccion);

private:
	bool horizontal;
	float separacion;

	virtual void regenerar();
	void recalcularDimensiones();
	std::pair<float, std::vector<Rect>> realizarLayout(float separacion, float extension);
	void commitLayout(std::vector<Rect>&& tamanios);
};

#endif /* CONTENEDORLAYOUT_H_ */
