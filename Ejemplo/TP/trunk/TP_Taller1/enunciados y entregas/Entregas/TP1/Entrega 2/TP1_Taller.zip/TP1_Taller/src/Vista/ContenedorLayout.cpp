#include "ContenedorLayout.h"

#include "LayoutInfo.h"
#include "Utils/iteracion.h"
#include <algorithm>
#include <vector>

ContenedorLayout::ContenedorLayout (FuentePosicion* fuente, DestinoDibujo* destino, bool horizontal)
	: Contenedor(fuente, destino)
	, horizontal(horizontal)
	, separacion(0.0)
{
}

ContenedorLayout::~ContenedorLayout ()
{
}

LayoutInfo ContenedorLayout::getLayoutInfo()
{
	LayoutInfo retval;

	typedef std::list<interfases::Elemento*>::reverse_iterator iterator_t;
	for (iterator_t it = listaElementos.rbegin(); it != listaElementos.rend(); ++it) {
		retval = retval.combinar((*it)->getLayoutInfo(), horizontal);
	}

	int cantidadSeparaciones = listaElementos.size() - 1;
	float multiplicadorSeparacion = 1.0 + std::max(0.0f, separacion * cantidadSeparaciones);
	if (horizontal) {
		retval.tamPreferido.x *= multiplicadorSeparacion;
	} else {
		retval.tamPreferido.y *= multiplicadorSeparacion;
	}

	return retval;
}

void ContenedorLayout::setSeparacion(float fraccion)
{
	separacion = fraccion;
}

void ContenedorLayout::regenerar()
{
	recalcularDimensiones();
	Contenedor::regenerar();
}

void ContenedorLayout::recalcularDimensiones()
{
	Vec2 tamContenedor(getSuperficie().tam());

	float tamParalelo = horizontal ? tamContenedor.x : tamContenedor.y;
	auto layout = realizarLayout(0, 0);
	float espacioUsado = tamParalelo - layout.first;

	int cantidadSeparaciones = listaElementos.size() - 1;
	float multiplicadorSeparacion = std::max(0.0f, separacion * cantidadSeparaciones);
	float espacioSeparadores = espacioUsado * multiplicadorSeparacion;
	if (espacioSeparadores > layout.first) {
		espacioSeparadores = layout.first;
	}
	float espacioInfinitos = tamParalelo - espacioUsado - espacioSeparadores;

	int infinitos = 0;
	for (auto& emt : invertir_iteracion(listaElementos)) {
		if (emt->getLayoutInfo().infinitoParalelo(horizontal)) {
			infinitos++;
		}
	}
	float separacion = (cantidadSeparaciones == 0) ? 0.0 : (espacioSeparadores / cantidadSeparaciones);
	float extension = (infinitos == 0) ? 0.0 : (espacioInfinitos / infinitos);
	layout = realizarLayout(separacion, extension);
	commitLayout(move(layout.second));
}

/* Devuelve espacio no ocupado. Argumentos son el espacio a usar entre pares
 * de objetos, y espacio a usar para cada objeto extensible.
 */
std::pair<float, std::vector<Rect>> ContenedorLayout::realizarLayout (float separacion, float extension)
{
	std::pair<float, std::vector<Rect>> retval;

	Vec2 tamContenedor(getSuperficie().tam());

	Vec2 media;
	if (horizontal) {
		media.y = tamContenedor.y / 2;
	} else {
		media.x = tamContenedor.x / 2;
	}

	LayoutInfo miInfo(this->getLayoutInfo());
	Vec2 ratios = (tamContenedor - miInfo.tamMinimo)/ (miInfo.tamPreferido - miInfo.tamMinimo);
	float ratio = horizontal ? ratios.x : ratios.y;

	for (auto& emt : invertir_iteracion(listaElementos)) {
		LayoutInfo currentInfo(emt->getLayoutInfo());
		Vec2 nTam;
		if (ratio < 1) {
			nTam = currentInfo.interpoladoCompatible(tamContenedor, horizontal, ratio);
		} else {
			nTam = currentInfo.maximoCompatible(tamContenedor, horizontal, extension);
		}

		Vec2 avance;
		Vec2 separador;
		if (horizontal) {
			avance.x = nTam.x / 2;
			separador.x = separacion;
		} else {
			avance.y = nTam.y / 2;
			separador.y = separacion;
		}
		Vec2 nCentro = media + avance;

		retval.second.push_back(Rect::deCentro(nCentro, nTam));

		media = nCentro + avance + separador;
	}

	if (horizontal) {
		retval.first = tamContenedor.x - media.x;
	} else {
		retval.first = tamContenedor.y - media.y;
	}
	return retval;
}

void ContenedorLayout::commitLayout(std::vector<Rect>&& posiciones)
{
	Vec2 tamContenedor = this->getFuente()->getSuperficie().tam();
	for (auto& emt : listaElementos) {
		FuenteLayout* fuente = dynamic_cast<FuenteLayout*>(emt->getFuente());
		if (fuente != NULL) {
			fuente->setTamPadre(tamContenedor);
			fuente->setSuperficie(posiciones.back());
		}
		posiciones.pop_back();
	}
}
