/*
 * Controlador.h
 *
 *  Created on: Sep 12, 2013
 *      Author: lucia
 */

#ifndef CONTROLADOR_H_
#define CONTROLADOR_H_

#include "Mouse.h"
#include "Teclado.h"

class Ventana;
class Contenedor;

class Controlador {
public:
	Controlador(Ventana*, Contenedor*);
	void handle(SDL_Event event);
	virtual ~Controlador();
	Contenedor* getContenedorClickeado();
private:
	controlador::Mouse mouse;
	controlador::Teclado teclado;
	Ventana* window;
	Contenedor* contenedorRaiz;
};

#endif /* CONTROLADOR_H_ */
