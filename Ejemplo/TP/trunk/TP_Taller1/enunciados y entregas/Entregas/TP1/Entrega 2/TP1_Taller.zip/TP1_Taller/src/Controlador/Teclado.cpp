/*
 * Teclado.cpp
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#include "Teclado.h"

#include <cstddef>

namespace controlador {


Teclado::Teclado() : presionadas() {
}


Teclado::~Teclado() {
}


void Teclado::presionar(SDL_Keycode tecla) {
	presionadas.insert(tecla);
}


void Teclado::soltar(SDL_Keycode tecla) {
	presionadas.erase(tecla);
}


bool Teclado::presionada(SDL_Keycode tecla) {
	return presionadas.count(tecla) != 0;
}

} /* namespace controlador */
