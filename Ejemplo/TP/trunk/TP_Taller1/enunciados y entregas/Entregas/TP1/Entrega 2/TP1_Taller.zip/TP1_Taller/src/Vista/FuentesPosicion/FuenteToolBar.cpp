/*
 * FuenteToolBar.cpp
 *
 *  Created on: 21/09/2013
 *      Author: stephanie
 */

#include "FuenteToolBar.h"

FuenteToolBar::FuenteToolBar(ToolBar* toolbar)
	: toolbar(toolbar)
	, superficie()
{
}

FuenteToolBar::FuenteToolBar(const FuenteToolBar& rhs)
{	// TODO Auto-generated constructor stub
	this->toolbar = rhs.toolbar;

}

FuenteToolBar::~FuenteToolBar() {
}

Rect FuenteToolBar::getSuperficie ()
{
	return superficie;
}

void FuenteToolBar::setSuperficie (const Rect& sup)
{
	superficie = sup;
}

float FuenteToolBar::getAngulo ()
{
	return 0.0f;
}

void FuenteToolBar::setAngulo (float)
{
}

Vec2 FuenteToolBar::getTamPadre ()
{
	return toolbar->getSuperficie().tam();
}

FuentePosicion *FuenteToolBar::clonar() const{
	return new FuenteToolBar(*this);
}
