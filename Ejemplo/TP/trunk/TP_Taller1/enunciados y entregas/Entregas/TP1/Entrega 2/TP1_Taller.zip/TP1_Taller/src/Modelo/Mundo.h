#ifndef MUNDO_H_
#define MUNDO_H_

#include <yaml-cpp/yaml.h>
#include <list>
#include "Utils/ConvertStr.h"

namespace Modelo
{
class Entidad;

class Mundo
{
public:
	Mundo ();
	virtual ~Mundo ();

	Entidad* agregarEntidad (const Entidad &fig);
	void quitarEntidad (Entidad* fig);

	typedef std::list<Entidad*>::iterator iterator;
	iterator begin();
	iterator end();

	typedef std::list<Entidad*>::const_iterator const_iterator;
	const_iterator begin() const;
	const_iterator end() const;
private:
	std::list<Entidad*> contenido;
};

} /* namespace Modelo */

namespace YAML {

template<>
struct convert<Modelo::Mundo> {
	static Node encode(const Modelo::Mundo& rhs);

	// EL NODO ENTREGADO DEBE SER DISTINTO DE NULL Y DEFINIDO.
	static bool decode(const Node& node, Modelo::Mundo& rhs);
};

} /* namespace YAML */

#endif /* MUNDO_H_ */
