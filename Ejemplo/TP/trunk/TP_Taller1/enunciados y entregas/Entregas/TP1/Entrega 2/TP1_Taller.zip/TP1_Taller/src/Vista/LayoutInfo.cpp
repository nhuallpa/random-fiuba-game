#include "LayoutInfo.h"

#include <algorithm>

LayoutInfo::LayoutInfo (const Vec2& tamPreferido, const Vec2& tamMinimo, bool infinitoHorizontal, bool infintoVertical)
	: tamMinimo(tamMinimo)
	, tamPreferido(tamPreferido)
	, infinitoHorizontal(infinitoHorizontal)
	, infinitoVertical(infintoVertical)
{
}

LayoutInfo::~LayoutInfo ()
{
}

Vec2 combinarHorizontal (const Vec2& lhs, const Vec2& rhs)
{
	return Vec2(lhs.x + rhs.x, std::max(lhs.y, rhs.y));
}

Vec2 combinarVertical (const Vec2& lhs, const Vec2& rhs)
{
	return Vec2(std::max(lhs.x, rhs.x), lhs.y + rhs.y);
}

LayoutInfo LayoutInfo::combinar (const LayoutInfo& rhs, bool horizontal)
{
	LayoutInfo retval;

	if (horizontal) {
		retval.tamMinimo = combinarHorizontal(this->tamMinimo, rhs.tamMinimo);
		retval.tamPreferido = combinarHorizontal(this->tamPreferido, rhs.tamPreferido);
	} else {
		retval.tamMinimo = combinarVertical(this->tamMinimo, rhs.tamMinimo);
		retval.tamPreferido = combinarVertical(this->tamPreferido, rhs.tamPreferido);
	}
	retval.infinitoHorizontal = this->infinitoHorizontal || rhs.infinitoHorizontal;
	retval.infinitoVertical = this->infinitoVertical || rhs.infinitoVertical;

	return retval;
}

bool LayoutInfo::infinitoParalelo (bool horizontal)
{
	return horizontal ? infinitoHorizontal : infinitoVertical;
}

bool LayoutInfo::infinitoPerpendicular (bool horizontal)
{
	return horizontal ? infinitoVertical : infinitoHorizontal;
}

Vec2 LayoutInfo::interpoladoCompatible (Vec2 tamContenedor, bool horizontal, float u)
{
	Vec2 retval = tamMinimo + (tamPreferido - tamMinimo) * u;

	if (infinitoPerpendicular(horizontal)) {
		if (horizontal) {
			retval.y = tamContenedor.y;
		} else {
			retval.x = tamContenedor.x;
		}
	}

	return retval;
}

Vec2 LayoutInfo::maximoCompatible (Vec2 tamContenedor, bool horizontal, float espacioExtra)
{
	Vec2 retval(tamPreferido);
	if (tamPreferido != tamMinimo) {
		Vec2 u = (tamContenedor - tamMinimo) / (tamPreferido - tamMinimo);
		float ratio = std::min(u.x, u.y);
		if (ratio < 1.0) {
			retval = tamMinimo + (tamPreferido - tamMinimo) * ratio;
		}
	}
	if (horizontal) {
		if (infinitoHorizontal) {
			retval.x += espacioExtra;
		}
		if (infinitoVertical) {
			retval.y = tamContenedor.y;
		}
	} else {
		if (infinitoHorizontal) {
			retval.x = tamContenedor.x;
		}
		if (infinitoVertical) {
			retval.y += espacioExtra;
		}
	}
	return retval;
}
