/*
 * Textbox.cpp
 *
 *  Created on: 24/09/2013
 *      Author: rick
 */

#include "Textbox.h"

#include "Vista/FuentesPosicion/FuenteLayout.h"

Textbox::Textbox(FuentePosicion* fuente, DestinoDibujo* destino)
     : interfases::Elemento(fuente)
{
	this->apariencia = new Textura(*destino,fuente->getSuperficie().tam());
	this->preparadoParaEscritura = false;
	FuentePosicion *fuenteTex = new FuenteLayout(fuente->getSuperficie().tam());
	this->texto = new Texto(fuenteTex, destino);
	this->fondo = new Imagen("imagenes/fondos/fondoBlanco.png", destino);
}

Textbox::~Textbox() {
	if (apariencia != NULL) {
		delete apariencia;
	}
	if (fondo != NULL){
		delete fondo;
	}
	delete texto;
}

LayoutInfo Textbox::getLayoutInfo() {
	return LayoutInfo(Vec2(300, 25), Vec2(150, 25), true, false);
}

void Textbox::regenerar() {
	if (apariencia->tamDestino() != fuente->getSuperficie().tam()) {
		Textura *nApariencia = new Textura(*apariencia, fuente->getSuperficie().tam());
		if (nApariencia != NULL) {
			delete apariencia;
			apariencia = nApariencia;
		}
	}

	Vec2 tamanio = fuente->getSuperficie().tam();
	Vec2 tamanioTexto = texto->tamanio() / texto->tamanio().y * tamanio.y;
	float delta = std::min(0.0f, tamanio.x - tamanioTexto.x);

	FuenteLayout* fuenteTexto = dynamic_cast<FuenteLayout*>(texto->getFuente());
	fuenteTexto->setTamPadre(tamanio);
	fuenteTexto->setSuperficie(Rect(Vec2(delta, 0), tamanioTexto));

	apariencia->limpiar();
	fondo->dibujar(*apariencia);
	texto->dibujarse(apariencia);
}

void Textbox::dibujarse(DestinoDibujo* destino) {
	regenerar();
	apariencia->dibujar(*destino, *fuente);
}

void Textbox::grabarCaracter(char caracter) {
	if (preparadoParaTexto()) {
		std::string textoActual = this->texto->getTexto();
		if (caracter == '\b') {
			this->texto->setTexto(textoActual.substr(0, textoActual.size() - 1));
		}
		else {
			textoActual.push_back(caracter);
			this->texto->setTexto(textoActual);
		}
		regenerar();
	}
}

bool Textbox::preparadoParaTexto() {
	return preparadoParaEscritura;
}

void Textbox::prepararParaEscritura() {
	preparadoParaEscritura = true;
}

void Textbox::reaccionar() {
	this->prepararParaEscritura();
}

void Textbox::limpiarTexto() {
	this->preparadoParaEscritura = false;
	this->texto->limpiarTexto();
	apariencia->limpiar();
}

std::string Textbox::getTexto() {
	return this->texto->getTexto();
}
