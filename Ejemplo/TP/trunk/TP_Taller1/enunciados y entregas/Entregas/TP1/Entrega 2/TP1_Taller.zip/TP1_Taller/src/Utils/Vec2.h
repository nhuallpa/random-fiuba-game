#ifndef VEC2_H_
#define VEC2_H_

#include <yaml-cpp/yaml.h>

class Rect;

struct Vec2
{
	float x;
	float y;

	Vec2 ();
	Vec2 (float x, float y);

	Vec2 (const Vec2&) = default;
	Vec2 (Vec2&&) = default;
	Vec2& operator= (const Vec2&) = default;
	Vec2& operator= (Vec2&&) = default;
	virtual ~Vec2 ();

	bool operator== (const Vec2& rhs) const;
	bool operator!= (const Vec2& rhs) const;

	Vec2 operator+ (const Vec2& rhs) const;
	Vec2 operator* (float rhs) const;
	Vec2 operator* (const Vec2& rhs) const;

	Vec2 operator- () const;
	Vec2 operator- (const Vec2& rhs) const;
	Vec2 operator/ (float rhs) const;
	Vec2 operator/ (const Vec2& rhs) const;

	Vec2& operator+= (const Vec2& rhs);
	Vec2& operator-= (const Vec2& rhs);
	Vec2& operator*= (float rhs);
	Vec2& operator/= (float rhs);
	Vec2& operator*= (const Vec2& rhs);
	Vec2& operator/= (const Vec2& rhs);

	Vec2 cambioCoordenadas (const Rect& sistOrigen, const Rect& sistDestino) const;
	Vec2 rotar (float anguloGrados) const;
};

namespace YAML {
template<>
struct convert<Vec2> {
	static Node encode(const Vec2& rhs);

	/* EL NODO ENTREGADO DEBE SER DISTINTO DE NULL Y DEFINIDO.
	 * En caso de que ambos valores esten vacios, se rellenan por defecto en (0,0).
	 * Idem si no es una secuencia o no tiene tamaño 2.
	 * En caso de que uno de los valores este vacio o no sea escalar, se rellena por 0.
	 * Idem si no puede leerse como float.
	 */
	static bool decode(const Node& node, Vec2& rhs);
};
}

#endif /* VEC2_H_ */
