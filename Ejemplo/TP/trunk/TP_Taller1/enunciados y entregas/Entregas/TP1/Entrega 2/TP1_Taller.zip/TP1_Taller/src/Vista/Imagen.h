#ifndef IMAGEN_H_
#define IMAGEN_H_

#include "Interfases/OrigenDibujo.h"
#include <string>
#include <map>
#include <memory>

class DestinoDibujo;
class Vec2;
struct SDL_Texture;
struct SDL_Renderer;
struct ImagenReal;

class Imagen : public OrigenDibujo
{
public:
	Imagen (const std::string &path, DestinoDibujo *rend);

	Imagen (const Imagen&) = default;
	Imagen (Imagen&&) = default;
	Imagen& operator= (const Imagen&) = default;
	Imagen& operator= (Imagen&&) = default;
	virtual ~Imagen ();

	Vec2 tam ();
	bool esTransparente(Vec2 pos);

	virtual SDL_Texture *getTextureR ();

private:
	std::shared_ptr<ImagenReal> impl;
};

#endif /* IMAGEN_H_ */
