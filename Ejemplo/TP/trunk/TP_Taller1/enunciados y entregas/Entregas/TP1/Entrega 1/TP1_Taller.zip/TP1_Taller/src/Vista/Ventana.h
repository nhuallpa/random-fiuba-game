/*
 * Ventana.h
 *
 *  Created on: Sep 5, 2013
 *      Author: lucia
 */

#ifndef VENTANA_H_
#define VENTANA_H_

#include "Interfases/DestinoDibujo.h"

#include <string>

class SDL_Renderer;
class SDL_Texture;
class Vec2;
class SDL_Window;

class Ventana : public DestinoDibujo
{
public:
	Ventana(int width, int height, std::string title);
	virtual ~Ventana();

	virtual SDL_Renderer* getRenderer();
	virtual SDL_Texture* getTextureW();
	virtual Vec2 tamDestino() const;

	void setTamanio(int nWidth, int nHeight);

	void limpiarRenderer();
	void update ();

private:
	int width;
	int height;
	SDL_Window *window;
	SDL_Renderer *ren;
};

#endif /* VENTANA_H_ */
