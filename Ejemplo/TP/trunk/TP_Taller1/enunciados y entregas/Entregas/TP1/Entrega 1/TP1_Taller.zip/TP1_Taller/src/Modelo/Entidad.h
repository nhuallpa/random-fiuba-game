#ifndef ENTIDAD_H_
#define ENTIDAD_H_

#include "Utils/Vec2.h"
#include "Utils/ConvertStr.h"
#include <string>

namespace Modelo
{

class Entidad
{
public:
	Entidad ();
	explicit Entidad (std::string clase, Vec2 centro = Vec2(0, 0),
	                  Vec2 tamanio = Vec2(0, 0), float angulo = 0.0f);
	virtual ~Entidad ();

	bool valida();

	std::string clase;
	Vec2 centro;
	Vec2 tamanio;
	float angulo; //en grados
};

} /* namespace Modelo */

namespace YAML
{

template<>
struct convert<Modelo::Entidad> {
	static Node encode(const Modelo::Entidad& rhs);

	/* EL NODO ENTREGADO DEBE SER DISTINTO DE NULL Y ESTAR DEFINIDO.
	 * En caso de que los valores de posicion o tamanio esten vacios, se rellenan por defecto en (0,0).
	 * En caso de que angulo este vacio o no sea escalar, se rellena por 0.
	 * Idem si no puede leerse como float.
	 * Si no es un mapa o no tiene tamaño 3, sus atributos se rellenan con valores por defecto.
	 */
	static bool decode(const Node& node, Modelo::Entidad& rhs);
};

} /* namespace YAML */

#endif /* ENTIDAD_H_ */
