#include "Elemento.h"

using namespace interfases;

#include "Vista/FuentesPosicion/FuentePosicion.h"
#include "Utils/Rect.h"

Elemento::Elemento(FuentePosicion *nFuente)
	: visible(true)
	, fuente(nFuente)
	, clonable(false)
{
}

Elemento::~Elemento()
{
	//delete fuente;
}

void Elemento::ocultar()
{
	visible = false;
}

void Elemento::mostrar()
{
	visible = true;
}

bool Elemento::visibilidad()
{
	return visible;
}

bool Elemento::contiene(Vec2 punto)
{
	return this->getSuperficie().contiene(punto);
}

interfases::Elemento* Elemento::buscarElemento(Vec2)
{
	return this;
}

bool Elemento::aEliminar (Vec2)
{
	return false;
}

Rect Elemento::getSuperficie() const
{
	return fuente->getSuperficie();
}

FuentePosicion* Elemento::getFuente ()
{
	return fuente;
}

void Elemento::setFuente(FuentePosicion* nFuente)
{
	fuente = nFuente;
}

void Elemento::setClonable(bool clonable){
	this->clonable = clonable;
}

void Elemento::recibirFigura (const FiguraVista *elemento)
{
}

interfases::Elemento* Elemento::clonar() const
{
	return NULL;
}

interfases::Elemento* Elemento::clonar(Vec2 posicionMouse) const
{
	return NULL;
}

bool Elemento::getClonable(){
	return clonable;
}

bool Elemento::preparadoParaTexto(){
	return false;
}
