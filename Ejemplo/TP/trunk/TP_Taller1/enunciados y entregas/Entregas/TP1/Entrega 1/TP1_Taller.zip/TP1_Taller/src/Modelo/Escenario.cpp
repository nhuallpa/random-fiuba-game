/*
 * Escenario.cpp
 *
 *  Created on: 25/09/2013
 *  Last Amended: 25/09/2013
 *      Author: natuchis
 */

#include "Escenario.h"

#include "Log/Suceso.h"
#include "Log/Logger.h"
#include "Utils/YAMLHelper.h"
#include <string>

Escenario::Escenario()
	: pathFondo("imagenes/fondoNegro.png")
	, mundo()
{
}

Escenario::Escenario(std::string path, Modelo::Mundo mundo)
	: pathFondo(path)
	, mundo(mundo)
{
}

Escenario::~Escenario() {
}

namespace YAML {
	Node convert<Escenario>::encode(const Escenario& rhs) {
		Node node;
		node["pathFondo"] = rhs.pathFondo;
		node["mundo"] = rhs.mundo;
		return node;
	}

	bool convert<Escenario>::decode(const Node& node, Escenario& rhs) {
		YAML::Mark marca = node.mark();

		if (!node.IsMap() || node.size() != 2) {
			ConvertStr output(marca, "No se puede leer Escenario, no es mapa o no tiene 2 atributos. Creado vacio y con imagen por defecto.");
			Log::Suceso (Log::ERROR, output.getString());
		}
		else {
			rhs.pathFondo = YAML_leer<std::string>(node["pathFondo"], "pathFondo");
			rhs.mundo = YAML_leer<Modelo::Mundo>(node["mundo"], "mundo");
		}
		return true;
	}
}
