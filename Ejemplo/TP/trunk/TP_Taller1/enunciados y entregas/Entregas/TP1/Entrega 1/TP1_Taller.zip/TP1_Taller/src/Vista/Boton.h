/*
 * Boton.h
 *
 *  Created on: 14/09/2013
 *  Last Amended: 14/09/2013
 *      Author: natuchis
 */

#ifndef BOTON_H_
#define BOTON_H_

#include "Interfases/Elemento.h"

class Vec2;
class Rect;
class FuentePosicion;
class Imagen;

class Boton: public interfases::Elemento {
public:
	Boton(FuentePosicion *fuente, std::string pathImagen, DestinoDibujo *destino);
	virtual ~Boton();

	virtual void dibujarse(DestinoDibujo* window);

	void setImagen(Imagen* imagen);
	Imagen* getImagen();
	LayoutInfo getLayoutInfo();

	//Esto es para definir un método puramente virtual.
	virtual std::string getPathImagen() = 0;

private:
	Imagen *imagen;
};

#endif /* BOTON_H_ */
