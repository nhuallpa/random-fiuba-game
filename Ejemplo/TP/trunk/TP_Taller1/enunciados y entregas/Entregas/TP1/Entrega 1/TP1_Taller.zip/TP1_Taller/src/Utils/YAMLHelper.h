#ifndef YAMLHELPER_H_
#define YAMLHELPER_H_

#include "Log/Suceso.h"

template <class RETORNO>
RETORNO YAML_leerBase (const YAML::Node &nodo, const std::string nombreAtributo,
                       bool fatal, const RETORNO& retornoDefault)
{
	RETORNO retval(retornoDefault);

	if (nodo.IsNull() || !nodo.IsDefined()) {
		std::string mensaje = std::string()
		                    + "No existe el atributo '"
		                    + nombreAtributo
		                    + "'. ";
		ConvertStr output(nodo.mark(), mensaje);
		if (fatal) {
			throw Log::Suceso (Log::ERROR, output.getString());
		} else {
			mensaje += "Usando valor por defecto";
			Log::Suceso (Log::ERROR, output.getString());
		}
	} else {
		try {
			retval = nodo.as<RETORNO>();
		} catch (YAML::TypedBadConversion<RETORNO>& e) {
			std::string mensaje = std::string()
		                            + "El atributo '"
		                            + nombreAtributo
		                            + "' no se puede convertir. ";
			ConvertStr output(nodo.mark(), mensaje);
			if (fatal) {
				throw Log::Suceso (Log::ERROR, output.getString());
			} else {
				mensaje += "Usando valor por defecto";
				Log::Suceso (Log::ERROR, output.getString());
			}
		}
	}

	return retval;
}

template <class RETORNO>
RETORNO YAML_leerFatal (const YAML::Node &nodo, const std::string nombreAtributo,
                        const RETORNO& retornoDefault)
{
	return YAML_leerBase<RETORNO>(nodo, nombreAtributo, true, retornoDefault);
}

template <class RETORNO>
RETORNO YAML_leerFatal (const YAML::Node &nodo, const std::string nombreAtributo)
{
	return YAML_leerBase<RETORNO>(nodo, nombreAtributo, true, RETORNO());
}

template <class RETORNO>
RETORNO YAML_leer (const YAML::Node &nodo, const std::string nombreAtributo,
                        const RETORNO& retornoDefault)
{
	return YAML_leerBase<RETORNO>(nodo, nombreAtributo, false, retornoDefault);
}

template <class RETORNO>
RETORNO YAML_leer (const YAML::Node &nodo, const std::string nombreAtributo)
{
	return YAML_leerBase<RETORNO>(nodo, nombreAtributo, false, RETORNO());
}

#endif /* YAMLHELPER_H_ */
