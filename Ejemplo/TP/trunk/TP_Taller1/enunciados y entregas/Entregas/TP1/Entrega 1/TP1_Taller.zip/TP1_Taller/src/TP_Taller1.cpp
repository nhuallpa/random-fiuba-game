#include "Vista/Ventana.h"
#include "Vista/Canvas.h"
#include "Vista/FuentesPosicion/FuenteVentana.h"
#include "Vista/ContenedorLayout.h"
#include "Vista/FuentesPosicion/FuenteLayout.h"
#include "Vista/FiguraVista.h"
#include "Vista/FuentesPosicion/FuenteModelo.h"
#include "Vista/FuentesPosicion/FuenteToolBar.h"
#include "Vista/Boton.h"
#include "Vista/Botones/Guardar.h"
#include "Vista/Botones/Cargar.h"
#include "Vista/Botones/Salir.h"
#include "Vista/Botones/FlechaUp.h"
#include "Vista/Botones/FlechaDown.h"
#include "Vista/Imagen.h"
#include "Modelo/Mundo.h"
#include "Modelo/Entidad.h"
#include "Modelo/Escenario.h"
#include "Utils/Vec2.h"
#include "Utils/Rect.h"
#include "Utils/ConvertStr.h"
#include "Controlador/Controlador.h"
#include "Log/Logger.h"
#include "Log/Suceso.h"
#include "Vista/ToolBar.h"
#include "Global/terminarPrograma.h"
#include <unistd.h>
#include <yaml-cpp/yaml.h>
#include <SDL2/SDL_image.h>
#include <iostream>
#include <fstream>
#include <SDL2/SDL.h>

using namespace std;

void cargarEscenario (std::string path, Escenario& escenario) {
	try {
		YAML::Node nodo = YAML::LoadFile (path);
		YAML::Mark marca = nodo.mark();

		if (nodo["escenario"].IsNull() || !nodo["escenario"].IsDefined()) {
			ConvertStr output(marca, "No existe el Escenario.");
			Log::Suceso (Log::ERROR, output.getString());
		}
		else {
			escenario = nodo["escenario"].as<Escenario>();

			Modelo::Mundo re_mundo = escenario.mundo;
			string path = escenario.pathFondo;
			for (Modelo::Mundo::iterator iter = re_mundo.begin(); iter != re_mundo.end(); ++iter) {
				cout << (*iter)->centro.x << " "
						<< (*iter)->centro.y << " "
						<< (*iter)->tamanio.x << " "
						<< (*iter)->tamanio.y << " "
						<< (*iter)->angulo << endl;
			}
			cout << "Path: " << path << endl;
		}

	} catch(YAML::ParserException& e) {
		cout << e.what() << "\n";
	}
	catch (YAML::BadFile& e) {
		string output("No se puede cargar el archivo especificado. Se crea Escenario vacio con imagen por defecto.");
		Log::Suceso (Log::ERROR, output);
	}
	catch (YAML::TypedBadConversion<Escenario>& e) {
		ConvertStr output(e.mark, "No se puede convertir a Escenario.");
		Log::Suceso (Log::ERROR, output.getString());
	}
}

void cargarToolBar (ToolBar* toolbar, Ventana* window) {
	typedef std::map<std::string, FiguraVista> dato_t;
	dato_t listaFiguras = FiguraVista::getPrototipos();
	for (dato_t::iterator it = listaFiguras.begin(); it != listaFiguras.end(); it++) {
		FuentePosicion *fuente = new FuenteToolBar(toolbar);
		FiguraVista *vista = new FiguraVista(it->first, fuente, window);
		vista->setClonable(true);
		toolbar->addElemento(vista);
	}
}

int main (int argc, char *argv[]) {

	//Creo los logger
	Log::Logger cout_logger(Log::FATAL | Log::ERROR);
	Log::Logger file_logger("Log.txt", Log::ALL);

	if (argc != 2) {
		Log::Suceso(Log::FATAL, "Cantidad de argumentos invalido. \n Ingreso correcto: TP_Taller1 <path de archivo YAML>");
		return -1;
	}

	Escenario escenario;
	cargarEscenario(argv[1], escenario);

	if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
		std::string mensaje("Fallo al iniciar SDL: ");
		mensaje += SDL_GetError();
		throw Log::Suceso(Log::FATAL, mensaje);
	}

	//Se crea una ventana.
	Ventana window(500,500,"The Incredible Machine");
	Log::Suceso(Log::INFO, "Creada ventana!");

	// Creo el canvas con enlace al modelo
	FuenteLayout fuenteIzquierda;
	Canvas izquierda(&fuenteIzquierda, &window, &escenario.mundo, Rect(0, 0, 100, 100));
	izquierda.setBackground(escenario.pathFondo, &window);
	izquierda.setPermitirEliminaciones(true);

	// Creo y agrego vistas al toolbar
	FuenteLayout fuenteDerecha;
	ContenedorLayout derecha(&fuenteDerecha, &window, false);
	derecha.setBackground("imagenes/fondoGris.png", &window);

	FuenteLayout fuenteToolbar;
	ToolBar toolbar(&fuenteToolbar, &window, &izquierda);
	toolbar.setBackground("imagenes/fondoBlanco.png", &window);

	FuenteLayout fuenteBotonUp;
	Boton *botonUp = new FlechaUp(&fuenteBotonUp, &window, &toolbar);
	derecha.addElemento(botonUp, &fuenteBotonUp);

	cargarToolBar(&toolbar, &window);

	derecha.addElemento(&toolbar, &fuenteToolbar);

	FuenteLayout fuenteBotonDown;
	Boton *botonDown = new FlechaDown(&fuenteBotonDown, &window, &toolbar);
	derecha.addElemento(botonDown, &fuenteBotonDown);

	FuenteLayout fuenteArriba;
	ContenedorLayout contenedorArriba(&fuenteArriba, &window, true);
	contenedorArriba.setSeparacion(0.05);
	contenedorArriba.setBackground("imagenes/fondoGris.png", &window);
	contenedorArriba.addElemento(&izquierda, &fuenteIzquierda);
	contenedorArriba.addElemento(&derecha, &fuenteDerecha);

	// Creo y agrego botones al contenedor
	FuenteLayout fuenteTextbox;
	Textbox vistaTextbox(&fuenteTextbox, &window);

	FuenteLayout fuenteCargar;
	Cargar *vistaCargar = new Cargar(&fuenteCargar, &window, &izquierda, &vistaTextbox);

	FuenteLayout fuenteGuardar;
	Guardar *vistaGuardar = new Guardar(&fuenteGuardar, &window, &escenario, argv[1]);

	FuenteLayout fuenteSalir;
	Salir *vistaSalir = new Salir(&fuenteSalir, &window);

	FuenteLayout fuenteAbajo;
	ContenedorLayout contenedorAbajo(&fuenteAbajo, &window, true);
	contenedorAbajo.setSeparacion(0.02);
	contenedorAbajo.setBackground("imagenes/fondoGris.png", &window);
	contenedorAbajo.addElemento(&vistaTextbox, &fuenteTextbox);
	contenedorAbajo.addElemento(vistaCargar, &fuenteCargar);
	contenedorAbajo.addElemento(vistaGuardar, &fuenteGuardar);
	contenedorAbajo.addElemento(vistaSalir, &fuenteSalir);

	FuenteVentana fuenteVentana(&window);
	ContenedorLayout contenedorVentana(&fuenteVentana, &window, false);
	contenedorVentana.setSeparacion(0.02);
	contenedorVentana.setBackground("imagenes/fondoGris.png", &window);
	contenedorVentana.addElemento(&contenedorArriba, &fuenteArriba);
	contenedorVentana.addElemento(&contenedorAbajo, &fuenteAbajo);


	Controlador controlador(&window, &contenedorVentana);

	//Ciclo infinito principal
	try {
		while (true) {
			SDL_Event event;
			while (SDL_PollEvent(&event) != 0) {
				if (event.type == SDL_QUIT){
					terminarPrograma();
				} else if (event.type == SDL_WINDOWEVENT && event.window.event == SDL_WINDOWEVENT_RESIZED) {
					window.setTamanio(event.window.data1, event.window.data2);
				} else {
					controlador.handle(event);
				}
			}

			window.limpiarRenderer();
			contenedorVentana.dibujarse(&window);
			window.update();

			// TODO: timing del modelo y vista
			SDL_Delay(1000/40);
		}
	} catch (int retorno) {
		return retorno;
	}
}
