/*
 * Cargar.cpp
 *
 *  Created on: 14/09/2013
 *  Last Amended: 24/09/2013
 *      Author: natuchis, rick
 */

#include "Cargar.h"


Cargar::Cargar(FuentePosicion* unaFuente, DestinoDibujo* unDestino, Contenedor* unCanvas, Textbox* unTextbox)
	: Boton(unaFuente, constantesVista::ConstantesVista::imagenCargar, unDestino)
{
	this->pathImagen = constantesVista::ConstantesVista::imagenCargar;
	this->canvas  = unCanvas;
	this->textbox = unTextbox;
	this->destino = unDestino;
}


Cargar::~Cargar() {
}


std::string Cargar::getPathImagen() {
	return this->pathImagen;
}


void Cargar::reaccionar() {

	std::string texto = this->textbox->getTexto();
	this->canvas->setBackground(texto, this->destino);
	Log::Suceso(Log::INFO, "Se ha cambiado de fondo.");
	this->textbox->limpiarTexto();

}

