/*
 * ConstantesVista.h
 *
 *  Created on: Sep 5, 2013
 *      Author: lucia
 */

#ifndef CONSTANTESVISTA_H_
#define CONSTANTESVISTA_H_

#include <string>

#ifndef PI
#define PI 3.14159265
#endif

/*
 * NombresArchivos.h
 *
 *  Created on: Jun 15, 2013
 *      Author: lucia
 */

namespace constantesVista {

class ConstantesVista {
public:
	ConstantesVista();
	static const std::string imagenFondo;
	static const std::string imagenRombo;
	static const std::string imagenCuadrado;
	static const std::string imagenCirculo;
	static const std::string imagenTriangulo;
	static const std::string imagenPentagono;
	static const std::string imagenHexagono;
	static const std::string imagenParalelogramo;
	static const std::string imagenTrapecio;
	static const std::string imagenTrianguloRect;
	static const std::string imagenEstrella;
	static const std::string imagenEstrella4Puntas;
	static const std::string imagenEstrella6Puntas;
	static const std::string imagenCargar;
	static const std::string imagenGuardar;
	static const std::string imagenSalir;
	static const std::string imagenFlechaUp;
	static const std::string imagenFlechaDown;
	virtual ~ConstantesVista();
};


}

#endif /* CONSTANTESVISTA_H_ */
