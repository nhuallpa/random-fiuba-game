#include "FuenteLayout.h"

FuenteLayout::FuenteLayout (const Vec2& tamPadre)
	: tamPadre(tamPadre)
	, superficie(Vec2(), tamPadre)
{
}

FuenteLayout::FuenteLayout (const FuenteLayout& rhs)
	: tamPadre(rhs.tamPadre)
	, superficie(Vec2(), rhs.tamPadre)
{
}

FuenteLayout::~FuenteLayout ()
{
}

Rect FuenteLayout::getSuperficie ()
{
	return superficie;
}

void FuenteLayout::setSuperficie (const Rect& nSuperficie)
{
	superficie = nSuperficie;
}

Vec2 FuenteLayout::getTamPadre ()
{
	return tamPadre;
}

void FuenteLayout::setTamPadre (const Vec2& nTam)
{
	tamPadre = nTam;
}

float FuenteLayout::getAngulo ()
{
	return 0;
}

void FuenteLayout::setAngulo (float)
{
}

FuentePosicion *FuenteLayout::clonar() {
	return new FuenteLayout(*this);
}
