#ifndef IMAGEN_H_
#define IMAGEN_H_

#include "Interfases/OrigenDibujo.h"
#include <string>
#include <map>

class DestinoDibujo;
class Vec2;
struct SDL_Texture;
struct SDL_Renderer;

class Imagen : public OrigenDibujo
{
public:
	Imagen (const Imagen& rhs);
	Imagen (const std::string &path, DestinoDibujo *rend);
	virtual ~Imagen ();

	Vec2 tam ();

	virtual SDL_Texture *getTextureR ();

private:
	struct ImagenReal;
	ImagenReal *impl;

	static std::map<SDL_Renderer*, std::map<std::string, ImagenReal*> > cache;
};

#endif /* IMAGEN_H_ */
