/*
 * FuenteToolBar.h
 *
 *  Created on: 21/09/2013
 *      Author: stephanie
 */

#ifndef FUENTETOOLBAR_H_
#define FUENTETOOLBAR_H_

#include "FuentePosicion.h"
#include "../ToolBar.h"
#include "Utils/Rect.h"

class FuenteToolBar: public FuentePosicion{
public:
	FuenteToolBar(ToolBar* toolbar);
	FuenteToolBar(const FuenteToolBar& rhs);
	virtual ~FuenteToolBar();
	virtual Rect getSuperficie ();
	virtual void setSuperficie (const Rect& val);
	virtual float getAngulo ();
	virtual void setAngulo (float val);
	virtual Vec2 getTamPadre ();
	virtual FuentePosicion* clonar();

private:
	ToolBar* toolbar;
	Rect superficie;
};

#endif /* FUENTETOOLBAR_H_ */
