#ifndef FUENTEMODELO_H_
#define FUENTEMODELO_H_

#include "FuentePosicion.h"

namespace Modelo {
	class Entidad;
}
class Rect;
class Contenedor;
class Vec2;

class FuenteModelo : public FuentePosicion
{
public:
	FuenteModelo (Modelo::Entidad *entidad
                     , const Rect *regionModelo
                     , Contenedor *contenedorDestino);
	FuenteModelo (const FuenteModelo& rhs);
	virtual ~FuenteModelo ();

	virtual Rect getSuperficie ();
	virtual void setSuperficie (const Rect& val);
	virtual Vec2 getTamPadre ();

	virtual float getAngulo ();
	virtual void setAngulo (float val);

	Modelo::Entidad *getEntidad();
	virtual FuentePosicion* clonar();

private:
	Modelo::Entidad *entidad;
	const Rect *regionModelo;
	Contenedor *contenedorDestino;
};

#endif /* FUENTEMODELO_H_ */
