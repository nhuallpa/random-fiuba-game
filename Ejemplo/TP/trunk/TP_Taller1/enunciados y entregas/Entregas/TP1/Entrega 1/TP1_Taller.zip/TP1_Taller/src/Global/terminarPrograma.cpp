#include "terminarPrograma.h"

#include "Vista/FiguraVista.h"
#include "Vista/Imagen.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <unistd.h>

void terminarPrograma (void)
{
	// TODO: agregar verificacion de salida
	FiguraVista::finalizar();
	TTF_Quit();
	SDL_Quit();
	throw 0;
}
