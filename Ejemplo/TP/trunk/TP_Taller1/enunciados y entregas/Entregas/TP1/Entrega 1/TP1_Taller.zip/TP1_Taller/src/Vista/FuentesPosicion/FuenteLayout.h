#ifndef FUENTELAYOUT_H_
#define FUENTELAYOUT_H_

#include "FuentePosicion.h"
#include "Utils/Rect.h"

class FuenteLayout : public FuentePosicion
{
public:
	FuenteLayout (const Vec2& tamPadre = Vec2(100, 100));
	FuenteLayout (const FuenteLayout& rhs);
	virtual ~FuenteLayout ();

	virtual Rect getSuperficie ();
	virtual void setSuperficie (const Rect& val);
	virtual Vec2 getTamPadre ();
	void setTamPadre (const Vec2& nTam);

	virtual float getAngulo ();
	virtual void setAngulo (float val);

	virtual FuentePosicion* clonar();

private:
	Rect superficie;
	Vec2 tamPadre;
};

#endif /* FUENTELAYOUT_H_ */
