/*
 * Ventana.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: lucia
 */

#include "Ventana.h"

#include "Utils/Rect.h"
#include "Log/Suceso.h"
#include <SDL2/SDL.h>

Ventana::Ventana(int width, int height, std::string title)
	: width(width)
	, height(height)
	, window(NULL)
	, ren(NULL)
{
	window = SDL_CreateWindow(title.c_str(), SDL_WINDOWPOS_CENTERED,
	                          SDL_WINDOWPOS_CENTERED, width, height,
	                          SDL_WINDOW_HIDDEN | SDL_WINDOW_RESIZABLE);
	if (window == NULL) {
		std::string mensaje("No se creo ventana: ");
		mensaje = mensaje + SDL_GetError();
		throw Log::Suceso(Log::FATAL, mensaje);
	}

	ren = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC | SDL_TEXTUREACCESS_TARGET);
	if (this->ren == NULL) {
		SDL_DestroyWindow(window);

		std::string mensaje("No se creo renderer: ");
		mensaje = mensaje + SDL_GetError();
		throw Log::Suceso(Log::FATAL, mensaje);
	}

	SDL_RenderClear(this->ren);
	SDL_ShowWindow(this->window);
}

Ventana::~Ventana() {
	SDL_DestroyRenderer(ren);
	SDL_DestroyWindow(window);
}

SDL_Renderer* Ventana::getRenderer(){
	return this->ren;
}

SDL_Texture* Ventana::getTextureW(){
	return NULL; //indica que quiero escribir a la ventana en si
}

Vec2 Ventana::tamDestino() const{
	return Vec2(width, height);
}

void Ventana::setTamanio(int nWidth, int nHeight)
{
	width = nWidth;
	height = nHeight;
}

void Ventana::limpiarRenderer(){
	SDL_RenderClear(this->ren);
}

void Ventana::update () {
	SDL_RenderPresent(this->ren);
}
