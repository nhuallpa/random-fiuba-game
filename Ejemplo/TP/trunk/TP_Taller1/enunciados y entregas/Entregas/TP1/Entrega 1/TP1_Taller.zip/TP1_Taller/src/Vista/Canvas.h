#ifndef CANVAS_H_
#define CANVAS_H_

#include "Contenedor.h"

#include "Utils/Rect.h"

class FuentePosicion;
class DestinoDibujo;
class FiguraVista;
namespace Modelo {
	class Mundo;
}

class Canvas : public Contenedor
{
public:
	Canvas (FuentePosicion* fuente, DestinoDibujo* destino,
	        Modelo::Mundo *mundo, const Rect& regionModeloAMostrar);
	virtual ~Canvas ();

	Vec2 tamUnidadLogica() const;
	bool aEliminar (Vec2 posicionRespectoPadre);
	virtual void recibirFigura (const FiguraVista *elemento);

	//PARCHE TODO
	void mandarAlFrente(interfases::Elemento* el);

private:
	Modelo::Mundo* mundo;
	Rect regionModelo;
};

#endif /* CANVAS_H_ */
