#include "ConstantesVista.h"

namespace constantesVista {
	const std::string ConstantesVista::imagenFondo = "imagenes/fondo.bmp";
	const std::string ConstantesVista::imagenCargar = "imagenes/Cargar.png";
	const std::string ConstantesVista::imagenGuardar = "imagenes/Guardar.png";
	const std::string ConstantesVista::imagenSalir = "imagenes/Salir.png";
	const std::string ConstantesVista::imagenFlechaUp = "imagenes/FlechaUp.png";
	const std::string ConstantesVista::imagenFlechaDown = "imagenes/FlechaDown.png";
}
