/*
 * Teclado.h
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#ifndef TECLADO_H_
#define TECLADO_H_

#include <SDL2/SDL_keycode.h>
#include <set>

#define BACKSPACE 8
#define SHIFT 15
#define MAYUS 16

namespace controlador {


class Teclado {

public:
	Teclado();
	virtual ~Teclado();

	void presionar(SDL_Keycode tecla);
	void soltar(SDL_Keycode tecla);

	bool presionada(SDL_Keycode tecla);
	
	char parsearTecla(char tecla);


private:
	std::set<SDL_Keycode> presionadas;
	
	bool shiftOn;
	bool blockMayusOn;
	
};


} /* namespace controlador */

#endif /* TECLADO_H_ */

