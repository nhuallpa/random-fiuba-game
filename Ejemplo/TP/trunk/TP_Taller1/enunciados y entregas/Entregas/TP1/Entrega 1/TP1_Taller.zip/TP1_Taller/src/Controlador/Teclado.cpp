/*
 * Teclado.cpp
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#include "Teclado.h"

#include <cstddef>

namespace controlador {


Teclado::Teclado() : presionadas() {
	this->shiftOn = false;
	this->blockMayusOn = false;
}


Teclado::~Teclado() {
}


void Teclado::presionar(SDL_Keycode tecla) {
	presionadas.insert(tecla);
}


void Teclado::soltar(SDL_Keycode tecla) {
	presionadas.erase(tecla);
}


bool Teclado::presionada(SDL_Keycode tecla) {
	return presionadas.count(tecla) != 0;
}


char Teclado::parsearTecla(char tecla) {
	char nTecla;
	
	if (true) {
	
	// parsear las teclas
/*	if ( (tecla >= 32 && tecla <=64) || (tecla >= 97 && tecla <= 125)
		|| (tecla == SHIFT) || (tecla == BACKSPACE) || tecla == MAYUS ) {
		
	//	return (nTecla = '/');
*/		
		if (tecla == ',') {
			return (nTecla = '/');
		}



/*
		if (tecla == BACKSPACE)
			// hacer logica de borrar
			return (nTecla = '\0');

		if (tecla == SHIFT)	{
			if (!this->shiftOn)	{
				this->shiftOn = true ;
			}
			else {
				this->shiftOn = false;
			}
			return (nTecla = '\0');
		}
		
		if (tecla == MAYUS)	{
			if (!this->blockMayusOn)	{
				this->blockMayusOn = true ;

			}
			else {
				this->blockMayusOn = false;
			}
			return (nTecla = '\0');
		}
*/		
		// caso 
		return (nTecla = tecla);

	} // end if grande ppal
	
	return (nTecla = '\0');
	
}





} /* namespace controlador */

