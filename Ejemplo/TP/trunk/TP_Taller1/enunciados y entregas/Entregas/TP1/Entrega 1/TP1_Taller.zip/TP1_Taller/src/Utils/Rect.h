#ifndef RECT_H_
#define RECT_H_

#include "Vec2.h"

struct SDL_Rect;

/* Clase para representar genericamente rectangulos */
class Rect
{
public:
	Rect ();
	Rect(const Rect &copia);
	Rect (float x, float y, float w, float h);
	Rect (const Vec2& up_left, const Vec2& tam);
	static Rect deCentro (const Vec2& centro, const Vec2& tam);
	virtual ~Rect ();

	Vec2 origen () const;
	void setOrigen (const Vec2& nOrigen);
	Vec2 centro () const;
	void setCentro (const Vec2& nCentro);
	Vec2 tam () const;
	void setTam (const Vec2& nTam);

	void sumarOrigen(const Vec2& otro_up_left);

	bool contiene (const Vec2& punto) const;

	void trasladar (const Vec2& delta);

	Rect cambioCoordenadas (const Rect& sistOrigen, const Rect& sistDestino) const;

	SDL_Rect aSDL_Rect() const;

private:
	Vec2 up_left;
	Vec2 down_right;
};

#endif /* RECT_H_ */
