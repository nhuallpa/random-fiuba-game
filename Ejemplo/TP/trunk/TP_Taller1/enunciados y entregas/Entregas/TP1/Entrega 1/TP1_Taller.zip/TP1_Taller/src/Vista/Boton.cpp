/*
 * Boton.cpp
 *
 *  Created on: 14/09/2013
 *  Last Amended: 14/09/2013
 *      Author: natuchis
 */

#include "Boton.h"

#include "Imagen.h"
#include "LayoutInfo.h"
#include "Interfases/Elemento.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "Log/Suceso.h"
#include "Utils/Vec2.h"
#include "Utils/Rect.h"

Boton::Boton(FuentePosicion *fuente, std::string pathImagen, DestinoDibujo *destino)
	: interfases::Elemento(fuente)
	, imagen(NULL)
{
	try {
		imagen = new Imagen(pathImagen, destino);
	} catch (Log::Suceso&) {
		// TODO: imagen = Imagen::botonDefault;
	}
}

Boton::~Boton() {
	delete imagen;
}

void Boton::dibujarse(DestinoDibujo* window) {
	//Acordarse que las posiciones de los elementos que guardamos
	//siempre son relativas a la posicion del contenedor.
	imagen->dibujar(*window, *fuente);
}

void Boton::setImagen(Imagen* imagen){
	this->imagen = imagen;
}

Imagen* Boton::getImagen(){
	return this->imagen;
}

LayoutInfo Boton::getLayoutInfo(){
	return LayoutInfo(imagen->tam());
}
