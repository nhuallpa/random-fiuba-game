#include "Rect.h"

#include "Vec2.h"
#include <SDL2/SDL_rect.h>

Rect::Rect ()
	: up_left(0, 0)
	, down_right(0, 0)
{
}

Rect::Rect(const Rect& copia){
	this->down_right = copia.down_right;
	this->up_left = copia.up_left;
}

Rect::Rect (float x, float y, float w, float h)
	: up_left(x, y)
	, down_right(x+w, y+h)
{
}

Rect::Rect (const Vec2& up_left, const Vec2& tam)
	: up_left(up_left)
	, down_right(up_left + tam)
{
}

Rect Rect::deCentro (const Vec2& centro, const Vec2& tam)
{
	return Rect(centro - tam/2, tam);
}

Rect::~Rect ()
{
}

Vec2 Rect::origen () const
{
	return up_left;
}

Vec2 Rect::centro () const
{
	return (up_left + down_right) / 2;
}

Vec2 Rect::tam () const
{
	return down_right - up_left;
}

bool Rect::contiene (const Vec2& punto) const
{
	return up_left.x <= punto.x && punto.x <= down_right.x && up_left.y <= punto.y && punto.y <= down_right.y;
}

void Rect::trasladar (const Vec2& delta)
{
	up_left += delta;
	down_right += delta;
}

Rect Rect::cambioCoordenadas (const Rect& sistOrigen, const Rect& sistDestino) const
{
	Vec2 ncentro(centro().cambioCoordenadas(sistOrigen, sistDestino));
	Vec2 ntam(tam() * sistDestino.tam() / sistOrigen.tam());
	return Rect::deCentro(ncentro, ntam);
}

SDL_Rect Rect::aSDL_Rect () const
{
	SDL_Rect retval;
	retval.x = up_left.x;
	retval.y = up_left.y;
	retval.w = tam().x;
	retval.h = tam().y;
	return retval;
}

void Rect::setOrigen (const Vec2& nOrigen)
{
	Vec2 tamActual(tam());
	up_left = nOrigen;
	down_right = nOrigen + tamActual;
}

void Rect::setCentro (const Vec2& nCentro)
{
	Vec2 tamActual(tam());
	up_left = nCentro - tamActual / 2;
	down_right = up_left + tamActual;
}

void Rect::setTam (const Vec2& nTam)
{
	Vec2 centroActual(centro());
	up_left = centroActual - nTam / 2;
	down_right = up_left + nTam;
}

void Rect::sumarOrigen(const Vec2& otro_up_left){
	this->up_left+=otro_up_left;
}
