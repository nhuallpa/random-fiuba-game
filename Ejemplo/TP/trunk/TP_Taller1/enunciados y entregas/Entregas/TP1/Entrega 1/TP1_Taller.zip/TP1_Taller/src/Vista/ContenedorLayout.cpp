#include "ContenedorLayout.h"

#include "LayoutInfo.h"
#include <algorithm>

ContenedorLayout::ContenedorLayout (FuentePosicion* fuente, DestinoDibujo* destino, bool horizontal)
	: Contenedor(fuente, destino)
	, horizontal(horizontal)
	, separacion(0.0)
	, arreglo()
{
}

ContenedorLayout::~ContenedorLayout ()
{
}

void ContenedorLayout::addElemento(interfases::Elemento* elemento, FuenteLayout* fuente)
{
	arreglo.push_back(std::pair<interfases::Elemento*, FuenteLayout*>(elemento, fuente));
	Contenedor::addElemento(elemento);
}

void ContenedorLayout::quitarElemento(interfases::Elemento* elemento)
{
	typedef std::list<dato_t>::iterator iterator_t;
	for (iterator_t it = arreglo.begin(); it != arreglo.end(); ++it) {
		if (it->first == elemento) {
			it = arreglo.erase(it);
		}
	}
	Contenedor::quitarElemento(elemento);
}

LayoutInfo ContenedorLayout::getLayoutInfo()
{
	LayoutInfo retval;

	typedef std::list<dato_t>::iterator iterator_t;
	for (iterator_t it = arreglo.begin(); it != arreglo.end(); ++it) {
		retval = retval.combinar(it->first->getLayoutInfo(), horizontal);
	}

	float multiplicadorSeparacion = 1.0 + std::max(0.0f, separacion * (arreglo.size() - 1));
	if (horizontal) {
		retval.tamPreferido.x *= multiplicadorSeparacion;
	} else {
		retval.tamPreferido.y *= multiplicadorSeparacion;
	}

	return retval;
}

void ContenedorLayout::setSeparacion(float fraccion)
{
	separacion = fraccion;
}

void ContenedorLayout::regenerar()
{
	recalcularDimensiones();
	Contenedor::regenerar();
}

void ContenedorLayout::recalcularDimensiones()
{
	Vec2 tamContenedor(getSuperficie().tam());

	float tamParalelo = horizontal ? tamContenedor.x : tamContenedor.y;
	float diferencia = realizarLayout(0, 0);
	float espacioUsado = tamParalelo - diferencia;

	float multiplicadorSeparacion = std::max(0.0f, separacion * (arreglo.size() - 1));
	float espacioSeparadores = espacioUsado * multiplicadorSeparacion;
	if (espacioSeparadores > diferencia) {
		espacioSeparadores = diferencia;
	}
	float espacioInfinitos = tamParalelo - espacioUsado - espacioSeparadores;

	int infinitos = 0;
	for (iterator_t it = arreglo.begin(); it != arreglo.end(); ++it) {
		if (it->first->getLayoutInfo().infinitoParalelo(horizontal)) {
			infinitos++;
		}
	}
	float separacion = (arreglo.size() == 1) ? 0.0 : (espacioSeparadores / (arreglo.size() - 1));
	float extension = (infinitos == 0) ? 0.0 : (espacioInfinitos / infinitos);
	realizarLayout(separacion, extension);
}

/* Devuelve espacio no ocupado. Argumentos son el espacio a usar entre pares
 * de objetos, y espacio a usar para cada objeto extensible.
 */
float ContenedorLayout::realizarLayout (float separacion, float extension)
{
	Vec2 tamContenedor(getSuperficie().tam());

	Vec2 media;
	if (horizontal) {
		media.y = tamContenedor.y / 2;
	} else {
		media.x = tamContenedor.x / 2;
	}

	LayoutInfo miInfo(this->getLayoutInfo());
	Vec2 ratios = (tamContenedor - miInfo.tamMinimo)/ (miInfo.tamPreferido - miInfo.tamMinimo);
	float ratio = horizontal ? ratios.x : ratios.y;

	for (iterator_t it = arreglo.begin(); it != arreglo.end(); ++it) {
		LayoutInfo currentInfo(it->first->getLayoutInfo());
		Vec2 nTam;
		if (ratio < 1) {
			nTam = currentInfo.interpoladoCompatible(tamContenedor, horizontal, ratio);
		} else {
			nTam = currentInfo.maximoCompatible(tamContenedor, horizontal, extension);
		}

		Vec2 avance;
		Vec2 separador;
		if (horizontal) {
			avance.x = nTam.x / 2;
			separador.x = separacion;
		} else {
			avance.y = nTam.y / 2;
			separador.y = separacion;
		}
		Vec2 nCentro = media + avance;

		it->second->setSuperficie(Rect::deCentro(nCentro, nTam));
		it->second->setTamPadre(tamContenedor);

		media = nCentro + avance + separador;
	}

	if (horizontal) {
		return tamContenedor.x - media.x;
	} else {
		return tamContenedor.y - media.y;
	}
}
