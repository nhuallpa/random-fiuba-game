/*
 * Textbox.cpp
 *
 *  Created on: 24/09/2013
 *      Author: rick
 */

#include "Textbox.h"

#include "Imagen.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "LayoutInfo.h"
#include "Textura.h"
#include "Utils/Rect.h"
#include <SDL2/SDL_rect.h>
#include <SDL2/SDL_image.h>


Textbox::Textbox(FuentePosicion* fuente, DestinoDibujo* destino)
     : interfases::Elemento(fuente) {

	if (!TTF_WasInit()) {
		if (TTF_Init() == -1) {
			std::string mensaje("Fallo al iniciar SDL2_ttf: ");
			mensaje += TTF_GetError();
			throw Log::Suceso(Log::FATAL, mensaje);
		}
		else {
			Log::Suceso(Log::INFO, "SDL2_ttf iniciado correctamente.");
		}
	}
	
	this->fuenteTexto = TTF_OpenFont("fonts/Arial_Bold.ttf", 14);
	if (this->fuenteTexto == NULL){
		std::string mensaje("Fallo al iniciar la fuente: ");
		mensaje += TTF_GetError();
		throw Log::Suceso(Log::FATAL, mensaje);
	}
	else {
		Log::Suceso(Log::INFO, "Fuente arial bold iniciado correctamente.");
	}
	
	this->colorTexto = {0,0,0};
	this->textoTotal  = "";
	this->textoActual = "                                                     ";
	this->apariencia = new Textura(*destino,fuente->getSuperficie().tam());

	//manejar excepciones
	this->fondo = new Imagen("imagenes/exampleimage.bmp", destino);
}


Textbox::~Textbox() {
	if (fondo != NULL) {
		delete fondo;
	}
	if (apariencia != NULL) {
		delete apariencia;
	}
	TTF_CloseFont(this->fuenteTexto);
}


LayoutInfo Textbox::getLayoutInfo() {
	return LayoutInfo(Vec2(300, 25), Vec2(150, 25), false, false);
}


std::string Textbox::getTexto() {
	return this->textoTotal;
}


void Textbox::setTexto(std::string unTexto) {
	this->textoTotal = unTexto;
}


void Textbox::regenerar() {
	SDL_Surface* superficieTexto;
	superficieTexto = TTF_RenderText_Solid(this->fuenteTexto, this->textoActual.c_str(), this->colorTexto);

	if (superficieTexto != NULL) {
		if (superficieTexto->w > this->getSuperficie().tam().x) {
			textoActual = textoActual.substr(1);
			superficieTexto->w = this->getSuperficie().tam().x;
		}
		Textura* tex = new Textura(*apariencia, superficieTexto);
		SDL_FreeSurface(superficieTexto);
		if (tex != NULL){
			delete apariencia;
			apariencia = tex;
		}
	}

}


void Textbox::dibujarse(DestinoDibujo* destino) {
	apariencia->limpiar();
	regenerar();
	if (fondo != NULL){
		fondo->dibujar(*apariencia);
	}
	apariencia->dibujar(*destino, *fuente);
}


void Textbox::grabarCaracter(char caracter) {
	this->textoTotal.push_back(caracter);
	this->textoActual.push_back(caracter);
}


bool Textbox::preparadoParaTexto() {
	return preparadoParaEscritura;
}


void Textbox::prepararParaEscritura() {
	preparadoParaEscritura = true;
}


void Textbox::reaccionar() {
	this->preparadoParaEscritura = true;
}


void Textbox::limpiarTexto() {
	this->textoTotal  = "";
	this->textoActual = "";
	this->preparadoParaEscritura = false;
	apariencia->limpiar();
}







