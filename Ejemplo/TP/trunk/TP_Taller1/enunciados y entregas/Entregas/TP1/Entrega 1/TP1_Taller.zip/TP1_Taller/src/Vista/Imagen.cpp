#include "Imagen.h"

#include "Interfases/DestinoDibujo.h"
#include "Log/Suceso.h"
#include "Utils/Vec2.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdexcept>

std::map<SDL_Renderer*, std::map<std::string, Imagen::ImagenReal*> > Imagen::cache;

struct Imagen::ImagenReal
{
	ImagenReal (const std::string &path);
	ImagenReal (const std::string &path, DestinoDibujo *destino);
	virtual ~ImagenReal ();
	static ImagenReal* ImagenDefault (const std::string &path, DestinoDibujo *destino);

	Vec2 tam ();

	SDL_Texture *tex;
	SDL_Renderer *ren;
	std::string path;
	int referencias;
};

Imagen::ImagenReal::ImagenReal (const std::string &path)
	: tex(NULL)
	, ren(NULL)
	, path(path)
	, referencias(0)
{
}

Imagen::ImagenReal *Imagen::ImagenReal::ImagenDefault (const std::string &path, DestinoDibujo *destino)
{
	Imagen::ImagenReal *retval = new Imagen::ImagenReal(path);

	retval->ren = destino->getRenderer();
	retval->tex = SDL_CreateTexture(retval->ren, SDL_PIXELFORMAT_RGBA8888,
	                              SDL_TEXTUREACCESS_TARGET, 100, 100);
	if (retval->tex == NULL) {
		std::string mensaje("No se pudo crear imagen por defecto: ");
		mensaje = mensaje + SDL_GetError();
		throw Log::Suceso(Log::ERROR, mensaje);
	}

	// guardo estado de renderer
	Uint8 r, g, b, a;
	SDL_GetRenderDrawColor(retval->ren, &r, &g, &b, &a);
	SDL_Texture *oldTarget = SDL_GetRenderTarget(retval->ren);

	SDL_SetRenderTarget(retval->ren, retval->tex);
	SDL_SetRenderDrawColor(retval->ren, 255, 0, 0, 255);
	SDL_RenderDrawLine(retval->ren, 0, 0, 100, 100);
	SDL_RenderDrawLine(retval->ren, 0, 100, 100, 0);

	// restauro estado de renderer
	SDL_SetRenderTarget(retval->ren, oldTarget);
	SDL_SetRenderDrawColor(retval->ren, r, g, b, a);

	return retval;
}

Imagen::ImagenReal::ImagenReal (const std::string &path, DestinoDibujo *destino)
	: tex(NULL)
	, ren(destino->getRenderer())
	, path(path)
	, referencias(0)
{
	SDL_Surface *loadedImage = IMG_Load(path.c_str());
	if (loadedImage == NULL) {
		std::string mensaje("No se pudo cargar imagen: ");
		mensaje = mensaje + IMG_GetError();
		throw Log::Suceso(Log::ERROR, mensaje);
	}

	this->tex = SDL_CreateTextureFromSurface(ren, loadedImage);
	SDL_FreeSurface(loadedImage);
	if (tex == NULL) {
		std::string mensaje("No se pudo crear imagen: ");
		mensaje = mensaje + SDL_GetError();
		throw Log::Suceso(Log::ERROR, mensaje);
	}
}

Imagen::ImagenReal::~ImagenReal ()
{
	SDL_DestroyTexture(tex);
}

Vec2 Imagen::ImagenReal::tam ()
{
	int x, y;
	SDL_QueryTexture(tex, NULL, NULL, &x, &y);
	return Vec2(x, y);
}



Imagen::Imagen (const Imagen& rhs)
	: impl(rhs.impl)
{
	impl->referencias++;
}

Imagen::Imagen (const std::string &path, DestinoDibujo *destino)
{
	SDL_Renderer *ren = destino->getRenderer();
	if (cache[ren].find(path) == cache[ren].end() || cache[ren].find(path)->second == NULL) {
		if (path == "") {
			cache[ren][path] = ImagenReal::ImagenDefault(path, destino);
		} else {
			try {
				cache[ren][path] = new ImagenReal(path, destino);
			} catch (Log::Suceso&) {
				cache[ren][path] = ImagenReal::ImagenDefault(path, destino);
			}
		}
	}
	impl = cache[ren][path];
	impl->referencias++;
}

Imagen::~Imagen ()
{
	impl->referencias--;
	if (impl->referencias == 0) {
		cache[impl->ren][impl->path] = NULL;
		delete impl;
	}
}

Vec2 Imagen::tam ()
{
	return impl->tam();
}

SDL_Texture *Imagen::getTextureR ()
{
	return impl->tex;
}

