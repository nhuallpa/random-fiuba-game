#ifndef ORIGENDIBUJO_H_
#define ORIGENDIBUJO_H_

class DestinoDibujo;
class FuentePosicion;
struct SDL_Texture;

class OrigenDibujo
{
public:
	OrigenDibujo () {}
	virtual ~OrigenDibujo () {}

	void dibujar (DestinoDibujo& destino);
	void dibujar (DestinoDibujo& destino, FuentePosicion& fuente);

	virtual SDL_Texture* getTextureR() = 0;
};

#endif /* ORIGENDIBUJO_H_ */
