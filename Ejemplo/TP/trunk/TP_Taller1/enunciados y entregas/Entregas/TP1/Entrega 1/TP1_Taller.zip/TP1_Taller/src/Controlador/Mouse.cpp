/*
 * Mouse.cpp
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#include "Mouse.h"

#include "Vista/FiguraVista.h"
#include "Vista/Interfases/Elemento.h"
#include "Vista/FuentesPosicion/FuenteLayout.h"
#include "Vista/FuentesPosicion/FuenteMouse.h"
#include <SDL2/SDL.h>


namespace controlador {

Mouse::Mouse()
	: arrastrando(false)
	, rotando(false)
	, clon(false)
	, elemento(NULL)
{
}

Mouse::~Mouse() {
	if (arrastrando) {
		delete elemento;
	}
}

void Mouse::iniciarSeleccion(const Ventana *ventana, interfases::Elemento* nElemento,
	                     Contenedor *contenedorRaiz)
{

	if (elemento != NULL) return;

	if(nElemento->getClonable()){
		elemento = nElemento->clonar();
		if (elemento == NULL) return;

		arrastrando = true;

		contenedorRaiz->aEliminar(getPosicionMouse());

		FuentePosicion *nFuente = new FuenteMouse(ventana, this, elemento->getFuente());
		elemento->setFuente(nFuente);
		contenedorRaiz->addElemento(elemento);
		clon = true;
	} else {
		contenedorRaiz->mandarAlFrente(nElemento);
		elemento = nElemento;
		arrastrando = true;
	}
}

void Mouse::iniciarRotacion(interfases::Elemento* nElemento) {
	if (elemento == NULL && nElemento != NULL) {
		rotando = true;
		elemento = nElemento;
	}
}

void Mouse::realizarMovimiento(SDL_Event* event){
	Vec2 movimiento(event->motion.xrel, event->motion.yrel);
	if (arrastrando) {
		elemento->mover(movimiento);
	} else if (rotando) {
		elemento->rotar(this->getPosicionMouse());
	}
}

Vec2 Mouse::getPosicionMouse() const{
	int x, y;
	SDL_GetMouseState(&x, &y);
	return Vec2(x, y);
}

void Mouse::soltar(Contenedor *contenedorRaiz){
	if (clon) {
		contenedorRaiz->quitarElemento(elemento);
		//TODO: manejar si falla el dynamic_cast (pero no deberia!)
		contenedorRaiz->recibirFigura(dynamic_cast<FiguraVista*>(elemento));
		delete elemento;
		clon = false;
	}
	elemento = NULL;
	arrastrando = false;
	rotando = false;
}

} /* namespace controlador */
