/*
 * Elemento.h
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#ifndef ELEMENTO_H_
#define ELEMENTO_H_

#include "Utils/Vec2.h"

class Rect;
class DestinoDibujo;
class FuentePosicion;
class LayoutInfo;
class Ventana;
class Contenedor;
class FiguraVista;

namespace interfases {

//Clase abstracta que modela cualquier elemento que pueda formar parte de la pantalla
class Elemento {
public:
	Elemento (FuentePosicion *fuente = NULL);
	virtual ~Elemento();

	// dibujo
	virtual void dibujarse(DestinoDibujo* destino) = 0;
	virtual Rect getSuperficie() const; //relativa a su padre
	virtual void setSuperfice(const Rect& val) {};
	virtual FuentePosicion* getFuente ();
	virtual void setFuente(FuentePosicion* fuente);

	// informacion de tamaño
	virtual LayoutInfo getLayoutInfo() = 0;

	// control de visibilidad
	virtual void ocultar();
	virtual void mostrar();
	virtual bool visibilidad();

	// respuesta a eventos
	virtual bool contiene(Vec2 punto);
	virtual interfases::Elemento* buscarElemento(Vec2);
	virtual void mover(Vec2) {};
	virtual void desplazarHaciaArriba(Vec2) {};
	virtual void desplazarHaciaAbajo(Vec2) {};
	virtual void rotar(Vec2) {};
	virtual bool aEliminar (Vec2 posicion);
	virtual void reaccionar() {};
	virtual void recibirFigura (const FiguraVista *elemento);
	virtual void grabarCaracter(char caracter) {};
	virtual bool preparadoParaTexto ();
	virtual void prepararParaEscritura() {};

	//TODO parche para la entrega
	virtual void setClonable(bool clonable);
	virtual bool getClonable();

	virtual interfases::Elemento* clonar() const;

	//El único que implementará esto es la toolbar por ahora.
	virtual interfases::Elemento* clonar(Vec2 posicionMouse) const;

	//PARCHE TODO TODO TODO
	virtual void mandarAlFrente(interfases::Elemento* el){ return;}

protected:
	bool visible;
	bool clonable;
	FuentePosicion* fuente;
};

} /* namespace interfases */
#endif /* ELEMENTO_H_ */
