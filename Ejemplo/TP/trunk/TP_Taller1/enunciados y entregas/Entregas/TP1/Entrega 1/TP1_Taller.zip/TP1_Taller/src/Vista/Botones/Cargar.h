/*
 * Cargar.h
 *
 *  Created on: 14/09/2013
 *  Last Amended: 24/09/2013
 *      Author: natuchis, rick
 */

#ifndef CARGAR_H_
#define CARGAR_H_

#include "Vista/Boton.h"
#include "Vista/ConstantesVista.h"
#include "Vista/Textbox.h"


class Cargar: public Boton {

public:
	Cargar(FuentePosicion* fuente, DestinoDibujo* destino, Contenedor* canvas, Textbox* textbox);
	virtual ~Cargar();
	std::string getPathImagen();
	virtual void reaccionar();

private:
	std::string pathImagen;
	Contenedor* canvas;
	Textbox* textbox;
	DestinoDibujo* destino;

};

#endif /* CARGAR_H_ */

