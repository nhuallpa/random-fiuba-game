/*
 * ToolBar.h
 *
 *  Created on: 15/09/2013
 *      Author: stephanie
 */

#ifndef TOOLBAR_H_
#define TOOLBAR_H_

#include <list>
#include "FiguraVista.h"
#include "Textura.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "Interfases/Elemento.h"
#include "Contenedor.h"
#include "Boton.h"

class Canvas;

class ToolBar:public Contenedor{
public:
	ToolBar(FuentePosicion* fuente, DestinoDibujo* destino, Canvas *canvas);
	virtual ~ToolBar();
	void addElemento(interfases::Elemento* fig);

	void subirToolBar();
	void bajarToolBar();

	virtual void desplazarHaciaArriba(Vec2 posicion);
	virtual void desplazarHaciaAbajo(Vec2 posicion);
	virtual LayoutInfo getLayoutInfo();

	interfases::Elemento* clonar(Vec2 posicionMouse) const;

	int getPosicionEnToolbar();

private:
	static const int espacioEntreFiguras = 20;
	static const int desplazamientoInicial = 10;
	static const float desplazamientoFraccional = 0.02;

	int posicionEnToolbar;
	Canvas *canvas;

	void actualizarPosicionEnToolbar(Rect fig);
	virtual void regenerar();
	void actualizarSuperficiesFiguras(interfases::Elemento* figura);
};

#endif /* TOOLBAR_H_ */
