/*
 * Contenedor.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: lucia
 */

#include "Contenedor.h"

#include "Imagen.h"
#include "FiguraVista.h"
#include "LayoutInfo.h"
#include "Textura.h"
#include "Interfases/DestinoDibujo.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "Log/Suceso.h"
#include "Utils/Rect.h"

Contenedor::Contenedor(FuentePosicion* fuente, DestinoDibujo* destino)
	: interfases::Elemento(fuente)
	, listaElementos()
	, fondo(NULL)
	, apariencia(new Textura(*destino, fuente->getSuperficie().tam()))
	, permitirEliminaciones(false)
{
//	setBackground("imagenes/exampleimage.bmp", destino);
}

void Contenedor::addElemento(interfases::Elemento* fig) {
	//hay que ver donde se setea la imagen de la figura, probablemente hacer un factory en el contenedor.
	listaElementos.push_front(fig);
}

void Contenedor::regenerar() {
	Vec2 ratios = fuente->getSuperficie().tam() / apariencia->tamDestino();
	if (std::max(ratios.x, ratios.y) > 1.2) {
		Textura *nApariencia = new Textura(*apariencia, fuente->getSuperficie().tam());
		if (nApariencia != NULL) {
			delete apariencia;
			apariencia = nApariencia;
		}
	}

	apariencia->limpiar();
	if (fondo != NULL) {
		fondo->dibujar(*apariencia);
	}
	for (std::list<interfases::Elemento*>::reverse_iterator it = listaElementos.rbegin(); it != listaElementos.rend(); it++){
		interfases::Elemento* elemento = *it;
		elemento->dibujarse(apariencia);
	}
}

void Contenedor::dibujarse (DestinoDibujo* destino) {
	regenerar();
	apariencia->dibujar(*destino, *fuente);
}

Contenedor::~Contenedor() {
	if (fondo != NULL) {
		delete fondo;
	}
	if (apariencia != NULL) {
		delete apariencia;
	}
}

void Contenedor::setBackground(std::string filename, DestinoDibujo* destino) {

	Imagen *nFondo = NULL;
	try {
		nFondo = new Imagen(filename, destino);
	} catch (Log::Suceso&) {
		// TODO: nFondo = Imagen::fondoDefault;
	}

	if (fondo != NULL) {
		delete fondo;
	}
	fondo = nFondo;
	regenerar();
}

interfases::Elemento* Contenedor::buscarElemento(Vec2 posicionMouse) {

	typedef std::list<interfases::Elemento*>::iterator iterator;
	iterator it = listaElementos.begin();
	iterator it_end = listaElementos.end();

	Vec2 mouseRelativo = posicionMouse - fuente->getSuperficie().origen();

	interfases::Elemento* elemento = NULL;
	for (;it != it_end; ++it) {
		elemento = *it;
		if (elemento->contiene(mouseRelativo)) {
	    		return elemento->buscarElemento(mouseRelativo);
		}
	}
	return NULL;
}

void Contenedor::desplazarHaciaArriba(Vec2 posicionRespectoPadre){
	Vec2 posicion = posicionRespectoPadre - this->fuente->getSuperficie().origen();

	typedef std::list<interfases::Elemento*>::iterator iterator;
	for (iterator iter = listaElementos.begin(); iter != listaElementos.end(); ++iter) {
		if ((*iter)->contiene(posicion)) {
			(*iter)->desplazarHaciaArriba(posicion);
			break;
		}
	}
}

void Contenedor::desplazarHaciaAbajo(Vec2 posicionRespectoPadre){
	Vec2 posicion = posicionRespectoPadre - this->fuente->getSuperficie().origen();

	typedef std::list<interfases::Elemento*>::iterator iterator;
	for (iterator iter = listaElementos.begin(); iter != listaElementos.end(); ++iter) {
		if ((*iter)->contiene(posicion)) {
			(*iter)->desplazarHaciaAbajo(posicion);
			break;
		}
	}
}

bool Contenedor::aEliminar (Vec2 posicionRespectoPadre){
	Vec2 posicion = posicionRespectoPadre - this->fuente->getSuperficie().origen();

	typedef std::list<interfases::Elemento*>::iterator iterator;
	for (iterator iter = listaElementos.begin(); iter != listaElementos.end(); ++iter) {
		if ((*iter)->contiene(posicion)) {
			if ((*iter)->aEliminar(posicion) && permitirEliminaciones) {
				listaElementos.remove(*iter);
			}
			break;
		}
	}
	return false;
}

void Contenedor::mandarAlFrente(interfases::Elemento* elemento) {
	Vec2 posicion = elemento->getSuperficie().centro() - this->fuente->getSuperficie().origen();

	typedef std::list<interfases::Elemento*>::iterator iterator;
		for (iterator iter = listaElementos.begin(); iter != listaElementos.end(); ++iter) {
			if ((*iter)->contiene(posicion)) {
				(*iter)->mandarAlFrente(elemento);
				break;
			}
		}
}

void Contenedor::recibirFigura (const FiguraVista *elemento){
	Vec2 posicion = elemento->getSuperficie().centro() - this->fuente->getSuperficie().origen();

	typedef std::list<interfases::Elemento*>::iterator iterator;
	for (iterator iter = listaElementos.begin(); iter != listaElementos.end(); ++iter) {
		if ((*iter)->contiene(posicion)) {
			(*iter)->recibirFigura(elemento);
			break;
		}
	}
}

void Contenedor::setPermitirEliminaciones (bool permitido){
	permitirEliminaciones = permitido;
}

void Contenedor::quitarElemento(interfases::Elemento* elemento){
	listaElementos.remove(elemento);
}

LayoutInfo Contenedor::getLayoutInfo(){
	return LayoutInfo(Vec2(), Vec2(), true, true);
}

interfases::Elemento* Contenedor::clonar(Vec2 posicionMouse ) const {
	//Recorre su lista de elementos y llama a su clonar, es recursivo.
	typedef std::list<interfases::Elemento*>::const_iterator iterator;
	iterator it = listaElementos.begin();
	iterator it_end = listaElementos.end();

	Vec2 mouseRelativo = posicionMouse - fuente->getSuperficie().origen();

	interfases::Elemento* elemento = NULL;
	interfases::Elemento* elementoRes = NULL;

	while ((it != it_end) && (elementoRes == NULL)) {
		elemento = *it;
		if (elemento->contiene(mouseRelativo)) {
			elementoRes = elemento->clonar(mouseRelativo);
		}
		++it;
	}
	return elementoRes;
}
