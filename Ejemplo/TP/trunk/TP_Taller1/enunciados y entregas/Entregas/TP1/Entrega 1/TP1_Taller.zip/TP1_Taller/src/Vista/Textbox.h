/*
 * Textbox.h
 *
 *  Created on: 24/09/2013
 *      Author: rick
 */

#ifndef TEXTBOX_H_
#define TEXTBOX_H_

#include <list>
#include "FiguraVista.h"
#include "Textura.h"
#include "FuentesPosicion/FuentePosicion.h"
#include "Interfases/Elemento.h"
#include "Imagen.h"
#include "Contenedor.h"
#include "Log/Logger.h"
#include "Log/Suceso.h"

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <string>


class Textbox : public interfases::Elemento {

public:

	Textbox(FuentePosicion* fuente, DestinoDibujo* destino);
	virtual ~Textbox();
	virtual LayoutInfo getLayoutInfo();
	
	std::string getTexto();
	void setTexto(std::string);
	
//	void dibujarTexto();
	void regenerar();
	virtual void dibujarse(DestinoDibujo* destino);
	virtual void grabarCaracter(char caracter);
	virtual bool preparadoParaTexto();
	virtual void prepararParaEscritura();
	virtual void reaccionar();
	void limpiarTexto();


private:

	std::string textoTotal;
	std::string textoActual;
	
	TTF_Font* fuenteTexto;
	SDL_Colour colorTexto;
	Textura* apariencia;
	Imagen* fondo;
	bool preparadoParaEscritura;
	
};

#endif /* TEXTBOX_H_ */

