/*
 * FlechaDown.cpp
 *
 *  Created on: 16/09/2013
 *  Last Amended: 16/09/2013
 *      Author: natuchis
 */

#include "FlechaDown.h"

FlechaDown::FlechaDown(FuentePosicion *fuente, DestinoDibujo *destino, ToolBar* toolbar)
	: Boton(fuente, constantesVista::ConstantesVista::imagenFlechaDown, destino)
{
	this->pathImagen = constantesVista::ConstantesVista::imagenFlechaDown;
	this->toolbar = toolbar;
}

FlechaDown::~FlechaDown() {
}

std::string FlechaDown::getPathImagen() {
	return this->pathImagen;
}

void FlechaDown::reaccionar(){
	toolbar->desplazarHaciaArriba(Vec2());
}
