/*
 * Mouse.h
 *
 *  Created on: Sep 13, 2013
 *      Author: lucia
 */

#ifndef MOUSE_H_
#define MOUSE_H_

#include "Vista/Interfases/DestinoDibujo.h"
#include "Vista/Contenedor.h"
#include "Utils/Rect.h"

namespace interfases {
	class Elemento;
}
union SDL_Event;
class Vec2;

namespace controlador {

class Mouse {
public:
	Mouse();
	virtual ~Mouse();

	void iniciarSeleccion(const Ventana *ventana, interfases::Elemento* nElemento,
	                      Contenedor *contenedorRaiz);
	void iniciarRotacion(interfases::Elemento* elemento);

	void realizarMovimiento(SDL_Event* event);
	Vec2 getPosicionMouse() const;

	void soltar(Contenedor *contenedorRaiz);

	interfases::Elemento* clonarDeToolbar(DestinoDibujo* window, Contenedor* contenedorRaiz);

private:
	bool arrastrando;
	bool rotando;
	bool clon;
	interfases::Elemento* elemento;
};

} /* namespace controlador */
#endif /* MOUSE_H_ */
