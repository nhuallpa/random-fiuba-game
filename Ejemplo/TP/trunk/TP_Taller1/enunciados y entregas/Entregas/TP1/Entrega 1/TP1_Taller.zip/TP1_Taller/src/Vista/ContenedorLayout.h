#ifndef CONTENEDORLAYOUT_H_
#define CONTENEDORLAYOUT_H_

#include "Vista/Contenedor.h"
#include "Vista/FuentesPosicion/FuenteLayout.h"

class ContenedorLayout : public Contenedor
{
public:
	ContenedorLayout (FuentePosicion* fuente, DestinoDibujo* destino, bool horizontal);
	virtual ~ContenedorLayout ();

	void addElemento(interfases::Elemento* elemento, FuenteLayout* fuente);
	virtual void quitarElemento(interfases::Elemento* elemento);

	virtual LayoutInfo getLayoutInfo();

	void setSeparacion (float fraccion);

private:
	bool horizontal;
	float separacion;

	typedef std::pair<interfases::Elemento*, FuenteLayout*> dato_t;
	typedef std::list<dato_t>::iterator iterator_t;
	std::list<dato_t> arreglo;

	virtual void regenerar();
	void recalcularDimensiones();
	float realizarLayout(float separacion, float extension);
};

#endif /* CONTENEDORLAYOUT_H_ */
