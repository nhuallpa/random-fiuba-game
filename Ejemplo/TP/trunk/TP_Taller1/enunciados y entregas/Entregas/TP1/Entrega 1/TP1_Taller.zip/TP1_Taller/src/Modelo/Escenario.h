/*
 * Escenario.h
 *
 *  Created on: 25/09/2013
 *  Last Amended: 25/09/2013
 *      Author: natuchis
 */

#ifndef ESCENARIO_H_
#define ESCENARIO_H_

#include "Modelo/Mundo.h"
#include "Utils/YAMLHelper.h"
#include <yaml-cpp/yaml.h>

struct Escenario {

	Modelo::Mundo mundo;
	std::string pathFondo;

	Escenario();
	Escenario(std::string path, Modelo::Mundo mundo);
	virtual ~Escenario();

};

namespace YAML {
template<>
struct convert<Escenario> {
	static Node encode(const Escenario& rhs);

	// EL NODO ENTREGADO DEBE SER DISTINTO DE NULL Y DEFINIDO.
	static bool decode(const Node& node, Escenario& rhs);
};
}

#endif /* ESCENARIO_H_ */
