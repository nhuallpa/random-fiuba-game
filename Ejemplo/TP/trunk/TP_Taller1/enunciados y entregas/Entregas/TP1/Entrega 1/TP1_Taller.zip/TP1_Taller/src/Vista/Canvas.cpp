#include "Canvas.h"

#include "Modelo/Entidad.h"
#include "Modelo/Mundo.h"
#include "Vista/FiguraVista.h"
#include "Vista/FuentesPosicion/FuenteModelo.h"

Canvas::Canvas (FuentePosicion* fuente, DestinoDibujo* destino, Modelo::Mundo* mundo,
                const Rect& regionModelo)
	: Contenedor(fuente, destino)
	, mundo(mundo)
	, regionModelo(regionModelo)
{
	typedef Modelo::Mundo::iterator iter;
	for (iter it = mundo->begin(); it != mundo->end(); ++it) {
		FuenteModelo *nFuente = new FuenteModelo(*it, &regionModelo, this);
		FiguraVista *nFig = new FiguraVista((*it)->clase, nFuente, destino);
		this->addElemento(nFig);
	}
}

Canvas::~Canvas ()
{
}

Vec2 Canvas::tamUnidadLogica() const
{
	return getSuperficie().tam() / regionModelo.tam();
}

void Canvas::recibirFigura (const FiguraVista *figura)
{
	FiguraVista *nFigura = new FiguraVista(*figura);

	Rect supFiguraVista = figura->getSuperficie();
	Rect regionVista = this->getSuperficie();
	Rect supFiguraModelo = supFiguraVista.cambioCoordenadas(regionVista, regionModelo);

	Modelo::Entidad *nEntidad = new Modelo::Entidad(nFigura->getClase(), supFiguraModelo.centro(),
	                                                supFiguraModelo.tam(), 0.0);
	mundo->agregarEntidad(nEntidad);

	FuenteModelo *nFuente = new FuenteModelo(nEntidad, &regionModelo, this);
	nFuente->setAngulo(nFigura->getFuente()->getAngulo());
	nFigura->setFuente(nFuente);

	this->addElemento(nFigura);
}

bool Canvas::aEliminar (Vec2 posicionRespectoPadre){
	Vec2 posicion = posicionRespectoPadre - this->fuente->getSuperficie().origen();

	typedef std::list<interfases::Elemento*>::iterator iterator;
	for (iterator iter = listaElementos.begin(); iter != listaElementos.end(); ++iter) {
		if ((*iter)->contiene(posicion)) {
			if ((*iter)->aEliminar(posicion) && permitirEliminaciones) {
				FuentePosicion *fuente = (*iter)->getFuente();
				FuenteModelo *fuenteCasteada = dynamic_cast<FuenteModelo*>(fuente);
				mundo->quitarEntidad(fuenteCasteada->getEntidad());
				listaElementos.remove(*iter);
			}
			break;
		}
	}
	return false;
}

//PARCHE PARA LA ENTREGA TODO
void Canvas::mandarAlFrente(interfases::Elemento* el) {
	bool estaEnMiLista = false;
	typedef std::list<interfases::Elemento*>::iterator iterator;
	for (iterator iter = listaElementos.begin(); iter != listaElementos.end(); ++iter) {
		if (el == *iter)
			estaEnMiLista = true;
	}
	if (estaEnMiLista){
		listaElementos.remove(el);
		listaElementos.push_front(el);
	}
}
