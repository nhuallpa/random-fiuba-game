#include "FuenteVentana.h"

#include "Vista/Ventana.h"
#include "Utils/Vec2.h"
#include "Utils/Rect.h"

FuenteVentana::FuenteVentana (Ventana *ventana)
	: ventana(ventana)
{
}

FuenteVentana::FuenteVentana (const FuenteVentana& rhs)
	: ventana(rhs.ventana)
{
}

FuenteVentana::~FuenteVentana ()
{
}

Rect FuenteVentana::getSuperficie ()
{
	return Rect(Vec2(0, 0), ventana->tamDestino());
}

void FuenteVentana::setSuperficie (const Rect&)
{
}

Vec2 FuenteVentana::getTamPadre ()
{
	return ventana->tamDestino();
}

float FuenteVentana::getAngulo ()
{
	return 0;
}

void FuenteVentana::setAngulo (float)
{
}

FuentePosicion *FuenteVentana::clonar() {
	return new FuenteVentana(*this);
}
