#include "Vec2.h"

#include "Rect.h"
#include "Log/Suceso.h"
#include "Log/Logger.h"
#include "Utils/ConvertStr.h"
#include "Utils/YAMLHelper.h"
#include <string>

Vec2::Vec2 ()
	: x(0)
	, y(0)
{
}

Vec2::Vec2 (float x, float y)
	: x(x)
	, y(y)
{
}

Vec2::~Vec2 ()
{
}

bool Vec2::operator== (const Vec2& rhs) const
{
	return this->x == rhs.x && this->y == rhs.y;
}

bool Vec2::operator!= (const Vec2& rhs) const
{
	return this->x != rhs.x || this->y != rhs.y;
}

Vec2 Vec2::operator+ (const Vec2& rhs) const
{
	return Vec2(x + rhs.x, y + rhs.y);
}

Vec2 Vec2::operator* (float rhs) const
{
	return Vec2(x * rhs, y * rhs);
}

Vec2 Vec2::operator* (const Vec2& rhs) const
{
	return Vec2(x * rhs.x, y * rhs.y);
}

Vec2 Vec2::operator- () const
{
	return Vec2(-x, -y);
}

Vec2 Vec2::operator- (const Vec2& rhs) const
{
	return Vec2(x - rhs.x, y - rhs.y);
}

Vec2 Vec2::operator/ (float rhs) const
{
	return Vec2(x/rhs, y/rhs);
}

Vec2 Vec2::operator/ (const Vec2& rhs) const
{
	return Vec2(x / rhs.x, y / rhs.y);
}

Vec2& Vec2::operator+= (const Vec2& rhs)
{
	*this = *this + rhs;
	return *this;
}

Vec2& Vec2::operator-= (const Vec2& rhs)
{
	*this = *this - rhs;
	return *this;
}

Vec2& Vec2::operator*= (float rhs)
{
	*this = *this * rhs;
	return *this;
}

Vec2& Vec2::operator/= (float rhs)
{
	*this = *this / rhs;
	return *this;
}

Vec2& Vec2::operator*= (const Vec2& rhs)
{
	*this = *this * rhs;
	return *this;
}

Vec2& Vec2::operator/= (const Vec2& rhs)
{
	*this = *this / rhs;
	return *this;
}

Vec2 Vec2::cambioCoordenadas (const Rect& sistOrigen, const Rect& sistDestino) const
{
	Vec2 relOrigen(*this - sistOrigen.origen());
	Vec2 relDestino(relOrigen * sistDestino.tam() / sistOrigen.tam());
	return relDestino + sistDestino.origen();
}

namespace YAML {
	Node convert<Vec2>::encode(const Vec2& rhs) {
		Node node;
		node.push_back(rhs.x);
		node.push_back(rhs.y);
		return node;
	}

	bool convert<Vec2>::decode(const Node& node, Vec2& rhs) {
		YAML::Mark marca = node.mark();
		std::string msj = "";

		if (!node.IsSequence() || node.size() != 2) {
			ConvertStr output(marca, "No se puede leer Vec2, no es secuencia o no tiene 2 atributos. Creado por defecto (0,0).");
			Log::Suceso (Log::ERROR, output.getString());
		} else {
			rhs.x = YAML_leer<float>(node[0], "x");
			rhs.y = YAML_leer<float>(node[1], "y");
		}
		return true;
	}
}
