//Source code dump of Box2D scene: buoyancy.rube
//
//  Created by R.U.B.E 1.1.0
//  Using Box2D version 2.3.0
//  Wed January 16 2013 17:17:04
//
//  This code is originally intended for use in the Box2D testbed,
//  but you can easily use it in other applications by providing
//  a b2World for use as the 'm_world' variable in the code below.

