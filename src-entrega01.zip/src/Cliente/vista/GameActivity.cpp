#include "GameActivity.h"


GameActivity::GameActivity(const SDLScreen & screen, ViewBuilder & builder, GameLevel * cLevel)
							:Activity(screen),cLevel(cLevel)
{
	ViewGroup*  viewContainer = this->buildView(builder);
	this->setContentView(viewContainer);
}

ViewGroup* GameActivity::buildView( ViewBuilder & builder)
{
	ViewGroup* container = builder.buildContainer();
	this->figureContainer = builder.buildFigureContainer();
	builder.buildSky(container);
	builder.buildFigures(figureContainer);

	container->add(this->figureContainer);
	
	builder.buildTerrain(container);
	builder.buildWater(container);
	return container;
}

void GameActivity::update() 
{
	std::map<int,GameElement*> domainElements = this->cLevel->getEntities();
	std::map<int,GameElement*>::iterator it;
	Log::d(VIEW,"Actualizando %d en elemento", domainElements.size());

	for (it = domainElements.begin(); it != domainElements.end(); ++it)
	{
		GameElement* domainElement = it->second;
		try
		{
			FigureView* aFigure = this->figureContainer->findById(domainElement->getId());
			aFigure->update(domainElement);
		}
		catch (GameException e) {
			Log::e(e.what());
		}

	}
}

GameActivity::~GameActivity(void)
{
	if (aView) delete aView;
	aView = 0;
}
