#include "ViewBuilder.h"


ViewBuilder::ViewBuilder(void)
{
}


ViewBuilder::~ViewBuilder(void)
{
}
