#include "TScreen.h"


TScreen::TScreen(void)
{
}


TScreen::~TScreen(void)
{
}


int TScreen::getWidth(){
	return this->width;
}

int TScreen::getHeight() {
	return this->height;
}