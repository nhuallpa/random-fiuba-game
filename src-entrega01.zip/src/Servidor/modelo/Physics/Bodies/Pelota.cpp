#include <Box2D/Box2D.h>
#include <math.h>
#include "Pelota.h"

#define ANIMATION_SPEED 0.7

Pelota::Pelota(b2World* myWorld)
{
	this->myWorld = myWorld;


}

void Pelota::animate(){
	
}

Pelota::~Pelota() {
}
