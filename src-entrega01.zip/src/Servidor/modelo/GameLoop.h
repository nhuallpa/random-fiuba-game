#pragma once


class GameLoop {

	private:


	public:
		GameLoop();
		virtual ~GameLoop();
};
