#include "GameLoop.h"

GameLoop::GameLoop(){

}

GameLoop::~GameLoop(){

}
