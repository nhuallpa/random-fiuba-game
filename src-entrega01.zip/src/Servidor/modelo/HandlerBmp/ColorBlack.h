#ifndef COLORBLACK_H_
#define COLORBLACK_H_

#include "ColorBmp.h"

using namespace std;

class ColorBlack : public ColorBmp{
public:
ColorBlack();
virtual ~ColorBlack();
};

#endif // COLORBLACK_H_
