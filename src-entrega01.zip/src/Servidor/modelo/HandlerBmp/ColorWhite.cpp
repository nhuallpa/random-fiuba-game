#include "ColorWhite.h"

ColorWhite::ColorWhite()
{
this->red=255;
this->green=255;
this->blue=255;
this->alpha=255; //fully opaque

}


ColorWhite::~ColorWhite()
{

}