#ifndef COLORWHITE_H_
#define COLORWHITE_H_

#include "ColorBmp.h"

using namespace std;

class ColorWhite: public ColorBmp{
public:
ColorWhite();
virtual ~ColorWhite();
};

#endif
