#include "ColorBlack.h"

ColorBlack::ColorBlack()
{
this->red=0;
this->green=0;
this->blue=0;
this->alpha=255; //fully opaque

}


ColorBlack::~ColorBlack()
{

}